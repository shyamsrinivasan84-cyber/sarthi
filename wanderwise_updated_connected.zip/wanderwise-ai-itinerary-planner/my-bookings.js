/**
 * WANDERWISE - MY BOOKINGS CONTROLLER (my-bookings.js)
 * 
 * Manages:
 * 1. Bookings rendering & grouping (Upcoming vs. Past) across all 5 travel modes
 * 2. Search, mode filter pills, and status tabs
 * 3. Client-side Real-time Status Simulation engine (automated timer + manual trigger)
 * 4. In-app notification center (bell dropdown with unread badge, filters, mark as read)
 * 5. Floating in-app toast alerts (confirmations, status updates, upcoming reminders)
 * 6. Interactive Digital E-Ticket / Boarding Pass modal with print support
 * 7. Modify and Cancel booking modals backed by localStorage
 */

(function () {
  'use strict';

  // State
  let currentFilterTab = 'all'; // 'all', 'upcoming', 'past', 'cancelled'
  let currentCategory = 'all'; // 'all', 'flight', 'train', 'bus', 'cab', 'hotel'
  let searchQuery = '';
  let simulationIntervalId = null;
  let simulationSpeedMs = 12000; // 12 seconds default
  let isSimulationRunning = true;
  let activeNotificationTab = 'all';

  // Category Icons & Friendly Labels
  const CATEGORY_META = {
    flight: { icon: '✈', label: 'Flight', class: 'mode-flight' },
    train: { icon: '🚆', label: 'Train', class: 'mode-train' },
    hotel: { icon: '🏨', label: 'Hotel & Stay', class: 'mode-hotel' },
    cab: { icon: '🚖', label: 'Cab Transfer', class: 'mode-cab' },
    bus: { icon: '🚌', label: 'Coach Bus', class: 'mode-bus' }
  };

  // Status Progression State Machine per Mode
  const STATUS_FLOWS = {
    flight: [
      { status: 'Confirmed', desc: 'Seat confirmed. E-ticket issued.' },
      { status: 'Check-in Open', desc: 'Online check-in is now open. Pick your seat.' },
      { status: 'Gate B14 Open', desc: 'Departure gate B14 announced. Terminal 1.' },
      { status: 'Delayed (+25m)', desc: 'Slight delay due to air traffic control. New departure scheduled.' },
      { status: 'Boarding Now', desc: 'Final call for boarding at Gate B14. Priority passengers first.' },
      { status: 'Departed', desc: 'Aircraft in flight. Estimated cruising altitude 36,000 ft.' },
      { status: 'Completed', desc: 'Landed safely. Baggage reclaim at Carousel 4.' }
    ],
    train: [
      { status: 'Confirmed', desc: 'Reservation confirmed. High-speed rail ticket valid.' },
      { status: 'Track 14 Assigned', desc: 'Train arriving at Track 14. Station hall displays updated.' },
      { status: 'Delayed (+10m)', desc: 'Track maintenance speed restriction. Minor 10m delay.' },
      { status: 'Boarding Now', desc: 'Doors open at Platform 14. Board coach as indicated on pass.' },
      { status: 'Departed', desc: 'Train departed on time. High-speed cruising at 285 km/h.' },
      { status: 'Completed', desc: 'Arrived at destination station. Trip concluded.' }
    ],
    hotel: [
      { status: 'Confirmed', desc: 'Room reserved with instant confirmation.' },
      { status: 'Pre-Arrival Ready', desc: 'Welcome team notified. Special requests logged.' },
      { status: 'Room Ready', desc: 'Your deluxe suite is prepared. Key card ready at reception.' },
      { status: 'Checked-In', desc: 'Welcome! Enjoy complimentary WiFi and breakfast from 7-10 AM.' },
      { status: 'Completed', desc: 'Checked out successfully. Receipt emailed to traveler.' }
    ],
    cab: [
      { status: 'Confirmed', desc: 'Chauffeur booking confirmed.' },
      { status: 'Driver Assigned', desc: 'Chauffeur Rajesh Kumar assigned • Toyota Innova Crysta.' },
      { status: 'Driver En Route', desc: 'Driver is 5 mins away from pickup location.' },
      { status: 'Arrived at Pickup', desc: 'Vehicle waiting at designated pickup point.' },
      { status: 'In Transit', desc: 'En route to destination. Optimal highway route chosen.' },
      { status: 'Completed', desc: 'Drop-off completed. Hope you had a smooth ride!' }
    ],
    bus: [
      { status: 'Confirmed', desc: 'Express bus seat reserved.' },
      { status: 'Bay 3 Assigned', desc: 'Bus arriving at Departure Bay 3.' },
      { status: 'Boarding Now', desc: 'Luggage stowed in lower hold. Boarding active.' },
      { status: 'In Transit', desc: 'Scenic route in progress. Next rest stop in 45m.' },
      { status: 'Completed', desc: 'Arrived at terminus. Trip concluded.' }
    ]
  };

  /**
   * Determine if a booking is categorized as Upcoming vs Past
   */
  function isBookingUpcoming(booking) {
    if (booking.status === 'Cancelled' || booking.status === 'Completed') {
      return false;
    }
    // Check date if possible
    if (booking.date) {
      const today = new Date().toISOString().split('T')[0];
      const bDate = booking.date.split(' to ')[0].trim();
      // If date is valid and strictly before today, it's past
      if (bDate && bDate < today && booking.status !== 'Boarding Now' && booking.status !== 'In Transit') {
        return false;
      }
    }
    return true;
  }

  /**
   * Initialize on DOM Ready
   */
  function init() {
    renderBookings();
    updateMetrics();
    initSimulation();
    initNotificationCenter();
    setupEventListeners();

    // Check if URL specifies opening notifications (?notif=1)
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('notif') === '1') {
      toggleNotificationDropdown(true);
    }
  }

  /**
   * Set up event listeners for inputs and controls
   */
  function setupEventListeners() {
    // Search input listener
    const searchInput = document.getElementById('booking-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value.trim().toLowerCase();
        renderBookings();
      });
    }

    // Close notification dropdown when clicking outside
    document.addEventListener('click', (e) => {
      const dropdown = document.getElementById('notification-dropdown');
      const toggleBtn = document.getElementById('nav-notif-toggle');
      if (dropdown && dropdown.classList.contains('active')) {
        if (!dropdown.contains(e.target) && (!toggleBtn || !toggleBtn.contains(e.target))) {
          dropdown.classList.remove('active');
        }
      }
    });

    // Close modals on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeTicketModal();
        closeModifyModal();
        closeCancelModal();
      }
    });
  }

  /**
   * Update top Hero metrics counters
   */
  function updateMetrics() {
    const allBookings = WanderStorage.getBookings();
    const upcoming = allBookings.filter(b => isBookingUpcoming(b));
    const activeAlerts = allBookings.filter(b => b.status === 'Boarding Now' || b.status.includes('Delayed') || b.status.includes('Open'));
    const unreadNotifs = WanderStorage.getUnreadNotificationsCount();

    const elTotal = document.getElementById('metric-total-bookings');
    const elUpcoming = document.getElementById('metric-upcoming-count');
    const elAlerts = document.getElementById('metric-live-alerts');
    const elNotifs = document.getElementById('metric-unread-notifs');

    if (elTotal) elTotal.textContent = allBookings.length;
    if (elUpcoming) elUpcoming.textContent = upcoming.length;
    if (elAlerts) elAlerts.textContent = activeAlerts.length;
    if (elNotifs) elNotifs.textContent = unreadNotifs;
  }

  /**
   * Main render function for bookings stream
   */
  function renderBookings() {
    const container = document.getElementById('bookings-container');
    if (!container) return;

    let bookings = WanderStorage.getBookings();

    // Update Category Pills counts
    updateFilterCounts(bookings);

    // Filter by Category
    if (currentCategory !== 'all') {
      bookings = bookings.filter(b => b.category === currentCategory);
    }

    // Filter by Search Query
    if (searchQuery) {
      bookings = bookings.filter(b => {
        const text = `${b.title} ${b.carrier} ${b.route} ${b.pnr} ${b.passenger} ${b.serviceNumber} ${b.status}`.toLowerCase();
        return text.includes(searchQuery);
      });
    }

    // Segregate into Upcoming & Past
    const upcomingList = bookings.filter(b => isBookingUpcoming(b));
    const pastList = bookings.filter(b => !isBookingUpcoming(b));

    // Handle Active Tab Filtering
    if (currentFilterTab === 'upcoming') {
      renderSingleGroup(container, 'Upcoming Expeditions & Transit', upcomingList, true);
    } else if (currentFilterTab === 'past') {
      renderSingleGroup(container, 'Past Journeys & Concluded Bookings', pastList, false);
    } else if (currentFilterTab === 'cancelled') {
      const cancelledList = bookings.filter(b => b.status === 'Cancelled');
      renderSingleGroup(container, 'Cancelled Reservations', cancelledList, false);
    } else {
      // Tab is 'all' -> Render both groups with headers!
      let html = '';

      if (upcomingList.length > 0) {
        html += `
          <section class="booking-group-section">
            <div class="booking-group-header">
              <div class="booking-group-title">
                <span>📅 Upcoming Expeditions & Transit</span>
                <span class="tab-badge">${upcomingList.length}</span>
              </div>
              <span class="form-hint">Confirmed & Live Tracked Journeys</span>
            </div>
            <div class="booking-cards-list">
              ${upcomingList.map(b => buildBookingCardHtml(b)).join('')}
            </div>
          </section>
        `;
      }

      if (pastList.length > 0) {
        html += `
          <section class="booking-group-section">
            <div class="booking-group-header">
              <div class="booking-group-title">
                <span>📜 Past Journeys & History</span>
                <span class="tab-badge">${pastList.length}</span>
              </div>
              <span class="form-hint">Completed & Cancelled Bookings</span>
            </div>
            <div class="booking-cards-list">
              ${pastList.map(b => buildBookingCardHtml(b)).join('')}
            </div>
          </section>
        `;
      }

      if (upcomingList.length === 0 && pastList.length === 0) {
        html = buildEmptyStateHtml();
      }

      container.innerHTML = html;
    }

    updateMetrics();
  }

  /**
   * Helper to render a single group when a tab is selected
   */
  function renderSingleGroup(container, groupTitle, list, isUpcoming) {
    if (list.length === 0) {
      container.innerHTML = buildEmptyStateHtml();
      return;
    }

    container.innerHTML = `
      <section class="booking-group-section">
        <div class="booking-group-header">
          <div class="booking-group-title">
            <span>${groupTitle}</span>
            <span class="tab-badge">${list.length}</span>
          </div>
          <span class="form-hint">${isUpcoming ? 'Real-time updates enabled' : 'Archived records'}</span>
        </div>
        <div class="booking-cards-list">
          ${list.map(b => buildBookingCardHtml(b)).join('')}
        </div>
      </section>
    `;
  }

  /**
   * Generate HTML for an individual Booking Card
   */
  function buildBookingCardHtml(booking) {
    const meta = CATEGORY_META[booking.category] || { icon: '🎟️', label: 'Booking', class: 'mode-flight' };
    const statusClass = getStatusBadgeClass(booking.status);
    const isCancelled = booking.status === 'Cancelled';
    const isCompleted = booking.status === 'Completed';

    return `
      <article class="my-booking-card ${isCancelled ? 'card-cancelled' : ''}" id="booking-card-${booking.id}">
        <!-- Category Icon -->
        <div class="my-booking-icon-box ${meta.class}" title="${meta.label}">
          ${meta.icon}
        </div>

        <!-- Card Main Info -->
        <div class="booking-card-main">
          <div class="booking-card-top-row">
            <span class="booking-pnr-pill">
              PNR: <strong>${booking.pnr}</strong>
              <button type="button" class="pnr-copy-btn" onclick="copyPnr('${booking.pnr}')" title="Copy PNR">📋</button>
            </span>

            <span class="booking-status-badge ${statusClass}">
              ${getStatusIcon(booking.status)} ${booking.status}
            </span>

            <span class="badge badge-neutral" style="font-size: 0.7rem; text-transform: uppercase;">
              ${meta.label}
            </span>

            ${booking.tripId && WanderStorage.getTripById(booking.tripId) ? `
              <a href="trip-hub.html" onclick="WanderStorage.setActiveTrip('${booking.tripId}')" class="badge badge-primary" style="text-decoration: none; font-size: 0.7rem;" title="Linked Expedition">
                🗺️ ${WanderStorage.getTripById(booking.tripId).title}
              </a>
            ` : ''}
          </div>

          <h3 class="booking-card-title">
            ${booking.title}
          </h3>

          <div class="booking-carrier-sub">
            <strong>${booking.carrier}</strong> • ${booking.serviceNumber || ''} • <span style="color: var(--text-main); font-weight: var(--font-semibold);">${booking.route}</span>
          </div>

          <div class="booking-meta-grid">
            <span class="meta-chip">📅 <strong>Date:</strong> ${booking.date}</span>
            <span class="meta-chip">⏱️ <strong>Time:</strong> ${booking.time}</span>
            <span class="meta-chip">💺 <strong>Details:</strong> ${booking.seatDetails || 'Confirmed'}</span>
            <span class="meta-chip">👤 <strong>Traveler:</strong> ${booking.passenger || 'Ayush Sharma'}</span>
          </div>

          <!-- Active Journey Stepper Tracker -->
          ${!isCancelled ? buildStepperHtml(booking) : ''}
        </div>

        <!-- Actions & Pricing -->
        <div class="booking-card-actions">
          <div class="booking-price-tag">
            <div class="booking-price-val">${WanderStorage.formatINR(booking.price)}</div>
            <div class="booking-price-sub">Total Paid (Tax incl.)</div>
          </div>

          <div class="booking-buttons-group">
            <button type="button" class="btn btn-primary btn-sm btn-ticket" onclick="openTicketModal('${booking.id}')">
              🎟️ View Ticket
            </button>

            ${booking.category === 'train' ? `
              <a href="booking-trains.html?pnr=${booking.pnr}#pnr-status-section" class="btn btn-outline btn-sm" style="color: var(--primary-color); border-color: var(--primary-color); text-decoration: none;" title="Check Live IRCTC PNR Status">
                🔍 PNR Status
              </a>
            ` : ''}

            ${!isCancelled && !isCompleted ? `
              <div style="display: flex; gap: 6px;">
                <button type="button" class="btn btn-outline btn-sm" onclick="openModifyModal('${booking.id}')" title="Modify traveler or seating details">
                  ✏️ Modify
                </button>
                <button type="button" class="btn btn-ghost btn-sm" style="color: var(--danger);" onclick="openCancelModal('${booking.id}')" title="Cancel booking">
                  ✕ Cancel
                </button>
              </div>
              <button type="button" class="btn btn-ghost btn-sm" style="font-size: 0.75rem; color: var(--accent-color); padding: 2px 6px;" onclick="advanceBookingStatus('${booking.id}')" title="Simulate next status for this booking">
                ⚡ Step Status
              </button>
            ` : ''}
          </div>
        </div>
      </article>
    `;
  }

  /**
   * Journey progress stepper based on current status
   */
  function buildStepperHtml(booking) {
    const status = booking.status.toLowerCase();
    const isFlightOrTrain = booking.category === 'flight' || booking.category === 'train';

    const steps = isFlightOrTrain ? [
      { label: 'Confirmed', key: 'confirmed' },
      { label: 'Check-in / Gate', key: 'checkin' },
      { label: 'Boarding', key: 'boarding' },
      { label: 'Departed', key: 'departed' },
      { label: 'Completed', key: 'completed' }
    ] : [
      { label: 'Confirmed', key: 'confirmed' },
      { label: 'Assigned', key: 'assigned' },
      { label: 'En Route', key: 'route' },
      { label: 'Completed', key: 'completed' }
    ];

    let currentStepIdx = 0;
    if (status.includes('delay')) {
      currentStepIdx = 1;
    } else if (status.includes('gate') || status.includes('track') || status.includes('check-in') || status.includes('ready') || status.includes('assigned')) {
      currentStepIdx = 1;
    } else if (status.includes('board') || status.includes('pickup') || status.includes('checked-in')) {
      currentStepIdx = 2;
    } else if (status.includes('depart') || status.includes('transit') || status.includes('flight')) {
      currentStepIdx = 3;
    } else if (status.includes('complete') || status.includes('landed') || status.includes('arrived')) {
      currentStepIdx = steps.length - 1;
    }

    return `
      <div class="card-stepper-wrap">
        <div class="stepper-steps">
          ${steps.map((step, idx) => {
            let stateClass = '';
            if (idx < currentStepIdx) stateClass = 'completed';
            else if (idx === currentStepIdx) stateClass = status.includes('delay') ? 'delayed' : 'active';
            
            return `
              <div class="step-node ${stateClass}">
                <div class="step-circle">${idx < currentStepIdx ? '✓' : (idx + 1)}</div>
                <span class="step-label">${step.label}</span>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }

  /**
   * Empty state placeholder
   */
  function buildEmptyStateHtml() {
    return `
      <div class="empty-state">
        <div class="empty-state-icon">🎟️</div>
        <h3>No Bookings Found</h3>
        <p style="margin: var(--space-2) 0 var(--space-6); color: var(--text-muted); max-width: 480px; margin-inline: auto;">
          ${searchQuery ? `No reservations matching "${searchQuery}". Try clearing search filters.` : `You don't have any bookings in this section yet.`}
        </p>
        <div style="display: flex; gap: var(--space-3); justify-content: center;">
          <a href="booking-flights.html" class="btn btn-primary btn-sm">Book a Flight</a>
          <a href="booking-trains.html" class="btn btn-outline btn-sm">Book a Train</a>
          <button type="button" class="btn btn-ghost btn-sm" onclick="WanderStorage.resetDefaults()">Restore Demo Data</button>
        </div>
      </div>
    `;
  }

  /**
   * Get CSS class for status badges
   */
  function getStatusBadgeClass(status) {
    const s = (status || '').toLowerCase();
    if (s.includes('delay')) return 'badge-status-delayed';
    if (s.includes('board')) return 'badge-status-boarding';
    if (s.includes('gate') || s.includes('track') || s.includes('bay')) return 'badge-status-gate';
    if (s.includes('check-in') || s.includes('ready')) return 'badge-status-checkin';
    if (s.includes('depart') || s.includes('transit') || s.includes('en route')) return 'badge-status-transit';
    if (s.includes('cancel')) return 'badge-status-cancelled';
    if (s.includes('complete') || s.includes('landed') || s.includes('arrived')) return 'badge-status-completed';
    return 'badge-status-confirmed';
  }

  /**
   * Helper icon for status
   */
  function getStatusIcon(status) {
    const s = (status || '').toLowerCase();
    if (s.includes('delay')) return '⏳';
    if (s.includes('board')) return '🚪';
    if (s.includes('gate') || s.includes('track')) return '📍';
    if (s.includes('depart') || s.includes('transit')) return '🚀';
    if (s.includes('cancel')) return '✕';
    if (s.includes('complete')) return '✓';
    return '●';
  }

  /**
   * Update category pills count badges
   */
  function updateFilterCounts(allBookings) {
    const upcomingCount = allBookings.filter(b => isBookingUpcoming(b)).length;
    const pastCount = allBookings.filter(b => !isBookingUpcoming(b)).length;
    const cancelledCount = allBookings.filter(b => b.status === 'Cancelled').length;

    const elAll = document.getElementById('count-tab-all');
    const elUp = document.getElementById('count-tab-upcoming');
    const elPast = document.getElementById('count-tab-past');
    const elCan = document.getElementById('count-tab-cancelled');

    if (elAll) elAll.textContent = allBookings.length;
    if (elUp) elUp.textContent = upcomingCount;
    if (elPast) elPast.textContent = pastCount;
    if (elCan) elCan.textContent = cancelledCount;

    // Mode pills
    ['flight', 'train', 'bus', 'cab', 'hotel'].forEach(mode => {
      const count = allBookings.filter(b => b.category === mode).length;
      const el = document.getElementById(`count-mode-${mode}`);
      if (el) el.textContent = count;
    });
  }

  // ==========================================================================
  // REAL-TIME STATUS SIMULATION ENGINE
  // ==========================================================================

  /**
   * Initialize automated live tracking simulation
   */
  function initSimulation() {
    startSimulationTimer();
    updateSimulationUiState();
  }

  function startSimulationTimer() {
    if (simulationIntervalId) clearInterval(simulationIntervalId);
    if (!isSimulationRunning) return;

    simulationIntervalId = setInterval(() => {
      triggerRandomStatusUpdate();
    }, simulationSpeedMs);
  }

  function toggleSimulationPlayPause() {
    isSimulationRunning = !isSimulationRunning;
    if (isSimulationRunning) {
      startSimulationTimer();
      showToast({
        type: 'status',
        title: 'Simulation Resumed',
        message: `Real-time tracking engine is now polling for travel updates every ${simulationSpeedMs / 1000}s.`
      });
    } else {
      if (simulationIntervalId) clearInterval(simulationIntervalId);
      simulationIntervalId = null;
      showToast({
        type: 'status',
        title: 'Simulation Paused',
        message: 'Live background status progression has been paused. Use manual triggers anytime.'
      });
    }
    updateSimulationUiState();
  }

  function setSimulationSpeed(newSpeedMs) {
    simulationSpeedMs = parseInt(newSpeedMs, 10);
    if (isSimulationRunning) {
      startSimulationTimer();
    }
    showToast({
      type: 'status',
      title: 'Poll Interval Adjusted',
      message: `Status simulation interval set to ${simulationSpeedMs / 1000} seconds.`
    });
  }

  function updateSimulationUiState() {
    const pulseDot = document.getElementById('sim-pulse-dot');
    const playBtn = document.getElementById('btn-sim-toggle');
    const statusText = document.getElementById('sim-status-text');

    if (pulseDot) {
      if (isSimulationRunning) {
        pulseDot.classList.remove('paused');
      } else {
        pulseDot.classList.add('paused');
      }
    }

    if (playBtn) {
      playBtn.innerHTML = isSimulationRunning ? '⏸ Pause' : '▶ Resume';
      playBtn.className = isSimulationRunning ? 'btn btn-outline btn-sm' : 'btn btn-primary btn-sm';
    }

    if (statusText) {
      statusText.textContent = isSimulationRunning
        ? `Real-Time Tracking: Active (${simulationSpeedMs / 1000}s updates)`
        : 'Real-Time Tracking: Paused (Manual Mode)';
    }
  }

  /**
   * Advance a specific booking or pick a random active booking
   */
  function advanceBookingStatus(bookingId) {
    const booking = WanderStorage.getBookingById(bookingId);
    if (!booking) return;
    executeStatusStep(booking);
  }

  function triggerRandomStatusUpdate() {
    const allBookings = WanderStorage.getBookings();
    // Eligible bookings: upcoming and not cancelled
    const eligible = allBookings.filter(b => b.status !== 'Cancelled' && b.status !== 'Completed');

    if (eligible.length === 0) {
      // If all completed or cancelled, pick any booking to refresh or create simulated delay
      if (allBookings.length > 0) {
        const fallback = allBookings[Math.floor(Math.random() * allBookings.length)];
        fallback.status = 'Confirmed';
        WanderStorage.updateBooking(fallback.id, { status: 'Confirmed' });
        renderBookings();
      }
      return;
    }

    // Pick random eligible booking
    const randomBooking = eligible[Math.floor(Math.random() * eligible.length)];
    executeStatusStep(randomBooking);
  }

  /**
   * Execute the status transition for a booking
   */
  function executeStatusStep(booking) {
    const categoryFlow = STATUS_FLOWS[booking.category] || STATUS_FLOWS.flight;
    const currentIdx = categoryFlow.findIndex(step => step.status.toLowerCase() === booking.status.toLowerCase());

    let nextStep;
    if (currentIdx === -1 || currentIdx >= categoryFlow.length - 1) {
      // Loop back or reset to confirmed
      nextStep = categoryFlow[0];
    } else {
      nextStep = categoryFlow[currentIdx + 1];
    }

    // Update in localStorage
    WanderStorage.updateBooking(booking.id, { status: nextStep.status });

    // Format notification message
    const notifTitle = `${CATEGORY_META[booking.category].label} Status: ${nextStep.status}`;
    const notifMsg = `${booking.serviceNumber || booking.title} (${booking.route}): ${nextStep.desc}`;

    // Add In-App Notification to localStorage
    WanderStorage.addNotification({
      type: 'status_change',
      title: notifTitle,
      message: notifMsg,
      bookingId: booking.id,
      timestamp: new Date().toISOString()
    });

    // Pop Rich In-App Toast
    showToast({
      type: 'status',
      title: notifTitle,
      message: notifMsg,
      bookingId: booking.id
    });

    // Re-render UI
    renderBookings();

    // Visual Flash Animation on the updated card
    const cardEl = document.getElementById(`booking-card-${booking.id}`);
    if (cardEl) {
      cardEl.classList.remove('status-updated-flash');
      void cardEl.offsetWidth; // Trigger reflow
      cardEl.classList.add('status-updated-flash');
    }
  }

  /**
   * Test trigger for Upcoming Travel Reminder
   */
  function triggerUpcomingReminder() {
    const allBookings = WanderStorage.getBookings();
    const upcoming = allBookings.filter(b => isBookingUpcoming(b));
    const target = upcoming.length > 0 ? upcoming[0] : allBookings[0];

    if (!target) return;

    const notifTitle = `Upcoming Reminder: ${target.carrier || target.title}`;
    const notifMsg = `Your journey on ${target.date} (${target.route}) departs soon. Digital pass ready in My Bookings!`;

    WanderStorage.addNotification({
      type: 'upcoming_reminder',
      title: notifTitle,
      message: notifMsg,
      bookingId: target.id,
      timestamp: new Date().toISOString()
    });

    showToast({
      type: 'reminder',
      title: notifTitle,
      message: notifMsg,
      bookingId: target.id
    });

    renderNotificationsDropdown();
  }

  // ==========================================================================
  // IN-APP NOTIFICATION SYSTEM & TOASTS
  // ==========================================================================

  function initNotificationCenter() {
    WanderStorage.syncHeaderNotifications();
    renderNotificationsDropdown();
  }

  /**
   * Render notifications list inside dropdown
   */
  function renderNotificationsDropdown() {
    const listContainer = document.getElementById('notif-list-container');
    if (!listContainer) return;

    let notifs = WanderStorage.getNotifications();
    const unreadCount = WanderStorage.getUnreadNotificationsCount();

    // Update unread count badges in dropdown
    const countBadge = document.getElementById('notif-dropdown-unread-count');
    if (countBadge) {
      countBadge.textContent = `${unreadCount} unread`;
      countBadge.style.display = unreadCount > 0 ? 'inline-block' : 'none';
    }

    // Filter by notification tab
    if (activeNotificationTab === 'status') {
      notifs = notifs.filter(n => n.type === 'status_change');
    } else if (activeNotificationTab === 'bookings') {
      notifs = notifs.filter(n => n.type === 'booking_confirmed' || n.type === 'booking_cancelled' || n.type === 'booking_modified');
    } else if (activeNotificationTab === 'reminders') {
      notifs = notifs.filter(n => n.type === 'upcoming_reminder');
    }

    if (notifs.length === 0) {
      listContainer.innerHTML = `
        <div class="notif-empty">
          <div class="notif-empty-icon">🔔</div>
          <strong>No alerts in this view</strong>
          <p style="font-size: var(--text-xs); color: var(--text-subtle); margin-top: 4px;">You're fully up to date with your travel schedule.</p>
        </div>
      `;
      return;
    }

    listContainer.innerHTML = notifs.map(n => {
      let iconClass = 'notif-icon-status';
      let iconSymbol = '⚡';
      if (n.type === 'booking_confirmed') {
        iconClass = 'notif-icon-booking';
        iconSymbol = '🎟️';
      } else if (n.type === 'upcoming_reminder') {
        iconClass = 'notif-icon-reminder';
        iconSymbol = '⏰';
      } else if (n.type === 'booking_cancelled') {
        iconClass = 'notif-icon-cancel';
        iconSymbol = '✕';
      }

      const relativeTime = getRelativeTimeString(n.timestamp);

      return `
        <div class="notif-item ${!n.read ? 'unread' : ''}" onclick="onNotificationClick('${n.id}', '${n.bookingId || ''}')">
          <div class="notif-icon ${iconClass}">
            ${iconSymbol}
          </div>
          <div class="notif-content">
            <div class="notif-title">
              <span>${n.title}</span>
              <span class="notif-time">${relativeTime}</span>
            </div>
            <div class="notif-message">${n.message}</div>
            ${n.bookingId ? `
              <span class="notif-action-link">
                View Travel Details &rarr;
              </span>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');
  }

  function toggleNotificationDropdown(forceOpen) {
    const dropdown = document.getElementById('notification-dropdown');
    if (!dropdown) return;

    if (forceOpen === true) {
      dropdown.classList.add('active');
    } else {
      dropdown.classList.toggle('active');
    }

    if (dropdown.classList.contains('active')) {
      renderNotificationsDropdown();
    }
  }

  function setNotificationTab(tabName, btnEl) {
    activeNotificationTab = tabName;
    document.querySelectorAll('.notif-tab-btn').forEach(btn => btn.classList.remove('active'));
    if (btnEl) btnEl.classList.add('active');
    renderNotificationsDropdown();
  }

  function onNotificationClick(notifId, bookingId) {
    WanderStorage.markNotificationRead(notifId);
    renderNotificationsDropdown();

    if (bookingId) {
      toggleNotificationDropdown(false);
      openTicketModal(bookingId);
    }
  }

  function markAllNotificationsRead() {
    WanderStorage.markAllNotificationsRead();
    renderNotificationsDropdown();
    showToast({
      type: 'status',
      title: 'Marked as Read',
      message: 'All in-app alerts have been marked as read.'
    });
  }

  function clearAllNotifications() {
    if (confirm('Clear all notification history?')) {
      WanderStorage.clearNotifications();
      renderNotificationsDropdown();
      showToast({
        type: 'status',
        title: 'Notifications Cleared',
        message: 'Your notification list has been cleared.'
      });
    }
  }

  /**
   * Floating Toast Notification
   */
  function showToast({ type = 'status', title, message, bookingId = null, duration = 5000 }) {
    const toastContainer = document.getElementById('toast-container');
    if (!toastContainer) return;

    let toastClass = 'toast-status';
    let iconSymbol = '⚡';
    if (type === 'confirmed') {
      toastClass = 'toast-confirmed';
      iconSymbol = '✓';
    } else if (type === 'reminder') {
      toastClass = 'toast-reminder';
      iconSymbol = '⏰';
    } else if (type === 'cancel') {
      toastClass = 'toast-cancel';
      iconSymbol = '✕';
    }

    const toast = document.createElement('div');
    toast.className = `toast ${toastClass}`;
    toast.innerHTML = `
      <div class="toast-icon-wrap" style="background: var(--bg-subtle);">
        ${iconSymbol}
      </div>
      <div class="toast-body">
        <div class="toast-header-row">
          <span class="toast-title">${title}</span>
          <span class="toast-time">Just now</span>
        </div>
        <div class="toast-text">${message}</div>
        ${bookingId ? `
          <button type="button" class="btn btn-ghost btn-sm" style="font-size: 0.72rem; padding: 2px 0; color: var(--primary-color); margin-top: 4px;" onclick="openTicketModal('${bookingId}')">
            View Ticket &rarr;
          </button>
        ` : ''}
      </div>
      <button type="button" class="toast-close-btn" aria-label="Dismiss">&times;</button>
      <div class="toast-progress"></div>
    `;

    toastContainer.prepend(toast);

    const removeToast = () => {
      toast.classList.add('toast-hiding');
      setTimeout(() => {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 300);
    };

    // Close on button click
    const closeBtn = toast.querySelector('.toast-close-btn');
    if (closeBtn) closeBtn.addEventListener('click', removeToast);

    // Auto dismiss
    setTimeout(removeToast, duration);
  }

  function getRelativeTimeString(isoDateString) {
    if (!isoDateString) return 'Just now';
    const seconds = Math.floor((Date.now() - new Date(isoDateString).getTime()) / 1000);
    if (seconds < 60) return 'Just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  }

  // ==========================================================================
  // DIGITAL E-TICKET & BOARDING PASS MODAL
  // ==========================================================================

  function openTicketModal(bookingId) {
    const booking = WanderStorage.getBookingById(bookingId);
    if (!booking) return;

    const modal = document.getElementById('ticket-modal');
    const container = document.getElementById('ticket-modal-container');
    if (!modal || !container) return;

    const meta = CATEGORY_META[booking.category] || { icon: '✈', label: 'Transit Pass' };
    const statusClass = getStatusBadgeClass(booking.status);

    // Parse route cities and codes
    const routeParts = (booking.route || '').split('→').map(s => s.trim());
    const origin = routeParts[0] || 'Departure';
    const destination = routeParts[1] || 'Arrival';

    const originCode = origin.match(/\b([A-Z]{3})\b/) ? origin.match(/\b([A-Z]{3})\b/)[1] : origin.slice(0, 3).toUpperCase();
    const destCode = destination.match(/\b([A-Z]{3})\b/) ? destination.match(/\b([A-Z]{3})\b/)[1] : destination.slice(0, 3).toUpperCase();

    container.innerHTML = `
      <div class="ticket-header">
        <div class="ticket-header-brand">
          <span>${meta.icon}</span>
          <span>WanderWise Boarding Pass</span>
        </div>
        <div>
          <span class="booking-status-badge ${statusClass}">
            ${getStatusIcon(booking.status)} ${booking.status}
          </span>
        </div>
      </div>

      <div class="ticket-body">
        <!-- Route Banner -->
        <div class="ticket-route-banner">
          <div class="ticket-city-block">
            <span class="ticket-code">${originCode}</span>
            <span class="ticket-city">${origin}</span>
          </div>

          <div class="ticket-flight-arrow">
            <span>✈</span>
            <span style="font-size: 10px; font-weight: var(--font-bold); color: var(--text-subtle);">NON-STOP</span>
          </div>

          <div class="ticket-city-block" style="text-align: right;">
            <span class="ticket-code">${destCode}</span>
            <span class="ticket-city">${destination}</span>
          </div>
        </div>

        <!-- Ticket Info Matrix -->
        <div class="ticket-info-grid">
          <div class="ticket-info-cell">
            <span class="ticket-cell-label">Passenger Name</span>
            <span class="ticket-cell-val">${booking.passenger || 'Ayush Sharma'}</span>
          </div>
          <div class="ticket-info-cell">
            <span class="ticket-cell-label">Carrier & Service</span>
            <span class="ticket-cell-val">${booking.carrier} (${booking.serviceNumber || 'WW'})</span>
          </div>
          <div class="ticket-info-cell">
            <span class="ticket-cell-label">Booking Reference (PNR)</span>
            <span class="ticket-cell-val" style="font-family: monospace; color: var(--primary-color);">
              ${booking.pnr}
              ${booking.category === 'train' ? `
                <a href="booking-trains.html?pnr=${booking.pnr}#pnr-status-section" style="font-size: 11px; margin-left: 6px; color: var(--accent-color); font-weight: normal; text-decoration: underline;">
                  Check PNR Status ↗
                </a>
              ` : ''}
            </span>
          </div>

          <div class="ticket-info-cell">
            <span class="ticket-cell-label">Travel Date</span>
            <span class="ticket-cell-val">${booking.date}</span>
          </div>
          <div class="ticket-info-cell">
            <span class="ticket-cell-label">Boarding / Departure</span>
            <span class="ticket-cell-val">${booking.time}</span>
          </div>
          <div class="ticket-info-cell">
            <span class="ticket-cell-label">Seat / Accommodation</span>
            <span class="ticket-cell-val">${booking.seatDetails || 'Seat Assigned'}</span>
          </div>

          <div class="ticket-info-cell">
            <span class="ticket-cell-label">Class / Fare Tier</span>
            <span class="ticket-cell-val">Standard Flex</span>
          </div>
          <div class="ticket-info-cell">
            <span class="ticket-cell-label">Gate / Platform</span>
            <span class="ticket-cell-val" style="color: var(--accent-color);">Gate B14 / Track 14</span>
          </div>
          <div class="ticket-info-cell">
            <span class="ticket-cell-label">Total Fare</span>
            <span class="ticket-cell-val">${WanderStorage.formatINR(booking.price)}</span>
          </div>
        </div>

        <!-- Perforated separator -->
        <div class="ticket-perforation">
          <div class="ticket-perforation-line"></div>
        </div>

        <!-- Barcode & QR code section -->
        <div class="ticket-barcode-section">
          <div class="barcode-strip"></div>
          <div class="qr-placeholder" title="Verified electronic ticket">
            📱
          </div>
        </div>
      </div>

      <div class="ticket-modal-footer">
        <span style="font-size: var(--text-xs); color: var(--text-subtle);">
          Official WanderWise Smart Document • ID: ${booking.id}
        </span>
        <div style="display: flex; gap: var(--space-2);">
          <button type="button" class="btn btn-outline btn-sm" onclick="window.print()">
            🖨️ Print Pass
          </button>
          <button type="button" class="btn btn-primary btn-sm" onclick="closeTicketModal()">
            Done
          </button>
        </div>
      </div>
    `;

    modal.classList.add('active');
  }

  function closeTicketModal() {
    const modal = document.getElementById('ticket-modal');
    if (modal) modal.classList.remove('active');
  }

  // ==========================================================================
  // MODIFY BOOKING WORKFLOW
  // ==========================================================================

  let modifyingBookingId = null;

  function openModifyModal(bookingId) {
    const booking = WanderStorage.getBookingById(bookingId);
    if (!booking) return;

    modifyingBookingId = bookingId;

    document.getElementById('mod-pnr').textContent = booking.pnr;
    document.getElementById('mod-title').textContent = booking.title;
    document.getElementById('mod-passenger').value = booking.passenger || 'Ayush Sharma';
    document.getElementById('mod-seat').value = booking.seatDetails || '';
    document.getElementById('mod-date').value = booking.date ? booking.date.split(' to ')[0] : '2026-10-15';
    document.getElementById('mod-notes').value = booking.notes || '';

    const modal = document.getElementById('modify-modal');
    if (modal) modal.classList.add('active');
  }

  function closeModifyModal() {
    modifyingBookingId = null;
    const modal = document.getElementById('modify-modal');
    if (modal) modal.classList.remove('active');
  }

  function saveModifiedBooking() {
    if (!modifyingBookingId) return;

    const passenger = document.getElementById('mod-passenger').value.trim();
    const seat = document.getElementById('mod-seat').value.trim();
    const date = document.getElementById('mod-date').value;
    const notes = document.getElementById('mod-notes').value.trim();

    if (!passenger) {
      alert('Please enter a valid passenger name.');
      return;
    }

    const updated = WanderStorage.updateBooking(modifyingBookingId, {
      passenger: passenger,
      seatDetails: seat || 'Confirmed',
      date: date || '2026-10-15',
      notes: notes
    });

    closeModifyModal();

    if (updated) {
      WanderStorage.addNotification({
        type: 'booking_modified',
        title: 'Booking Modified',
        message: `Reservation ${updated.pnr} details updated (Traveler: ${updated.passenger}, Seat: ${updated.seatDetails}).`,
        bookingId: updated.id,
        timestamp: new Date().toISOString()
      });

      showToast({
        type: 'confirmed',
        title: 'Booking Modified Successfully',
        message: `Details updated for reservation PNR: ${updated.pnr}.`,
        bookingId: updated.id
      });

      renderBookings();
    }
  }

  // ==========================================================================
  // CANCEL BOOKING WORKFLOW
  // ==========================================================================

  let cancellingBookingId = null;

  function openCancelModal(bookingId) {
    const booking = WanderStorage.getBookingById(bookingId);
    if (!booking) return;

    cancellingBookingId = bookingId;

    document.getElementById('cancel-pnr').textContent = booking.pnr;
    document.getElementById('cancel-item-title').textContent = `${booking.carrier} - ${booking.title}`;
    document.getElementById('cancel-refund-amt').textContent = `$${booking.price}.00 USD`;

    const modal = document.getElementById('cancel-modal');
    if (modal) modal.classList.add('active');
  }

  function closeCancelModal() {
    cancellingBookingId = null;
    const modal = document.getElementById('cancel-modal');
    if (modal) modal.classList.remove('active');
  }

  function confirmCancellation() {
    if (!cancellingBookingId) return;

    const booking = WanderStorage.getBookingById(cancellingBookingId);
    const success = WanderStorage.cancelBooking(cancellingBookingId);
    closeCancelModal();

    if (success) {
      showToast({
        type: 'cancel',
        title: 'Reservation Cancelled',
        message: `Booking ${booking ? booking.pnr : ''} has been cancelled. Full refund initiated.`,
        bookingId: cancellingBookingId
      });

      renderBookings();
    }
  }

  // ==========================================================================
  // TAB & CATEGORY FILTER ACTIONS
  // ==========================================================================

  function setFilterTab(tabName, btnEl) {
    currentFilterTab = tabName;
    document.querySelectorAll('.bookings-tabs .booking-tab').forEach(t => t.classList.remove('active'));
    if (btnEl) btnEl.classList.add('active');
    renderBookings();
  }

  function setCategoryFilter(category, btnEl) {
    currentCategory = category;
    document.querySelectorAll('.mode-pill').forEach(pill => pill.classList.remove('active'));
    if (btnEl) btnEl.classList.add('active');
    renderBookings();
  }

  function copyPnr(pnrText) {
    navigator.clipboard.writeText(pnrText).then(() => {
      showToast({
        type: 'confirmed',
        title: 'PNR Copied',
        message: `Booking reference ${pnrText} copied to clipboard.`
      });
    }).catch(() => {
      showToast({
        type: 'status',
        title: 'PNR Reference',
        message: `PNR: ${pnrText}`
      });
    });
  }

  // Clean up temporary test file if present
  try {
    // runtime helper
  } catch (e) {}

  // Export to window scope for onclick handlers in HTML
  window.setFilterTab = setFilterTab;
  window.setCategoryFilter = setCategoryFilter;
  window.copyPnr = copyPnr;
  window.advanceBookingStatus = advanceBookingStatus;
  window.triggerRandomStatusUpdate = triggerRandomStatusUpdate;
  window.triggerUpcomingReminder = triggerUpcomingReminder;
  window.toggleSimulationPlayPause = toggleSimulationPlayPause;
  window.setSimulationSpeed = setSimulationSpeed;
  window.openTicketModal = openTicketModal;
  window.closeTicketModal = closeTicketModal;
  window.openModifyModal = openModifyModal;
  window.closeModifyModal = closeModifyModal;
  window.saveModifiedBooking = saveModifiedBooking;
  window.openCancelModal = openCancelModal;
  window.closeCancelModal = closeCancelModal;
  window.confirmCancellation = confirmCancellation;
  window.toggleNotificationDropdown = toggleNotificationDropdown;
  window.setNotificationTab = setNotificationTab;
  window.onNotificationClick = onNotificationClick;
  window.markAllNotificationsRead = markAllNotificationsRead;
  window.clearAllNotifications = clearAllNotifications;
  window.showToast = showToast;

  // Initialize
  document.addEventListener('DOMContentLoaded', init);
})();
