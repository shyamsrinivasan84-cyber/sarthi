/**
 * WANDERWISE - ITINERARY PLANNER CONTROLLER (itinerary.js)
 * Full client-side interactive builder:
 * - Native HTML5 Drag and Drop (suggestions to timeline, timeline reordering)
 * - Auto-populated "Suggested for you" ranked by user preferences & rating
 * - "Regenerate suggestions"
 * - Haversine distance & transit time estimation
 * - Schedule conflict detection (overlaps, tight transit gaps)
 * - Must-Do vs Optional toggle
 * - Custom places/notes, editing, deletion
 * - Leaflet interactive route map with numbered waypoints
 * - Auto-save to localStorage
 * - Read-only share link generation and view mode
 */

(function () {
  // Destination Coordinates Catalog
    const DEST_COORDS = {
    "dest-jaipur": { lat: 26.9124, lng: 75.7873, name: "Jaipur, Rajasthan" },
    "dest-udaipur": { lat: 24.5854, lng: 73.7125, name: "Udaipur, Rajasthan" },
    "dest-kerala": { lat: 9.4981, lng: 76.3388, name: "Munnar & Alleppey, Kerala" },
    "dest-goa": { lat: 15.2993, lng: 74.1240, name: "North & South Goa" },
    "dest-ladakh": { lat: 34.1526, lng: 77.5771, name: "Leh & Ladakh" },
    "dest-varanasi": { lat: 25.3176, lng: 82.9739, name: "Varanasi, Uttar Pradesh" },
    "dest-manali": { lat: 32.2432, lng: 77.1892, name: "Manali, Himachal Pradesh" },
    "dest-rishikesh": { lat: 30.0869, lng: 78.2676, name: "Rishikesh, Uttarakhand" },
    "dest-amritsar": { lat: 31.6340, lng: 74.8723, name: "Amritsar, Punjab" },
    "dest-darjeeling": { lat: 27.0410, lng: 88.2663, name: "Darjeeling, West Bengal" },
    "dest-meghalaya": { lat: 25.5788, lng: 91.8933, name: "Shillong, Meghalaya" },
    "dest-andaman": { lat: 11.9761, lng: 92.9876, name: "Havelock Island, Andaman" },
    "dest-hampi": { lat: 15.3350, lng: 76.4600, name: "Hampi, Karnataka" },
    "dest-mumbai": { lat: 18.9220, lng: 72.8347, name: "Mumbai, Maharashtra" },
    "dest-agra": { lat: 27.1767, lng: 78.0081, name: "Agra, Uttar Pradesh" }
  };

  // State
  let activeTrip = null;
  let tripSchedule = [];
  let currentDayNum = 1;
  let isReadOnly = false;
  let suggestionsCategory = "all";
  let suggestionsRotation = 0;
  let tripDestPlaces = [];

  // Map state
  let leafletMap = null;
  let mapMarkers = [];
  let mapPolyline = null;

  // Drag-and-drop transfer state
  let draggedActivityId = null;

  // =========================================================================
  // 1. INITIALIZATION & READ-ONLY CHECK
  // =========================================================================
  function initPlanner() {
    const urlParams = new URLSearchParams(window.location.search);
    const requestedTripId = urlParams.get("tripId");
    const viewMode = urlParams.get("mode") || urlParams.get("view");
    const isShare = urlParams.get("share");

    if (viewMode === "view" || viewMode === "readonly" || isShare === "1" || isShare === "true") {
      isReadOnly = true;
      showReadOnlyBanner();
    }

    // Retrieve active or requested trip
    if (requestedTripId) {
      activeTrip = WanderStorage.getTripById(requestedTripId);
      if (activeTrip && !isReadOnly) {
        WanderStorage.setActiveTrip(requestedTripId);
      }
    }

    if (!activeTrip) {
      activeTrip = WanderStorage.getActiveTrip();
    }

    if (!activeTrip) {
      // If no trips exist, check if user has any trips at all
      const trips = WanderStorage.getTrips();
      if (trips && trips.length > 0) {
        activeTrip = trips[0];
        WanderStorage.setActiveTrip(activeTrip.id);
      } else {
        // Show an empty state inside the workspace instead of a jarring alert
        const workspace = document.querySelector(".itinerary-workspace-grid");
        if (workspace) {
          workspace.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: var(--space-12) var(--space-4); background: white; border-radius: var(--radius-xl); border: 1px solid var(--border-color); box-shadow: var(--shadow-sm);">
              <div style="font-size: 56px; margin-bottom: var(--space-4);">🗺️</div>
              <h2 style="margin-bottom: var(--space-2);">No Active Trip Found</h2>
              <p style="color: var(--text-muted); max-width: 520px; margin: 0 auto var(--space-6) auto; font-size: var(--text-base);">
                You don't have an active trip selected yet. Explore our curated destinations or create a custom trip in your Trip Hub to build an itinerary.
              </p>
              <div style="display: flex; gap: var(--space-3); justify-content: center; flex-wrap: wrap;">
                <a href="destination.html" class="btn btn-primary">🌍 Explore Destinations</a>
                <a href="trip-hub.html" class="btn btn-outline">📋 Go to Trip Hub</a>
              </div>
            </div>
          `;
        }
        const heroTitle = document.getElementById("trip-title-heading");
        if (heroTitle) heroTitle.textContent = "No Trip Selected";
        const heroMeta = document.getElementById("trip-meta-sub");
        if (heroMeta) heroMeta.textContent = "Select or create a trip to start building your itinerary";
        return;
      }
    }

    // Load schedule
    loadTripSchedule();

    // Render components
    renderTripHero();
    renderDaysSidebar();
    renderDayActivities();
    populateSuggestions();
    initRouteMap();

    // Asynchronously load contextual sights for ANY destination
    if (window.DestinationService && activeTrip) {
      window.DestinationService.getPlacesForDestination(activeTrip.destination || activeTrip.destinationId).then(places => {
        if (places && places.length > 0) {
          tripDestPlaces = places;
          populateSuggestions();
        }
      }).catch(e => console.warn("Could not load destination places", e));
    }

    if (isReadOnly) {
      applyReadOnlyModeUI();
    }
  }

  function loadTripSchedule() {
    let schedule = WanderStorage.getItinerary(activeTrip.id);

    // If schedule is empty or has zero activities across all days, seed with real Indian sights!
    const hasActivities = schedule && schedule.some(d => d.activities && d.activities.length > 0);

    if (!schedule || schedule.length === 0 || !hasActivities) {
      if (window.MOCK_DATA && window.MOCK_DATA.sampleItineraries && window.MOCK_DATA.sampleItineraries[activeTrip.id]) {
        schedule = window.MOCK_DATA.sampleItineraries[activeTrip.id];
        WanderStorage.saveItinerary(activeTrip.id, schedule);
      } else if (WanderStorage.seedItineraryForDestination) {
        schedule = WanderStorage.seedItineraryForDestination(
          activeTrip.id, 
          activeTrip.destination || "Jaipur, Rajasthan", 
          activeTrip.daysCount || 5, 
          activeTrip.startDate
        );
      }
    }

    tripSchedule = schedule || [];
    if (currentDayNum > tripSchedule.length) currentDayNum = 1;
  }

  // =========================================================================
  // 2. HERO STRIP & CONTEXT
  // =========================================================================
  function renderTripHero() {
    const titleEl = document.getElementById("trip-title-heading");
    const metaEl = document.getElementById("trip-meta-sub");
    const badgeEl = document.getElementById("trip-badge");

    if (titleEl) titleEl.textContent = activeTrip.title;
    if (metaEl) {
      metaEl.innerHTML = `
        📍 <strong>${activeTrip.destination}</strong> &nbsp;•&nbsp; 
        🗓️ ${activeTrip.startDate || "Flexible"} to ${activeTrip.endDate || "Flexible"} &nbsp;•&nbsp; 
        👥 ${activeTrip.travelersCount || 1} Travelers &nbsp;•&nbsp; 
        💰 Budget: ${WanderStorage.formatINR(activeTrip.totalBudget || 45000)}
      `;
    }
    if (badgeEl) {
      badgeEl.textContent = activeTrip.status || "Active Plan";
    }
  }

  // Auto-Save Visual Notification
  function triggerAutoSavePulse() {
    const pill = document.getElementById("autosave-indicator");
    if (!pill) return;

    pill.className = "autosave-pill saving";
    pill.innerHTML = `<span class="autosave-dot"></span><span>Saving changes...</span>`;

    setTimeout(() => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
      pill.className = "autosave-pill saved";
      pill.innerHTML = `<span class="autosave-dot"></span><span>✓ Auto-saved at ${timeStr}</span>`;
    }, 280);
  }

  function persistChanges() {
    if (isReadOnly) return;
    WanderStorage.saveItinerary(activeTrip.id, tripSchedule);
    triggerAutoSavePulse();
    renderDaysSidebar();
    updateMapRoute();
  }

  // =========================================================================
  // 3. READ-ONLY MODE & SHARE TRIP LINK
  // =========================================================================
  function showReadOnlyBanner() {
    const existing = document.getElementById("read-only-banner");
    if (existing) return;

    const banner = document.createElement("div");
    banner.id = "read-only-banner";
    banner.className = "read-only-banner";
    banner.innerHTML = `
      <div style="display: flex; align-items: center; gap: var(--space-3);">
        <span class="badge">READ-ONLY MODE</span>
        <span>You are viewing a shared read-only itinerary. Drag-and-drop and editing are disabled.</span>
      </div>
      <button class="btn btn-secondary btn-sm" onclick="cloneSharedTripToMine()">
        📋 Save Copy to My Trips
      </button>
    `;
    document.body.prepend(banner);
  }

  function applyReadOnlyModeUI() {
    // Disable or hide edit buttons, add buttons
    const hideSelectors = [
      "#btn-add-activity-top",
      "#btn-add-activity-feed",
      "#btn-add-day",
      ".priority-toggle-btn",
      ".activity-delete-btn",
      ".activity-edit-btn",
      "#btn-regen-suggestions"
    ];
    hideSelectors.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => el.style.display = "none");
    });

    // Make all items non-draggable
    document.querySelectorAll('[draggable="true"]').forEach(el => {
      el.setAttribute("draggable", "false");
      el.style.cursor = "default";
    });
  }

  window.cloneSharedTripToMine = function () {
    const clone = WanderStorage.duplicateTrip(activeTrip.id);
    if (clone) {
      showToast(`Trip "${clone.title}" cloned! Opening editable view...`, "success");
      setTimeout(() => {
        window.location.href = `itinerary.html?tripId=${clone.id}`;
      }, 500);
    }
  };

  window.openShareModal = function () {
    const modal = document.getElementById("share-trip-modal");
    const linkInput = document.getElementById("share-trip-url");
    if (!modal || !linkInput) return;

    const shareUrl = `${window.location.origin}${window.location.pathname}?tripId=${activeTrip.id}&mode=view`;
    linkInput.value = shareUrl;
    modal.classList.add("active");
  };

  window.closeShareModal = function () {
    const modal = document.getElementById("share-trip-modal");
    if (modal) modal.classList.remove("active");
  };

  window.copyShareLink = function () {
    const linkInput = document.getElementById("share-trip-url");
    if (!linkInput) return;
    linkInput.select();
    navigator.clipboard.writeText(linkInput.value).then(() => {
      showToast("Read-only share link copied to clipboard!");
    }).catch(() => {
      document.execCommand("copy");
      showToast("Link copied!");
    });
  };

  // =========================================================================
  // 4. DAY TIMELINE TABS (LEFT SIDEBAR)
  // =========================================================================
  function renderDaysSidebar() {
    const listEl = document.getElementById("days-tabs-list");
    if (!listEl) return;

    listEl.innerHTML = tripSchedule.map(dayObj => {
      const isCur = dayObj.day === currentDayNum;
      const count = (dayObj.activities || []).length;
      return `
        <div class="itinerary-day-tab ${isCur ? 'active' : ''}" onclick="selectDay(${dayObj.day})">
          <div style="display: flex; flex-direction: column;">
            <span>Day ${dayObj.day}</span>
            <span style="font-size: 11px; color: ${isCur ? 'var(--primary-color)' : 'var(--text-muted)'};">
              ${dayObj.date || `Day ${dayObj.day}`}
            </span>
          </div>
          <span class="badge ${isCur ? 'badge-primary' : 'badge-neutral'}" style="font-size: 11px;">
            ${count} ${count === 1 ? 'stop' : 'stops'}
          </span>
        </div>
      `;
    }).join("");
  }

  window.selectDay = function (dayNum) {
    currentDayNum = dayNum;
    renderDaysSidebar();
    renderDayActivities();
    updateMapRoute();
  };

  window.addNewDay = function () {
    if (isReadOnly) return;
    const newDayNum = tripSchedule.length + 1;
    let newDateStr = `Day ${newDayNum}`;

    if (activeTrip.startDate) {
      const d = new Date(activeTrip.startDate);
      d.setDate(d.getDate() + (newDayNum - 1));
      newDateStr = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    }

    tripSchedule.push({
      day: newDayNum,
      title: `Day ${newDayNum} Adventures`,
      date: newDateStr,
      activities: []
    });

    activeTrip.daysCount = newDayNum;
    WanderStorage.saveTrip(activeTrip);
    persistChanges();
    selectDay(newDayNum);
    showToast(`Day ${newDayNum} added to schedule.`);
  };

  // =========================================================================
  // 5. HAVERSINE DISTANCE & TRANSIT ESTIMATION
  // =========================================================================
  function haversineDistance(lat1, lon1, lat2, lon2) {
    if (!lat1 || !lon1 || !lat2 || !lon2) return null;
    const R = 6371; // km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // distance in km
  }

  function estimateTravelTime(distanceKm) {
    if (distanceKm === null) return null;
    if (distanceKm <= 1.5) {
      // Walking @ 4.5 km/h
      const mins = Math.max(5, Math.round((distanceKm / 4.5) * 60));
      return {
        mode: "walk",
        icon: "🚶",
        mins: mins,
        text: `${mins} min walk (${distanceKm.toFixed(1)} km)`
      };
    } else {
      // Driving / Transit @ 30 km/h + 8 min buffer
      const mins = Math.max(10, Math.round((distanceKm / 30) * 60 + 8));
      return {
        mode: "drive",
        icon: "🚗",
        mins: mins,
        text: `${mins} min drive/transit (${distanceKm.toFixed(1)} km)`
      };
    }
  }

  // Parse time strings like "09:30 AM" or "14:00" to minutes from midnight
  function parseTimeToMinutes(timeStr) {
    if (!timeStr) return null;
    const cleaned = timeStr.trim().toUpperCase();
    const isPM = cleaned.includes("PM");
    const isAM = cleaned.includes("AM");
    const parts = cleaned.replace(/[APM]/g, "").trim().split(":");
    let hours = parseInt(parts[0], 10);
    const mins = parts[1] ? parseInt(parts[1], 10) : 0;
    if (isNaN(hours)) return null;

    if (isPM && hours < 12) hours += 12;
    if (isAM && hours === 12) hours = 0;
    return hours * 60 + mins;
  }

  // Parse duration strings like "2 hours", "90 mins", "1.5h" to minutes
  function parseDurationToMinutes(durStr) {
    if (!durStr) return 90; // default 1.5 hrs
    const lower = durStr.toLowerCase();
    if (lower.includes("hour") || lower.includes("hr") || lower.includes("h")) {
      const match = lower.match(/([0-9.]+)/);
      if (match) return Math.round(parseFloat(match[1]) * 60);
    }
    if (lower.includes("min")) {
      const match = lower.match(/([0-9]+)/);
      if (match) return parseInt(match[1], 10);
    }
    return 90;
  }

  // Format minutes from midnight back to readable "09:30 AM"
  function formatMinutesToTime(totalMins) {
    let hours = Math.floor(totalMins / 60) % 24;
    const mins = totalMins % 60;
    const ampm = hours >= 12 ? "PM" : "AM";
    hours = hours % 12;
    if (hours === 0) hours = 12;
    const formattedMins = mins < 10 ? `0${mins}` : mins;
    return `${hours}:${formattedMins} ${ampm}`;
  }

  // =========================================================================
  // 6. TIMELINE FEED & DRAG-AND-DROP REORDERING
  // =========================================================================
  function renderDayActivities() {
    const currentDayObj = tripSchedule.find(d => d.day === currentDayNum) || tripSchedule[0];
    if (!currentDayObj) return;

    const titleEl = document.getElementById("current-day-title");
    const dateEl = document.getElementById("current-day-date");
    const feed = document.getElementById("timeline-container");
    const conflictsAlertEl = document.getElementById("day-conflicts-alert");

    if (titleEl) titleEl.textContent = `Day ${currentDayObj.day}: ${currentDayObj.title || 'Exploration'}`;
    if (dateEl) dateEl.textContent = `${currentDayObj.date || ''} • ${(currentDayObj.activities || []).length} scheduled activities`;

    const activities = currentDayObj.activities || [];
    let conflictCount = 0;

    // Build timeline slots and transit connectors
    if (activities.length === 0) {
      if (conflictsAlertEl) conflictsAlertEl.style.display = "none";
      feed.innerHTML = `
        <div class="empty-state timeline-drop-target ${isReadOnly ? '' : 'droppable-zone'}" 
             ondragover="handleDragOver(event)" 
             ondragenter="handleDragEnter(event)" 
             ondragleave="handleDragLeave(event)" 
             ondrop="handleDropNewActivity(event, 0)">
          <div style="font-size: 36px; margin-bottom: var(--space-2);">📌</div>
          <h4>No activities scheduled for Day ${currentDayObj.day}</h4>
          <p style="margin: var(--space-2) 0 var(--space-4) 0;">
            ${isReadOnly 
              ? "No activities planned for this day." 
              : "Drag places from the 'Suggested for you' panel into this zone, or click '+ Add Activity' to create a custom stop."}
          </p>
          ${!isReadOnly ? `
            <button class="btn btn-outline-primary btn-sm" onclick="openAddActivityModal()">
              + Add Custom Activity
            </button>
          ` : ''}
        </div>
      `;
      return;
    }

    let feedHtml = "";

    activities.forEach((act, idx) => {
      // Transit connector from previous stop
      let transitHtml = "";
      let conflictHtml = "";

      if (idx > 0) {
        const prevAct = activities[idx - 1];
        const dist = haversineDistance(prevAct.lat, prevAct.lng, act.lat, act.lng);
        const estTransit = estimateTravelTime(dist);

        // Conflict check
        const prevStartMins = parseTimeToMinutes(prevAct.time);
        const prevDurMins = parseDurationToMinutes(prevAct.duration);
        const curStartMins = parseTimeToMinutes(act.time);

        if (prevStartMins !== null && curStartMins !== null) {
          const prevEndMins = prevStartMins + prevDurMins;
          const gap = curStartMins - prevEndMins;

          if (gap < 0) {
            // Overlap!
            conflictCount++;
            conflictHtml = `
              <div class="warning-overlap-chip" title="Schedule conflict">
                ⚠️ Overlap Warning: Starts ${Math.abs(gap)} mins before previous activity finishes (${formatMinutesToTime(prevEndMins)})
              </div>
            `;
          } else if (estTransit && gap < estTransit.mins) {
            // Insufficient transit time
            conflictCount++;
            conflictHtml = `
              <div class="warning-rush-chip" title="Tight transit gap">
                ⚠️ Tight Transit: Needs ~${estTransit.mins} mins travel, but only ${gap} mins scheduled between stops
              </div>
            `;
          }
        }

        if (estTransit) {
          transitHtml = `
            <div class="transit-connector">
              <span class="transit-chip" title="Estimated transit time based on distance">
                ${estTransit.icon} ${estTransit.text}
              </span>
            </div>
          `;
        }
      }

      const isMustDo = !!act.isMustDo;
      const draggableAttr = isReadOnly ? 'draggable="false"' : 'draggable="true"';

      feedHtml += `
        ${transitHtml}
        <div class="timeline-slot ${isMustDo ? 'is-must-do' : ''}" 
             id="slot-${act.id}"
             ${draggableAttr}
             ondragstart="handleTimelineDragStart(event, '${act.id}')"
             ondragover="handleTimelineSlotDragOver(event, ${idx})"
             ondragenter="handleTimelineSlotDragEnter(event)"
             ondragleave="handleTimelineSlotDragLeave(event)"
             ondrop="handleTimelineSlotDrop(event, ${idx})"
             onclick="focusActivityOnMap('${act.id}')"
             title="${isReadOnly ? '' : 'Drag to reorder stop'}">
          
          <!-- Waypoint Column -->
          <div class="timeline-time-col">
            <div class="timeline-step-badge ${isMustDo ? 'must-do' : ''}">
              ${idx + 1}
            </div>
            <div class="timeline-slot-time">${act.time || 'Flexible'}</div>
            <div class="timeline-slot-duration">⏳ ${act.duration || '2 hrs'}</div>
          </div>

          <!-- Body Column -->
          <div class="timeline-body-col">
            <div class="timeline-slot-header">
              <div>
                <span class="timeline-slot-title">${act.title}</span>
                <div class="timeline-slot-loc">
                  📍 ${act.location || activeTrip.destination}
                </div>
              </div>

              <!-- Must-Do vs Optional Toggle & Actions -->
              <div style="display: flex; align-items: center; gap: var(--space-2); flex-wrap: wrap;">
                ${!isReadOnly ? `
                  <button class="priority-toggle-btn" onclick="toggleMustDo(event, '${act.id}')" title="Click to toggle Must-Do priority">
                    <span class="${isMustDo ? 'must-do-badge' : 'optional-badge'}">
                      ${isMustDo ? '⭐ Must-Do' : '🌿 Optional'}
                    </span>
                  </button>
                ` : `
                  <span class="${isMustDo ? 'must-do-badge' : 'optional-badge'}">
                    ${isMustDo ? '⭐ Must-Do' : '🌿 Optional'}
                  </span>
                `}

                <span class="badge badge-info" style="font-size: 11px;">
                  ${act.category || 'Sight'}
                </span>

                ${!isReadOnly ? `
                  <button class="btn btn-ghost btn-sm activity-edit-btn" onclick="openEditActivityModal(event, '${act.id}')" title="Edit details" style="padding: 2px 6px;">
                    ✏️
                  </button>
                  <button class="btn btn-ghost btn-sm activity-delete-btn" onclick="deleteActivity(event, '${act.id}')" title="Delete stop" style="color: var(--danger); padding: 2px 6px;">
                    ✕
                  </button>
                ` : ''}
              </div>
            </div>

            ${act.notes ? `
              <div class="timeline-slot-notes">
                💡 ${act.notes}
              </div>
            ` : ''}

            ${conflictHtml}
          </div>
        </div>
      `;
    });

    // Drop target at end of list for appending
    if (!isReadOnly) {
      feedHtml += `
        <div class="timeline-drop-target droppable-zone" 
             style="padding: var(--space-4); margin-top: var(--space-2);"
             ondragover="handleDragOver(event)" 
             ondragenter="handleDragEnter(event)" 
             ondragleave="handleDragLeave(event)" 
             ondrop="handleDropNewActivity(event, ${activities.length})">
          <span>+ Drop another suggested place here to schedule</span>
        </div>
      `;
    }

    feed.innerHTML = feedHtml;

    // Render conflicts banner at the top if any
    if (conflictsAlertEl) {
      if (conflictCount > 0) {
        conflictsAlertEl.style.display = "flex";
        conflictsAlertEl.innerHTML = `
          <span>⚠️</span>
          <div>
            <strong>Schedule Advisory:</strong> ${conflictCount} timing conflict${conflictCount > 1 ? 's' : ''} detected on Day ${currentDayObj.day} (overlapping activities or insufficient travel time). Consider adjusting start times or durations.
          </div>
        `;
      } else {
        conflictsAlertEl.style.display = "none";
      }
    }
  }

  // =========================================================================
  // 7. NATIVE HTML5 DRAG & DROP HANDLERS
  // =========================================================================
  // A. Suggestion Card Drag
  window.handleSuggestionDragStart = function (e, placeId) {
    if (isReadOnly) return;
    const allPlaces = [...tripDestPlaces, ...((window.MOCK_DATA && window.MOCK_DATA.places) ? window.MOCK_DATA.places : [])];
    const place = allPlaces.find(p => p.id === placeId);
    if (!place) return;

    const payload = {
      type: "new_place",
      title: place.name,
      location: place.name + (place.subCategory ? ` (${place.subCategory})` : ""),
      category: place.category || "Attractions",
      duration: place.duration || "2 hours",
      lat: place.lat,
      lng: place.lng,
      notes: place.description || "",
      isMustDo: false
    };

    e.dataTransfer.setData("application/json", JSON.stringify(payload));
    e.dataTransfer.effectAllowed = "copy";
    e.target.classList.add("is-dragging");
  };

  window.handleSuggestionDragEnd = function (e) {
    e.target.classList.remove("is-dragging");
  };

  // B. Timeline Slot Drag (Reordering)
  window.handleTimelineDragStart = function (e, actId) {
    if (isReadOnly) return;
    draggedActivityId = actId;
    const payload = {
      type: "reorder",
      actId: actId
    };
    e.dataTransfer.setData("application/json", JSON.stringify(payload));
    e.dataTransfer.effectAllowed = "move";
    e.target.classList.add("is-dragging");
  };

  window.handleDragOver = function (e) {
    if (isReadOnly) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
  };

  window.handleDragEnter = function (e) {
    if (isReadOnly) return;
    e.preventDefault();
    const target = e.currentTarget;
    if (target) target.classList.add("is-active-drop");
  };

  window.handleDragLeave = function (e) {
    const target = e.currentTarget;
    if (target) target.classList.remove("is-active-drop");
  };

  window.handleTimelineSlotDragOver = function (e, targetIdx) {
    if (isReadOnly) return;
    e.preventDefault();
    const slot = e.currentTarget;
    const rect = slot.getBoundingClientRect();
    const relY = e.clientY - rect.top;

    slot.classList.remove("drag-over-top", "drag-over-bottom");
    if (relY < rect.height / 2) {
      slot.classList.add("drag-over-top");
    } else {
      slot.classList.add("drag-over-bottom");
    }
  };

  window.handleTimelineSlotDragEnter = function (e) {
    if (isReadOnly) return;
    e.preventDefault();
  };

  window.handleTimelineSlotDragLeave = function (e) {
    const slot = e.currentTarget;
    slot.classList.remove("drag-over-top", "drag-over-bottom");
  };

  window.handleTimelineSlotDrop = function (e, targetIdx) {
    if (isReadOnly) return;
    e.preventDefault();
    e.stopPropagation();

    const slot = e.currentTarget;
    const rect = slot.getBoundingClientRect();
    const relY = e.clientY - rect.top;
    const insertAfter = relY >= rect.height / 2;
    slot.classList.remove("drag-over-top", "drag-over-bottom");

    let finalIdx = insertAfter ? targetIdx + 1 : targetIdx;

    try {
      const dataStr = e.dataTransfer.getData("application/json");
      if (!dataStr) return;
      const data = JSON.parse(dataStr);

      const dayObj = tripSchedule.find(d => d.day === currentDayNum);
      if (!dayObj) return;

      if (data.type === "new_place") {
        insertNewActivityAt(data, finalIdx);
      } else if (data.type === "reorder") {
        reorderActivity(data.actId, finalIdx);
      }
    } catch (err) {
      console.error("Drop error", err);
    }
  };

  window.handleDropNewActivity = function (e, targetIdx) {
    if (isReadOnly) return;
    e.preventDefault();
    e.currentTarget.classList.remove("is-active-drop");

    try {
      const dataStr = e.dataTransfer.getData("application/json");
      if (!dataStr) return;
      const data = JSON.parse(dataStr);

      if (data.type === "new_place") {
        insertNewActivityAt(data, targetIdx);
      } else if (data.type === "reorder") {
        reorderActivity(data.actId, targetIdx);
      }
    } catch (err) {
      console.error("Drop error", err);
    }
  };

  function insertNewActivityAt(placeData, targetIdx) {
    const dayObj = tripSchedule.find(d => d.day === currentDayNum);
    if (!dayObj) return;
    if (!dayObj.activities) dayObj.activities = [];

    // Calculate auto-suggested start time
    let suggestedTime = "09:00 AM";
    if (dayObj.activities.length > 0) {
      const lastAct = dayObj.activities[dayObj.activities.length - 1];
      const prevMins = parseTimeToMinutes(lastAct.time) || (9 * 60);
      const prevDur = parseDurationToMinutes(lastAct.duration) || 90;
      const newMins = prevMins + prevDur + 30; // 30 min buffer
      suggestedTime = formatMinutesToTime(newMins);
    }

    const newAct = {
      id: "act-" + Date.now(),
      title: placeData.title,
      time: suggestedTime,
      duration: placeData.duration || "2 hours",
      location: placeData.location,
      category: placeData.category,
      lat: placeData.lat,
      lng: placeData.lng,
      notes: placeData.notes || "",
      isMustDo: false
    };

    if (targetIdx >= dayObj.activities.length) {
      dayObj.activities.push(newAct);
    } else {
      dayObj.activities.splice(targetIdx, 0, newAct);
    }

    persistChanges();
    renderDayActivities();
    showToast(`Added "${newAct.title}" to Day ${currentDayNum}!`);
  }

  function reorderActivity(actId, targetIdx) {
    const dayObj = tripSchedule.find(d => d.day === currentDayNum);
    if (!dayObj || !dayObj.activities) return;

    const curIdx = dayObj.activities.findIndex(a => a.id === actId);
    if (curIdx < 0) return;

    const [movedAct] = dayObj.activities.splice(curIdx, 1);
    const adjustedIdx = targetIdx > curIdx ? targetIdx - 1 : targetIdx;
    dayObj.activities.splice(adjustedIdx, 0, movedAct);

    persistChanges();
    renderDayActivities();
    showToast("Activities reordered & schedule updated!");
  }

  // =========================================================================
  // 8. "SUGGESTED FOR YOU" PANEL & PREFERENCE RANKING
  // =========================================================================
  function getRankedSuggestions() {
    const allPlaces = tripDestPlaces.length > 0
      ? tripDestPlaces
      : ((window.MOCK_DATA && window.MOCK_DATA.places) ? window.MOCK_DATA.places : []);
    if (allPlaces.length === 0) return [];

    const userPrefs = WanderStorage.getUserPreferences ? WanderStorage.getUserPreferences() : { interests: ["culture", "food", "nature"] };
    const userInterests = (userPrefs.interests || []).map(i => i.toLowerCase());

    // Find destination center coords
    let destCoords = getDestCenterCoords(activeTrip);

    // Filter places for this destination or nearby
    let matchedPlaces = tripDestPlaces.length > 0 ? [...tripDestPlaces] : allPlaces.filter(p => {
      if (activeTrip.destinationId && p.destinationId === activeTrip.destinationId) return true;
      if (activeTrip.destination && p.destinationId) {
        const destSimple = activeTrip.destination.split(",")[0].trim().toLowerCase();
        if (p.destinationId.toLowerCase().includes(destSimple)) return true;
      }
      return false;
    });

    if (matchedPlaces.length === 0) {
      // Fallback: use top rated places globally
      matchedPlaces = [...allPlaces];
    }

    // Filter by Category pills if selected
    if (suggestionsCategory !== "all") {
      matchedPlaces = matchedPlaces.filter(p => {
        const cat = (p.category || "").toLowerCase();
        return cat.includes(suggestionsCategory.toLowerCase());
      });
    }

    // Rank places
    const scoredPlaces = matchedPlaces.map(p => {
      // 1. Rating score (up to 40 pts)
      const ratingScore = ((p.rating || 4.5) / 5.0) * 40;

      // 2. Preferences score (up to 35 pts)
      let prefScore = 10;
      const cat = (p.category || "").toLowerCase();
      const subCat = (p.subCategory || "").toLowerCase();
      const desc = (p.description || "").toLowerCase();

      userInterests.forEach(interest => {
        if (cat.includes(interest) || subCat.includes(interest) || desc.includes(interest)) {
          prefScore = Math.min(35, prefScore + 12);
        }
      });

      // 3. Proximity score (up to 25 pts)
      let proxScore = 15;
      if (p.lat && p.lng && destCoords) {
        const dist = haversineDistance(destCoords.lat, destCoords.lng, p.lat, p.lng);
        if (dist !== null) {
          if (dist <= 3) proxScore = 25;
          else if (dist <= 8) proxScore = 20;
          else if (dist <= 15) proxScore = 15;
          else proxScore = 8;
        }
      }

      const totalScore = ratingScore + prefScore + proxScore;
      // Match percentage
      const matchPct = Math.min(99, Math.max(78, Math.round(totalScore)));

      return {
        ...p,
        score: totalScore,
        matchPct: matchPct
      };
    });

    // Sort descending by score
    scoredPlaces.sort((a, b) => b.score - a.score);

    // Apply rotation for "Regenerate"
    if (suggestionsRotation > 0) {
      const shift = suggestionsRotation % scoredPlaces.length;
      return scoredPlaces.slice(shift).concat(scoredPlaces.slice(0, shift));
    }

    return scoredPlaces;
  }

  function populateSuggestions() {

    // Real-time place search in Itinerary Suggestions
    const placeSearch = document.getElementById("itinerary-place-search");
    if (placeSearch) {
      placeSearch.addEventListener("input", function(e) {
        const term = e.target.value.trim().toLowerCase();
        const cards = document.querySelectorAll(".suggestion-place-card");
        cards.forEach(card => {
          const title = (card.querySelector(".suggestion-card-title")?.textContent || "").toLowerCase();
          const sub = (card.querySelector(".suggestion-card-sub")?.textContent || "").toLowerCase();
          const match = title.includes(term) || sub.includes(term);
          card.style.display = match ? "flex" : "none";
        });
      });
    }

    const listEl = document.getElementById("suggestions-cards-list");
    if (!listEl) return;

    const places = getRankedSuggestions();

    if (places.length === 0) {
      listEl.innerHTML = `
        <div style="padding: var(--space-4); text-align: center; color: var(--text-muted); font-size: var(--text-sm);">
          No suggestions available for the selected category.
        </div>
      `;
      return;
    }

    listEl.innerHTML = places.map(p => `
      <div class="suggestion-card" 
           id="sugg-${p.id}"
           draggable="${isReadOnly ? 'false' : 'true'}"
           ondragstart="handleSuggestionDragStart(event, '${p.id}')"
           ondragend="handleSuggestionDragEnd(event)"
           title="${isReadOnly ? '' : 'Drag into day timeline'}">
        <img src="${p.photoUrl || 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=300&auto=format&fit=crop'}" 
             alt="${p.name}" class="suggestion-photo">
        <div class="suggestion-body">
          <div style="display: flex; justify-content: space-between; align-items: start; gap: 4px;">
            <span class="suggestion-title">${p.name}</span>
            <span class="match-chip">${p.matchPct}% Match</span>
          </div>

          <div class="suggestion-meta">
            <span>⭐ <strong>${p.rating || 4.8}</strong></span>
            <span>•</span>
            <span>⏱️ ${p.duration || '2 hrs'}</span>
            <span>•</span>
            <span>${p.cost || p.priceLevel || 'Free'}</span>
          </div>

          <div class="suggestion-actions">
            <span class="drag-prompt-hint">
              ${isReadOnly ? '' : '⠿ Drag into timeline'}
            </span>
            ${!isReadOnly ? `
              <button class="btn btn-outline-primary btn-sm" style="padding: 2px 8px; font-size: 11px;" onclick="addSuggestedPlaceDirect('${p.id}')">
                + Add
              </button>
            ` : ''}
          </div>
        </div>
      </div>
    `).join("");
  }

  // Quick "+ Add" button on suggested cards
  window.addSuggestedPlaceDirect = function (placeId) {
    if (isReadOnly) return;
    const allPlaces = (window.MOCK_DATA && window.MOCK_DATA.places) ? window.MOCK_DATA.places : [];
    const place = allPlaces.find(p => p.id === placeId);
    if (!place) return;

    insertNewActivityAt({
      title: place.name,
      location: place.name + (place.subCategory ? ` (${place.subCategory})` : ""),
      category: place.category || "Attractions",
      duration: place.duration || "2 hours",
      lat: place.lat,
      lng: place.lng,
      notes: place.description || ""
    }, 999);
  };

  // Regenerate Suggestions Button
  window.regenerateSuggestions = function () {
    suggestionsRotation += 2;
    const btn = document.getElementById("btn-regen-suggestions");
    if (btn) {
      btn.style.transform = "rotate(180deg)";
      setTimeout(() => btn.style.transform = "rotate(0deg)", 300);
    }
    populateSuggestions();
    showToast("Suggestions refreshed based on your profile!");
  };

  window.filterSuggestionsByCategory = function (category, btnEl) {
    suggestionsCategory = category;
    document.querySelectorAll(".suggestions-filter-pill").forEach(p => p.classList.remove("active"));
    if (btnEl) btnEl.classList.add("active");
    populateSuggestions();
  };

  // =========================================================================
  // 9. ACTIVITY ACTIONS: MUST-DO, EDIT, DELETE, ADD CUSTOM
  // =========================================================================
  window.toggleMustDo = function (e, actId) {
    e.stopPropagation();
    if (isReadOnly) return;

    const dayObj = tripSchedule.find(d => d.day === currentDayNum);
    if (!dayObj || !dayObj.activities) return;

    const act = dayObj.activities.find(a => a.id === actId);
    if (act) {
      act.isMustDo = !act.isMustDo;
      persistChanges();
      renderDayActivities();
      showToast(act.isMustDo ? `Marked "${act.title}" as Must-Do!` : `Marked "${act.title}" as Optional.`);
    }
  };

  window.deleteActivity = function (e, actId) {
    e.stopPropagation();
    if (isReadOnly) return;

    const dayObj = tripSchedule.find(d => d.day === currentDayNum);
    if (!dayObj || !dayObj.activities) return;

    const act = dayObj.activities.find(a => a.id === actId);
    const title = act ? act.title : "this stop";

    if (confirm(`Remove "${title}" from Day ${currentDayNum}?`)) {
      dayObj.activities = dayObj.activities.filter(a => a.id !== actId);
      persistChanges();
      renderDayActivities();
      showToast("Activity removed from schedule.");
    }
  };

  // Modal: Add Custom Activity
  window.openAddActivityModal = function () {
    if (isReadOnly) return;
    const modal = document.getElementById("add-act-modal");
    if (!modal) return;

    document.getElementById("modal-act-header-title").textContent = `Add Activity to Day ${currentDayNum}`;
    document.getElementById("edit-act-id").value = "";
    document.getElementById("act-form").reset();

    // Suggest default time
    const dayObj = tripSchedule.find(d => d.day === currentDayNum);
    let nextTime = "09:30 AM";
    if (dayObj && dayObj.activities && dayObj.activities.length > 0) {
      const last = dayObj.activities[dayObj.activities.length - 1];
      const mins = parseTimeToMinutes(last.time) || (9 * 60);
      const dur = parseDurationToMinutes(last.duration) || 90;
      nextTime = formatMinutesToTime(mins + dur + 30);
    }
    document.getElementById("act-time").value = nextTime;
    document.getElementById("act-duration").value = "2 hours";

    modal.classList.add("active");
  };

  window.openEditActivityModal = function (e, actId) {
    e.stopPropagation();
    if (isReadOnly) return;

    const dayObj = tripSchedule.find(d => d.day === currentDayNum);
    if (!dayObj || !dayObj.activities) return;

    const act = dayObj.activities.find(a => a.id === actId);
    if (!act) return;

    const modal = document.getElementById("add-act-modal");
    document.getElementById("modal-act-header-title").textContent = `Edit Stop: ${act.title}`;
    document.getElementById("edit-act-id").value = act.id;
    document.getElementById("act-title").value = act.title;
    document.getElementById("act-time").value = act.time || "09:00 AM";
    document.getElementById("act-duration").value = act.duration || "2 hours";
    document.getElementById("act-location").value = act.location || "";
    document.getElementById("act-category").value = act.category || "Sightseeing";
    document.getElementById("act-notes").value = act.notes || "";
    document.getElementById("act-must-do").checked = !!act.isMustDo;

    modal.classList.add("active");
  };

  window.closeAddActivityModal = function () {
    const modal = document.getElementById("add-act-modal");
    if (modal) modal.classList.remove("active");
  };

  window.handleSaveActivity = function (e) {
    e.preventDefault();
    if (isReadOnly) return;

    const editId = document.getElementById("edit-act-id").value;
    const title = document.getElementById("act-title").value.trim();
    const time = document.getElementById("act-time").value.trim();
    const duration = document.getElementById("act-duration").value.trim();
    const location = document.getElementById("act-location").value.trim();
    const category = document.getElementById("act-category").value;
    const notes = document.getElementById("act-notes").value.trim();
    const isMustDo = document.getElementById("act-must-do").checked;

    const dayObj = tripSchedule.find(d => d.day === currentDayNum);
    if (!dayObj) return;
    if (!dayObj.activities) dayObj.activities = [];

    // Approximate coords if editing custom spot
    let lat = null;
    let lng = null;
    if (DEST_COORDS[activeTrip.destinationId]) {
      // Add slight jitter so multiple custom places don't stack directly on top
      const offset = (dayObj.activities.length * 0.008);
      lat = DEST_COORDS[activeTrip.destinationId].lat + offset;
      lng = DEST_COORDS[activeTrip.destinationId].lng + offset;
    }

    if (editId) {
      // Update existing
      const act = dayObj.activities.find(a => a.id === editId);
      if (act) {
        act.title = title;
        act.time = time;
        act.duration = duration;
        act.location = location;
        act.category = category;
        act.notes = notes;
        act.isMustDo = isMustDo;
      }
      showToast("Activity updated!");
    } else {
      // Add new
      dayObj.activities.push({
        id: "act-" + Date.now(),
        title,
        time,
        duration,
        location,
        category,
        lat,
        lng,
        notes,
        isMustDo
      });
      showToast("Activity added to Day " + currentDayNum + "!");
    }

    closeAddActivityModal();
    persistChanges();
    renderDayActivities();
  };

  // =========================================================================
  // 10. LEAFLET ROUTE MAP & WAYPOINTS
  // =========================================================================
  
  function getDestCenterCoords(trip) {
    if (!trip) return { lat: 26.9124, lng: 75.7873, name: "Jaipur, Rajasthan" };
    let coords = DEST_COORDS[trip.destinationId];
    if (!coords) {
      const destLower = (trip.destination || "").toLowerCase();
      for (const k in DEST_COORDS) {
        const d = DEST_COORDS[k];
        const dName = (d.name || "").toLowerCase();
        const keyShort = k.replace("dest-", "");
        if (destLower.includes(keyShort) || destLower.includes(dName.split(",")[0].trim()) || dName.includes(destLower.split(",")[0].trim())) {
          coords = d;
          break;
        }
      }
    }
    if (!coords && tripDestPlaces.length > 0 && tripDestPlaces[0].lat) {
      coords = { lat: tripDestPlaces[0].lat, lng: tripDestPlaces[0].lng, name: trip.destination };
    }
    return coords || { lat: 26.9124, lng: 75.7873, name: trip.destination || "Jaipur, Rajasthan" };
  }

  function initRouteMap() {
    const mapEl = document.getElementById("itinerary-route-map");
    if (!mapEl || typeof L === "undefined") return;

    let destCenter = getDestCenterCoords(activeTrip);

    try {
      leafletMap = L.map("itinerary-route-map", {
        center: [destCenter.lat, destCenter.lng],
        zoom: 12,
        zoomControl: true,
        scrollWheelZoom: true
      });

      L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
      }).addTo(leafletMap);

      updateMapRoute();
    } catch (e) {
      console.error("Map initialization failed", e);
    }
  }

  function updateMapRoute() {
    if (!leafletMap || typeof L === "undefined") return;

    // Clear existing markers and polyline
    mapMarkers.forEach(m => leafletMap.removeLayer(m));
    mapMarkers = [];
    if (mapPolyline) {
      leafletMap.removeLayer(mapPolyline);
      mapPolyline = null;
    }

    const dayObj = tripSchedule.find(d => d.day === currentDayNum);
    if (!dayObj || !dayObj.activities) return;

    const validStops = dayObj.activities.filter(a => a.lat && a.lng);
    const latLngs = [];

    validStops.forEach((act, idx) => {
      latLngs.push([act.lat, act.lng]);

      const isMustDo = !!act.isMustDo;
      const markerHtml = `
        <div class="leaflet-waypoint-marker ${isMustDo ? 'must-do' : ''}" id="map-pin-${act.id}">
          ${idx + 1}
        </div>
      `;

      const customIcon = L.divIcon({
        className: "custom-leaflet-marker-wrap",
        html: markerHtml,
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      });

      const marker = L.marker([act.lat, act.lng], { icon: customIcon }).addTo(leafletMap);

      marker.bindPopup(`
        <div style="font-family: var(--font-main); min-width: 180px;">
          <div style="font-size: 11px; color: var(--text-muted); font-weight: bold;">
            STOP #${idx + 1} • ${act.time || 'Scheduled'}
          </div>
          <strong style="font-size: 14px; color: var(--text-main); display: block; margin: 3px 0;">
            ${act.title}
          </strong>
          <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 6px;">
            📍 ${act.location || ''}
          </div>
          <span class="badge ${isMustDo ? 'badge-warning' : 'badge-primary'}" style="font-size: 10px;">
            ${isMustDo ? '⭐ Must-Do' : '🌿 ' + (act.category || 'Sight')}
          </span>
          ${act.notes ? `<div style="font-size: 11px; margin-top: 6px; color: var(--text-muted); background: #f1f5f9; padding: 4px; border-radius: 4px;">💡 ${act.notes}</div>` : ''}
        </div>
      `);

      marker.actId = act.id;
      mapMarkers.push(marker);
    });

    // Draw route polyline connecting consecutive stops
    if (latLngs.length > 1) {
      mapPolyline = L.polyline(latLngs, {
        color: "#0d9488",
        weight: 4,
        opacity: 0.8,
        dashArray: "6, 8"
      }).addTo(leafletMap);
    }

    // Fit map bounds to show all markers
    if (latLngs.length > 0) {
      const bounds = L.latLngBounds(latLngs);
      leafletMap.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
    } else {
      const center = getDestCenterCoords(activeTrip);
      leafletMap.setView([center.lat, center.lng], 12);
    }
  }

  window.focusActivityOnMap = function (actId) {
    const marker = mapMarkers.find(m => m.actId === actId);
    if (marker && leafletMap) {
      leafletMap.panTo(marker.getLatLng(), { animate: true });
      marker.openPopup();
    }
  };

  // Toast feedback helper
  function showToast(message, type = "success") {
    if (window.WanderStorage && WanderStorage.showToast) {
      WanderStorage.showToast(message, type);
      return;
    }
    let container = document.getElementById("toast-container");
    if (!container) {
      container = document.createElement("div");
      container.id = "toast-container";
      container.style.cssText = "position: fixed; bottom: 24px; right: 24px; z-index: 9999; display: flex; flex-direction: column; gap: 8px;";
      document.body.appendChild(container);
    }

    const toast = document.createElement("div");
    toast.style.cssText = "background: #0f172a; color: white; padding: 12px 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.25); font-size: 14px; display: flex; align-items: center; gap: 8px; border-left: 4px solid #0d9488;";
    toast.innerHTML = `<span>✓</span><span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transition = "opacity 0.3s ease";
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // Initialize on DOM ready
  document.addEventListener("DOMContentLoaded", initPlanner);
})();
