/**
 * WANDERWISE INDIA - MOCK DATA REPOSITORY (data.js)
 * Exclusively Indian destinations, places, transit & accommodations:
 * - 15 Iconic Indian Destinations (North, South, West, East, Northeast, Islands)
 * - Authentic Cultural, Historical, Culinary & Scenic Places in INR (₹)
 * - Indian Carriers: IndiGo, Air India, Vistara, Akasa Air
 * - Indian Railways: IRCTC Vande Bharat Express, Rajdhani, Shatabdi, Tejas
 * - Buses: Zingbus, IntrCity SmartBus, KSRTC Airavat
 * - Cabs: Ola, Uber, Himalayan Innova, Airport Pre-paid Taxis
 * - Stays: Heritage Havelis, Luxury Houseboats, Taj/Oberoi Resorts, Zostel Hostels
 */

const MOCK_DATA = {
  appName: "WanderWise India",
  tagline: "Your Autonomous Indian Journey, Itinerary & Budget Planner",
  currency: "INR",
  currencySymbol: "₹",

  // 1. ALL-INDIA DESTINATIONS (15 Iconic Indian Regions)
  destinations: [
    {
      id: "dest-jaipur",
      name: "Jaipur, Rajasthan",
      state: "Rajasthan",
      region: "North / West",
      theme: "Heritage & Forts",
      tagline: "The Royal Pink City of Palaces, Forts & Havelis",
      description: "Capital of Rajasthan, famed for majestic hill forts, intricate sandstone palaces, vibrant bazaars, and legendary Rajput hospitality.",
      heroImage: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "October - March",
      avgBudget: "₹3,500 / day",
      rating: 4.9,
      reviewCount: 3420,
      tags: ["Heritage", "Forts", "Palaces", "Rajasthani Food", "Shopping"]
    },
    {
      id: "dest-udaipur",
      name: "Udaipur, Rajasthan",
      state: "Rajasthan",
      region: "West",
      theme: "Lakes & Romance",
      tagline: "City of Lakes & White Marble Splendor",
      description: "Surrounded by the Aravalli hills, boasting tranquil lakes, magnificent royal palaces, sunset boat cruises, and luxury heritage stays.",
      heroImage: "https://images.unsplash.com/photo-1615836245337-f5b9b2303f10?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "September - March",
      avgBudget: "₹4,200 / day",
      rating: 4.95,
      reviewCount: 2850,
      tags: ["Lakes", "Romance", "Palaces", "Culture", "Photography"]
    },
    {
      id: "dest-kerala",
      name: "Kerala Backwaters & Munnar",
      state: "Kerala",
      region: "South",
      theme: "Backwaters & Hills",
      tagline: "God's Own Country - Palm Canals & Rolling Tea Hills",
      description: "Glide through palm-fringed Vembanad canals on traditional kettuvallam houseboats and breathe the crisp mountain air of Munnar's emerald tea estates.",
      heroImage: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "September - March",
      avgBudget: "₹3,800 / day",
      rating: 4.92,
      reviewCount: 4120,
      tags: ["Backwaters", "Houseboats", "Tea Gardens", "Ayurveda", "Nature"]
    },
    {
      id: "dest-goa",
      name: "Goa Coastal & Heritage",
      state: "Goa",
      region: "West / Coastal",
      theme: "Beaches & Heritage",
      tagline: "Golden Sands, Portuguese Quarters & Susegad Vibes",
      description: "A sun-soaked paradise blending Portuguese colonial architecture in Fontainhas, pristine southern beaches, lush spice plantations, and vibrant nightlife.",
      heroImage: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "November - February",
      avgBudget: "₹4,000 / day",
      rating: 4.88,
      reviewCount: 5200,
      tags: ["Beaches", "Portuguese Heritage", "Seafood", "Nightlife", "Water Sports"]
    },
    {
      id: "dest-ladakh",
      name: "Leh-Ladakh, Himalayas",
      state: "Ladakh",
      region: "North / Himalayas",
      theme: "Adventure & High Altitudes",
      tagline: "The Land of High Mountain Passes & Azure Lakes",
      description: "Dramatic barren mountain scapes, high-altitude passes like Khardung La, ancient Buddhist monasteries, and the crystal blues of Pangong Tso.",
      heroImage: "https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "May - September",
      avgBudget: "₹4,800 / day",
      rating: 4.96,
      reviewCount: 3100,
      tags: ["Himalayas", "Biking", "Monasteries", "High Altitude Lakes", "Adventure"]
    },
    {
      id: "dest-varanasi",
      name: "Varanasi & Sarnath",
      state: "Uttar Pradesh",
      region: "North / Central",
      theme: "Spiritual & Sacred",
      tagline: "The Spiritual Capital of India & Eternal Ganga Ghats",
      description: "One of the world's oldest living cities, where devotional Ganga Aarti illuminates Dashashwamedh Ghat at dusk, alongside timeless silk-weaving traditions.",
      heroImage: "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "October - March",
      avgBudget: "₹2,200 / day",
      rating: 4.85,
      reviewCount: 2950,
      tags: ["Spiritual", "Ghats", "Ganga Aarti", "Temples", "Street Food"]
    },
    {
      id: "dest-manali",
      name: "Manali & Solang Valley",
      state: "Himachal Pradesh",
      region: "North / Himalayas",
      theme: "Hill Stations & Snow",
      tagline: "Pine Valleys, Rohtang Snow & Himalayan Streams",
      description: "Set on the banks of the Beas River, framed by snow-capped peaks, apple orchards, the engineering wonder of Atal Tunnel, and adventure sports.",
      heroImage: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "October - June",
      avgBudget: "₹3,200 / day",
      rating: 4.86,
      reviewCount: 3800,
      tags: ["Snow", "Adventure", "Pine Forests", "Trekking", "Cafe Culture"]
    },
    {
      id: "dest-rishikesh",
      name: "Rishikesh & Haridwar",
      state: "Uttarakhand",
      region: "North",
      theme: "Yoga & River Rafting",
      tagline: "Yoga Capital of the World & Holy River Confluence",
      description: "Cradled by the Himalayan foothills where the holy river Ganges flows emerald green, famous for white-water rafting, yoga ashrams, and suspension bridges.",
      heroImage: "https://images.unsplash.com/photo-1544717305-2782549b5136?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "September - May",
      avgBudget: "₹2,500 / day",
      rating: 4.89,
      reviewCount: 2600,
      tags: ["Yoga", "River Rafting", "Ashrams", "Camping", "Ganga Aarti"]
    },
    {
      id: "dest-amritsar",
      name: "Amritsar, Punjab",
      state: "Punjab",
      region: "North",
      theme: "Spiritual & Culinary",
      tagline: "Golden Temple Splendor & Soulful Punjabi Hospitality",
      description: "Home to the revered Golden Temple (Harmandir Sahib), the sacred community langar, the poignant Jallianwala Bagh, and iconic culinary delicacies.",
      heroImage: "https://images.unsplash.com/photo-1514222134-b57cbb8ce073?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "October - March",
      avgBudget: "₹2,600 / day",
      rating: 4.94,
      reviewCount: 3300,
      tags: ["Golden Temple", "Punjabi Cuisine", "Wagah Border", "History", "Culture"]
    },
    {
      id: "dest-darjeeling",
      name: "Darjeeling & Gangtok",
      state: "West Bengal & Sikkim",
      region: "East & Northeast",
      theme: "Hill Stations & Tea",
      tagline: "Queen of the Hills & Kanchenjunga Vistas",
      description: "Historic Himalayan toy train, world-renowned single-estate black teas, breathtaking sunrise over Mt. Kanchenjunga from Tiger Hill, and Buddhist gompas.",
      heroImage: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "March - May & October - December",
      avgBudget: "₹3,400 / day",
      rating: 4.87,
      reviewCount: 2400,
      tags: ["Toy Train", "Tea Estates", "Kanchenjunga", "Monasteries", "Himalayas"]
    },
    {
      id: "dest-meghalaya",
      name: "Meghalaya (Shillong & Cherrapunji)",
      state: "Meghalaya",
      region: "Northeast",
      theme: "Waterfalls & Nature",
      tagline: "The Abode of Clouds & Bio-Engineered Root Bridges",
      description: "Ancient double-decker living root bridges, crystal-clear waters of the Umngot River in Dawki, roaring waterfalls, and misty pine plateaus.",
      heroImage: "https://images.unsplash.com/photo-1608755728617-aefab37d45f6?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "October - April",
      avgBudget: "₹3,600 / day",
      rating: 4.93,
      reviewCount: 1950,
      tags: ["Living Root Bridges", "Waterfalls", "Caves", "Clean Villages", "Nature"]
    },
    {
      id: "dest-andaman",
      name: "Andaman & Nicobar Islands",
      state: "Andaman & Nicobar",
      region: "Coastal & Islands",
      theme: "Islands & Coral Reefs",
      tagline: "Turquoise Lagoons, Radhanagar Beach & Coral Reefs",
      description: "Pristine white sandy shores on Havelock (Swaraj Dweep), world-class scuba diving, mangrove kayak trails, and historic Cellular Jail.",
      heroImage: "https://images.unsplash.com/photo-1589308078059-be1415eab4c3?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "October - May",
      avgBudget: "₹5,500 / day",
      rating: 4.95,
      reviewCount: 2200,
      tags: ["Scuba Diving", "Beaches", "Coral Reefs", "Water Sports", "Islands"]
    },
    {
      id: "dest-hampi",
      name: "Hampi, Karnataka",
      state: "Karnataka",
      region: "South",
      theme: "UNESCO Heritage",
      tagline: "Monumental Boulders & The Vijayanagara Empire",
      description: "A surreal open-air museum set amid ancient granite boulders, stone chariots, monumental temple complexes, and sunsets over the Tungabhadra River.",
      heroImage: "https://images.unsplash.com/photo-1600100397608-f010f4439c27?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "November - February",
      avgBudget: "₹2,400 / day",
      rating: 4.91,
      reviewCount: 2100,
      tags: ["UNESCO World Heritage", "Ancient Ruins", "Bouldering", "History", "Architecture"]
    },
    {
      id: "dest-mumbai",
      name: "Mumbai & Western Ghats",
      state: "Maharashtra",
      region: "West",
      theme: "City Life & Heritage",
      tagline: "The City of Dreams, Marine Drive & Gateway of India",
      description: "India's buzzing commercial capital with Victorian Gothic architecture, sea breezes along Marine Drive Queen's Necklace, and vibrant street food.",
      heroImage: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "October - March",
      avgBudget: "₹4,500 / day",
      rating: 4.82,
      reviewCount: 4600,
      tags: ["Marine Drive", "Heritage Architecture", "Street Food", "Nightlife", "Culture"]
    },
    {
      id: "dest-agra",
      name: "Agra, Uttar Pradesh",
      state: "Uttar Pradesh",
      region: "North",
      theme: "Mughal Heritage",
      tagline: "Home of the Taj Mahal - An Eternal Wonder of the World",
      description: "The crown jewel of the Mughal empire, featuring the peerless white marble Taj Mahal, the sprawling red sandstone Agra Fort, and Fatehpur Sikri.",
      heroImage: "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=1200&auto=format&fit=crop",
      bestTimeToVisit: "October - March",
      avgBudget: "₹2,800 / day",
      rating: 4.9,
      reviewCount: 5100,
      tags: ["Taj Mahal", "Mughal Architecture", "UNESCO Heritage", "History", "Petha Sweets"]
    }
  ],

  // 2. CURATED PLACES / SIGHTS IN INDIA
  places: [
    // JAIPUR SIGHTS
    {
      id: "place-amber-fort",
      destinationId: "dest-jaipur",
      name: "Amber Fort & Palace (Amer)",
      category: "attractions",
      subCategory: "Heritage Fort",
      rating: 4.9,
      cost: "₹500",
      duration: "3 hours",
      lat: 26.9855,
      lng: 75.8513,
      distanceFromCenter: "11 km",
      photoUrl: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&auto=format&fit=crop",
      description: "Magnificent Rajput hill fortress with Sheesh Mahal (Mirror Palace) overlooking Maota Lake."
    },
    {
      id: "place-hawa-mahal",
      destinationId: "dest-jaipur",
      name: "Hawa Mahal (Palace of Winds)",
      category: "attractions",
      subCategory: "Architecture",
      rating: 4.8,
      cost: "₹200",
      duration: "1.5 hours",
      lat: 26.9239,
      lng: 75.8267,
      distanceFromCenter: "2 km",
      photoUrl: "https://images.unsplash.com/photo-1609137144813-7d9921338f24?w=600&auto=format&fit=crop",
      description: "Five-story honeycomb pink sandstone facade with 953 ornate jharokha windows."
    },
    {
      id: "place-chokhi-dhani",
      destinationId: "dest-jaipur",
      name: "Chokhi Dhani Ethnic Village & Feast",
      category: "food",
      subCategory: "Rajasthani Dining",
      rating: 4.85,
      cost: "₹1,200",
      duration: "3.5 hours",
      lat: 26.7663,
      lng: 75.8361,
      distanceFromCenter: "19 km",
      photoUrl: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=600&auto=format&fit=crop",
      description: "Authentic Rajasthani thali dinner accompanied by Kalbelia folk dance, camel rides, and pottery."
    },
    {
      id: "place-nahargarh",
      destinationId: "dest-jaipur",
      name: "Nahargarh Fort Sunset Point",
      category: "nature",
      subCategory: "Viewpoint",
      rating: 4.9,
      cost: "₹200",
      duration: "2 hours",
      lat: 26.9378,
      lng: 75.8156,
      distanceFromCenter: "6 km",
      photoUrl: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&auto=format&fit=crop",
      description: "Perched on the Aravalli ridge offering sweeping panoramic views over the illuminated Pink City."
    },
    {
      id: "place-joharibazaar",
      destinationId: "dest-jaipur",
      name: "Johari Bazaar & Bapu Bazaar",
      category: "shopping",
      subCategory: "Traditional Bazaars",
      rating: 4.75,
      cost: "Free Entry",
      duration: "2.5 hours",
      lat: 26.9205,
      lng: 75.8285,
      distanceFromCenter: "1.5 km",
      photoUrl: "https://images.unsplash.com/photo-1596178065887-1198b6148b2b?w=600&auto=format&fit=crop",
      description: "Renowned market for handcrafted Kundan jewelry, Bandhani textiles, blue pottery, and Mojaris."
    },

    // KERALA SIGHTS
    {
      id: "place-alleppey-houseboat",
      destinationId: "dest-kerala",
      name: "Vembanad Lake Houseboat Cruise",
      category: "attractions",
      subCategory: "Backwaters Cruise",
      rating: 4.96,
      cost: "₹6,500",
      duration: "5 hours",
      lat: 9.4981,
      lng: 76.3388,
      distanceFromCenter: "4 km",
      photoUrl: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&auto=format&fit=crop",
      description: "Private cruise through serene canals, paddy fields, and coconut groves with fresh Karimeen fish curry."
    },
    {
      id: "place-munnar-tea",
      destinationId: "dest-kerala",
      name: "Munnar Kolukkumalai Tea Estates",
      category: "nature",
      subCategory: "Hill Station & Tea",
      rating: 4.92,
      cost: "₹300",
      duration: "4 hours",
      lat: 10.0889,
      lng: 77.0595,
      distanceFromCenter: "15 km",
      photoUrl: "https://images.unsplash.com/photo-1593693397690-362cb9666fc2?w=600&auto=format&fit=crop",
      description: "The highest tea plantation in the world with rolling mist, organic orthodox tea factory tours, and sunrise view."
    },
    {
      id: "place-kathakali",
      destinationId: "dest-kerala",
      name: "Kathakali & Kalaripayattu Cultural Show",
      category: "culture",
      subCategory: "Traditional Arts",
      rating: 4.88,
      cost: "₹500",
      duration: "2 hours",
      lat: 9.9658,
      lng: 76.2421,
      distanceFromCenter: "Fort Kochi",
      photoUrl: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=600&auto=format&fit=crop",
      description: "Intricate facial makeup demonstration followed by Kerala's classical dance-drama and martial arts."
    },

    // GOA SIGHTS
    {
      id: "place-fontainhas",
      destinationId: "dest-goa",
      name: "Fontainhas Latin Quarter Walking Tour",
      category: "culture",
      subCategory: "Heritage Walk",
      rating: 4.86,
      cost: "Free Entry",
      duration: "2 hours",
      lat: 15.4989,
      lng: 73.8278,
      distanceFromCenter: "Panaji",
      photoUrl: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=600&auto=format&fit=crop",
      description: "Charming Portuguese colonial streets with bright yellow, indigo, and terracotta houses and artisan bakeries."
    },
    {
      id: "place-dudhsagar",
      destinationId: "dest-goa",
      name: "Dudhsagar Waterfalls & Jeep Safari",
      category: "nature",
      subCategory: "Waterfalls & Safari",
      rating: 4.93,
      cost: "₹1,500",
      duration: "5 hours",
      lat: 15.3144,
      lng: 74.3143,
      distanceFromCenter: "Mollem",
      photoUrl: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=600&auto=format&fit=crop",
      description: "Four-tiered sea of milk waterfall on the Mandovi River deep inside Bhagwan Mahavir Wildlife Sanctuary."
    },
    {
      id: "place-anjuna-market",
      destinationId: "dest-goa",
      name: "Anjuna Beach & Flea Market",
      category: "shopping",
      subCategory: "Beach & Market",
      rating: 4.78,
      cost: "Free Entry",
      duration: "3 hours",
      lat: 15.5808,
      lng: 73.7431,
      distanceFromCenter: "North Goa",
      photoUrl: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop",
      description: "Eclectic beachfront bazaar with bohemian apparel, handicrafts, live musicians, and sunset shacks."
    },

    // LADAKH SIGHTS
    {
      id: "place-pangong",
      destinationId: "dest-ladakh",
      name: "Pangong Tso Lake Excursion",
      category: "nature",
      subCategory: "High Altitude Lake",
      rating: 4.98,
      cost: "₹2,500",
      duration: "6 hours",
      lat: 33.7595,
      lng: 78.6674,
      distanceFromCenter: "140 km from Leh",
      photoUrl: "https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?w=600&auto=format&fit=crop",
      description: "World famous endorheic lake changing colors from turquoise to deep indigo, situated at 14,270 ft."
    },
    {
      id: "place-thiksey",
      destinationId: "dest-ladakh",
      name: "Thiksey Monastery (Mini Potala)",
      category: "attractions",
      subCategory: "Buddhist Monastery",
      rating: 4.94,
      cost: "₹50",
      duration: "2.5 hours",
      lat: 34.0578,
      lng: 77.6669,
      distanceFromCenter: "19 km from Leh",
      photoUrl: "https://images.unsplash.com/photo-1596761225330-8012e87900b7?w=600&auto=format&fit=crop",
      description: "Twelve-story Tibetan Buddhist complex housing a colossal 49-foot statue of Maitreya Buddha."
    },

    // VARANASI SIGHTS
    {
      id: "place-ganga-aarti",
      destinationId: "dest-varanasi",
      name: "Dashashwamedh Ghat Evening Ganga Aarti",
      category: "culture",
      subCategory: "Spiritual Ceremony",
      rating: 4.97,
      cost: "Free Entry",
      duration: "2 hours",
      lat: 25.3076,
      lng: 83.0107,
      distanceFromCenter: "Main Ghats",
      photoUrl: "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=600&auto=format&fit=crop",
      description: "Soul-stirring river ritual where priests perform coordinated brass lamp aarti accompanied by conch shells."
    },
    {
      id: "place-kashi-vishwanath",
      destinationId: "dest-varanasi",
      name: "Kashi Vishwanath Jyotirlinga Temple & Corridor",
      category: "attractions",
      subCategory: "Sacred Temple",
      rating: 4.92,
      cost: "Free Entry",
      duration: "2 hours",
      lat: 25.3109,
      lng: 83.0107,
      distanceFromCenter: "Varanasi Old City",
      photoUrl: "https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop",
      description: "One of the twelve sacred Jyotirlingas, newly restored with grand riverfront corridor connecting to the Ghats."
    },

    // AGRA SIGHTS
    {
      id: "place-taj-mahal",
      destinationId: "dest-agra",
      name: "Taj Mahal (UNESCO World Heritage)",
      category: "attractions",
      subCategory: "Mughal Wonder",
      rating: 4.98,
      cost: "₹500",
      duration: "3 hours",
      lat: 27.1751,
      lng: 78.0421,
      distanceFromCenter: "Agra Center",
      photoUrl: "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=600&auto=format&fit=crop",
      description: "Magnificent 17th-century white marble mausoleum built by Mughal Emperor Shah Jahan for Mumtaz Mahal."
    },
    {
      id: "place-agra-fort",
      destinationId: "dest-agra",
      name: "Agra Red Fort & Diwan-i-Khas",
      category: "attractions",
      subCategory: "Historical Fort",
      rating: 4.88,
      cost: "₹350",
      duration: "2 hours",
      lat: 27.1795,
      lng: 78.0211,
      distanceFromCenter: "2.5 km from Taj",
      photoUrl: "https://images.unsplash.com/photo-1592635196078-9fdc757f27f4?w=600&auto=format&fit=crop",
      description: "Vast red sandstone imperial residence of Mughal emperors overlooking the Yamuna River."
    },

    // AMRITSAR SIGHTS
    {
      id: "place-golden-temple",
      destinationId: "dest-amritsar",
      name: "Golden Temple (Sri Harmandir Sahib)",
      category: "attractions",
      subCategory: "Sacred Shrine",
      rating: 4.99,
      cost: "Free Entry",
      duration: "3 hours",
      lat: 31.6200,
      lng: 74.8765,
      distanceFromCenter: "Amritsar Heart",
      photoUrl: "https://images.unsplash.com/photo-1514222134-b57cbb8ce073?w=600&auto=format&fit=crop",
      description: "Gilded sanctuary surrounded by the sacred Amrit Sarovar lake, serving free meals (Langar) to 100,000 pilgrims daily."
    },
    {
      id: "place-wagah-border",
      destinationId: "dest-amritsar",
      name: "Wagah Border Beating Retreat Ceremony",
      category: "culture",
      subCategory: "National Pride",
      rating: 4.91,
      cost: "Free Entry",
      duration: "3 hours",
      lat: 31.6042,
      lng: 74.5731,
      distanceFromCenter: "28 km from city",
      photoUrl: "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=600&auto=format&fit=crop",
      description: "Electrifying military drill and flag lowering ceremony conducted daily by Indian BSF and Pakistan Rangers."
    },

    // UDAIPUR SIGHTS
    {
      id: "place-city-palace-udaipur",
      destinationId: "dest-udaipur",
      name: "City Palace Udaipur",
      category: "attractions",
      subCategory: "Heritage Palace",
      rating: 4.9,
      cost: "₹300",
      duration: "3 hours",
      lat: 24.5764,
      lng: 73.6833,
      distanceFromCenter: "City Center",
      photoUrl: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&auto=format&fit=crop",
      description: "Sprawling granite-and-marble palace complex overlooking Lake Pichola, built over 400 years by Mewar rulers."
    },
    {
      id: "place-lake-pichola",
      destinationId: "dest-udaipur",
      name: "Lake Pichola Sunset Boat Ride",
      category: "nature",
      subCategory: "Lake Cruise",
      rating: 4.85,
      cost: "₹700",
      duration: "1.5 hours",
      lat: 24.5714,
      lng: 73.6798,
      distanceFromCenter: "1 km",
      photoUrl: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&auto=format&fit=crop",
      description: "Glide past the Jag Mandir and Lake Palace as the City Palace glows gold at sunset."
    },
    {
      id: "place-saheliyon-ki-bari",
      destinationId: "dest-udaipur",
      name: "Saheliyon-ki-Bari Gardens",
      category: "nature",
      subCategory: "Royal Gardens",
      rating: 4.6,
      cost: "₹50",
      duration: "1 hour",
      lat: 24.5964,
      lng: 73.6900,
      distanceFromCenter: "3 km",
      photoUrl: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=600&auto=format&fit=crop",
      description: "Fountain-filled garden built for royal ladies-in-waiting, with lotus pools and marble kiosks."
    },

    // MANALI SIGHTS
    {
      id: "place-solang-valley",
      destinationId: "dest-manali",
      name: "Solang Valley",
      category: "nature",
      subCategory: "Adventure Valley",
      rating: 4.8,
      cost: "₹200",
      duration: "3 hours",
      lat: 32.3170,
      lng: 77.1571,
      distanceFromCenter: "13 km",
      photoUrl: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&auto=format&fit=crop",
      description: "Snow-ringed valley popular for paragliding, zorbing, and cable car rides in view of the Beas Kund glaciers."
    },
    {
      id: "place-hadimba-temple",
      destinationId: "dest-manali",
      name: "Hadimba Devi Temple",
      category: "attractions",
      subCategory: "Wooden Temple",
      rating: 4.7,
      cost: "Free Entry",
      duration: "1 hour",
      lat: 32.2468,
      lng: 77.1706,
      distanceFromCenter: "2 km",
      photoUrl: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&auto=format&fit=crop",
      description: "Ancient cave shrine wrapped in a cedar forest, dedicated to the wife of Bhima from the Mahabharata."
    },
    {
      id: "place-old-manali",
      destinationId: "dest-manali",
      name: "Old Manali Cafes & Riverside Walk",
      category: "food",
      subCategory: "Cafe Hopping",
      rating: 4.75,
      cost: "₹600",
      duration: "2.5 hours",
      lat: 32.2550,
      lng: 77.1670,
      distanceFromCenter: "3 km",
      photoUrl: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=600&auto=format&fit=crop",
      description: "Laid-back lanes along the Manalsu stream lined with wood-and-stone cafes and Himachali handicraft stalls."
    },

    // RISHIKESH SIGHTS
    {
      id: "place-laxman-jhula",
      destinationId: "dest-rishikesh",
      name: "Laxman Jhula & Ram Jhula",
      category: "attractions",
      subCategory: "Suspension Bridges",
      rating: 4.7,
      cost: "Free Entry",
      duration: "1.5 hours",
      lat: 30.1197,
      lng: 78.3288,
      distanceFromCenter: "5 km",
      photoUrl: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&auto=format&fit=crop",
      description: "Iconic iron bridges over the Ganges, lined with temples, ashrams, and views of the river valley."
    },
    {
      id: "place-triveni-ghat-aarti",
      destinationId: "dest-rishikesh",
      name: "Triveni Ghat Ganga Aarti",
      category: "culture",
      subCategory: "Evening Ceremony",
      rating: 4.9,
      cost: "Free Entry",
      duration: "1 hour",
      lat: 30.0837,
      lng: 78.2926,
      distanceFromCenter: "2 km",
      photoUrl: "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=600&auto=format&fit=crop",
      description: "Sunset river-worship ritual with floating diyas, chanting, and conch shells on the banks of the Ganges."
    },
    {
      id: "place-rishikesh-rafting",
      destinationId: "dest-rishikesh",
      name: "Ganga White-Water Rafting",
      category: "nature",
      subCategory: "River Adventure",
      rating: 4.85,
      cost: "₹800",
      duration: "3 hours",
      lat: 30.1450,
      lng: 78.3050,
      distanceFromCenter: "6 km",
      photoUrl: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&auto=format&fit=crop",
      description: "Grade II-III rapids from Shivpuri down to Rishikesh through pine-forested Himalayan foothills."
    },

    // DARJEELING SIGHTS
    {
      id: "place-tiger-hill",
      destinationId: "dest-darjeeling",
      name: "Tiger Hill Sunrise Point",
      category: "nature",
      subCategory: "Viewpoint",
      rating: 4.85,
      cost: "₹50",
      duration: "2 hours",
      lat: 27.0038,
      lng: 88.2621,
      distanceFromCenter: "11 km",
      photoUrl: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&auto=format&fit=crop",
      description: "Pre-dawn climb for a first-light view of Kanchenjunga, the world's third-highest peak."
    },
    {
      id: "place-darjeeling-toy-train",
      destinationId: "dest-darjeeling",
      name: "Darjeeling Himalayan Railway (Toy Train)",
      category: "attractions",
      subCategory: "UNESCO Heritage Ride",
      rating: 4.8,
      cost: "₹1,500",
      duration: "2 hours",
      lat: 27.0410,
      lng: 88.2663,
      distanceFromCenter: "City Center",
      photoUrl: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&auto=format&fit=crop",
      description: "Narrow-gauge steam train looping through tea gardens and mountain villages since 1881."
    },
    {
      id: "place-happy-valley-tea",
      destinationId: "dest-darjeeling",
      name: "Happy Valley Tea Estate",
      category: "food",
      subCategory: "Tea Garden Tour",
      rating: 4.7,
      cost: "₹150",
      duration: "1.5 hours",
      lat: 27.0450,
      lng: 88.2470,
      distanceFromCenter: "3 km",
      photoUrl: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=600&auto=format&fit=crop",
      description: "Working second-flush tea estate offering factory tours and fresh Darjeeling tea tastings."
    },

    // MEGHALAYA SIGHTS
    {
      id: "place-living-root-bridges",
      destinationId: "dest-meghalaya",
      name: "Double Decker Living Root Bridge, Cherrapunji",
      category: "nature",
      subCategory: "Rainforest Trek",
      rating: 4.95,
      cost: "₹50",
      duration: "5 hours",
      lat: 25.2624,
      lng: 91.6647,
      distanceFromCenter: "78 km from Shillong",
      photoUrl: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&auto=format&fit=crop",
      description: "Centuries-old bridges grown from living rubber-fig roots by the Khasi tribe, reached via a steep jungle trek."
    },
    {
      id: "place-mawlynnong",
      destinationId: "dest-meghalaya",
      name: "Mawlynnong - Asia's Cleanest Village",
      category: "attractions",
      subCategory: "Village Walk",
      rating: 4.8,
      cost: "₹30",
      duration: "2 hours",
      lat: 25.2020,
      lng: 91.9137,
      distanceFromCenter: "90 km from Shillong",
      photoUrl: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&auto=format&fit=crop",
      description: "Immaculately kept Khasi village with bamboo dustbins, living root bridges, and a sky-view tower."
    },
    {
      id: "place-umiam-lake",
      destinationId: "dest-meghalaya",
      name: "Umiam Lake",
      category: "nature",
      subCategory: "Lake & Water Sports",
      rating: 4.7,
      cost: "₹300",
      duration: "2 hours",
      lat: 25.6698,
      lng: 91.8930,
      distanceFromCenter: "15 km from Shillong",
      photoUrl: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&auto=format&fit=crop",
      description: "Man-made reservoir ringed by pine hills, popular for kayaking, boating, and picnics."
    },

    // ANDAMAN SIGHTS
    {
      id: "place-radhanagar-beach",
      destinationId: "dest-andaman",
      name: "Radhanagar Beach",
      category: "nature",
      subCategory: "Beach",
      rating: 4.97,
      cost: "Free Entry",
      duration: "3 hours",
      lat: 11.9769,
      lng: 92.9556,
      distanceFromCenter: "12 km",
      photoUrl: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&auto=format&fit=crop",
      description: "Powder-white sand and turquoise water once rated Asia's best beach by Time magazine."
    },
    {
      id: "place-elephant-beach-snorkel",
      destinationId: "dest-andaman",
      name: "Elephant Beach Snorkeling",
      category: "attractions",
      subCategory: "Water Sports",
      rating: 4.85,
      cost: "₹1,000",
      duration: "3 hours",
      lat: 12.0089,
      lng: 92.9481,
      distanceFromCenter: "8 km",
      photoUrl: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&auto=format&fit=crop",
      description: "Boat ride through mangroves to a coral reef bay with vivid snorkeling and sea-walking options."
    },
    {
      id: "place-kala-pathar-beach",
      destinationId: "dest-andaman",
      name: "Kala Pathar Beach Sunrise",
      category: "nature",
      subCategory: "Beach Viewpoint",
      rating: 4.7,
      cost: "Free Entry",
      duration: "1.5 hours",
      lat: 12.0270,
      lng: 92.9670,
      distanceFromCenter: "10 km",
      photoUrl: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&auto=format&fit=crop",
      description: "Quiet boulder-lined shore with calm shallow water, best at dawn before the crowds arrive."
    },

    // HAMPI SIGHTS
    {
      id: "place-virupaksha-temple",
      destinationId: "dest-hampi",
      name: "Virupaksha Temple",
      category: "attractions",
      subCategory: "Ancient Temple",
      rating: 4.85,
      cost: "₹50",
      duration: "1.5 hours",
      lat: 15.3350,
      lng: 76.4600,
      distanceFromCenter: "City Center",
      photoUrl: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&auto=format&fit=crop",
      description: "Active 7th-century temple with a 50m gopuram, still functioning within the Vijayanagara ruins."
    },
    {
      id: "place-vittala-temple",
      destinationId: "dest-hampi",
      name: "Vittala Temple & Stone Chariot",
      category: "attractions",
      subCategory: "UNESCO Ruins",
      rating: 4.95,
      cost: "₹600",
      duration: "2.5 hours",
      lat: 15.3428,
      lng: 76.4761,
      distanceFromCenter: "2.5 km",
      photoUrl: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&auto=format&fit=crop",
      description: "Ornate 16th-century temple complex famed for its musical stone pillars and iconic stone chariot."
    },
    {
      id: "place-matanga-hill-sunset",
      destinationId: "dest-hampi",
      name: "Matanga Hill Sunset Point",
      category: "nature",
      subCategory: "Viewpoint",
      rating: 4.9,
      cost: "Free Entry",
      duration: "2 hours",
      lat: 15.3372,
      lng: 76.4677,
      distanceFromCenter: "1 km",
      photoUrl: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&auto=format&fit=crop",
      description: "Boulder-strewn hilltop with the best panoramic view of Hampi's temple-studded, ruin-scattered landscape."
    },

    // MUMBAI SIGHTS
    {
      id: "place-gateway-of-india",
      destinationId: "dest-mumbai",
      name: "Gateway of India & Colaba",
      category: "attractions",
      subCategory: "Colonial Landmark",
      rating: 4.75,
      cost: "Free Entry",
      duration: "2 hours",
      lat: 18.9220,
      lng: 72.8347,
      distanceFromCenter: "City Center",
      photoUrl: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&auto=format&fit=crop",
      description: "Basalt Indo-Saracenic archway on the waterfront, with harbor boat rides to Elephanta Caves."
    },
    {
      id: "place-marine-drive",
      destinationId: "dest-mumbai",
      name: "Marine Drive Sunset Walk",
      category: "nature",
      subCategory: "Promenade",
      rating: 4.8,
      cost: "Free Entry",
      duration: "1.5 hours",
      lat: 18.9440,
      lng: 72.8235,
      distanceFromCenter: "3 km",
      photoUrl: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&auto=format&fit=crop",
      description: "The 'Queen's Necklace' - a sweeping bay-side boulevard that lights up gold at dusk."
    },
    {
      id: "place-elephanta-caves",
      destinationId: "dest-mumbai",
      name: "Elephanta Caves",
      category: "attractions",
      subCategory: "UNESCO Rock-Cut Caves",
      rating: 4.7,
      cost: "₹600",
      duration: "4 hours",
      lat: 18.9633,
      lng: 72.9315,
      distanceFromCenter: "10 km by ferry",
      photoUrl: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600&auto=format&fit=crop",
      description: "Island cave temples carved with monumental Shiva sculptures, a short ferry ride from the Gateway."
    }
  ],

  // 3. INDIAN TRANSPORTATION & ACCOMMODATION INVENTORY

  flights: [
    {
      id: "FL-6E-204",
      airline: "IndiGo",
      flightNumber: "6E-204",
      origin: "DEL (Indira Gandhi Int'l, Delhi)",
      destination: "JAI (Jaipur Airport)",
      departureTime: "07:15 AM",
      arrivalTime: "08:15 AM",
      duration: "1h 00m",
      stops: "Non-stop",
      price: 3450,
      badge: "Fastest"
    },
    {
      id: "FL-AI-480",
      airline: "Air India",
      flightNumber: "AI-480",
      origin: "DEL (New Delhi)",
      destination: "COK (Cochin Int'l, Kochi)",
      departureTime: "09:30 AM",
      arrivalTime: "12:45 PM",
      duration: "3h 15m",
      stops: "Non-stop",
      price: 6850,
      badge: "Popular"
    },
    {
      id: "FL-UK-845",
      airline: "Vistara",
      flightNumber: "UK-845",
      origin: "BOM (Mumbai)",
      destination: "GOI (Dabolim, Goa)",
      departureTime: "11:20 AM",
      arrivalTime: "12:35 PM",
      duration: "1h 15m",
      stops: "Non-stop",
      price: 4200,
      badge: "Premium Economy"
    },
    {
      id: "FL-QP-132",
      airline: "Akasa Air",
      flightNumber: "QP-132",
      origin: "BLR (Bengaluru)",
      destination: "IXL (Kushok Bakula, Leh)",
      departureTime: "06:10 AM",
      arrivalTime: "10:45 AM",
      duration: "4h 35m",
      stops: "1 stop (DEL)",
      price: 8900,
      badge: "Best Value"
    },
    {
      id: "FL-6E-551",
      airline: "IndiGo",
      flightNumber: "6E-551",
      origin: "BOM (Mumbai)",
      destination: "DEL (New Delhi)",
      departureTime: "08:00 AM",
      arrivalTime: "10:15 AM",
      duration: "2h 15m",
      stops: "Non-stop",
      price: 4850,
      badge: "Frequent"
    }
  ],

  // ponytail: verified against real IRCTC schedules (train numbers, stations,
  // times, durations) so results match actual trains, not invented ones.
  trains: [
    {
      id: "TR-VB-20978",
      trainName: "Vande Bharat Express (Ajmer - Chandigarh)",
      trainNumber: "20978",
      fromStation: "New Delhi (NDLS)",
      toStation: "Jaipur Junction (JP)",
      departureTime: "06:28 PM",
      arrivalTime: "10:05 PM",
      duration: "3h 37m",
      price: 1350,
      classType: "AC Chair Car (CC)",
      badge: "Fastest Express"
    },
    {
      id: "TR-RJ-12952",
      trainName: "Mumbai Rajdhani Express",
      trainNumber: "12952",
      fromStation: "New Delhi (NDLS)",
      toStation: "Mumbai Central (MMCT)",
      departureTime: "04:55 PM",
      arrivalTime: "08:35 AM",
      duration: "15h 40m",
      price: 2850,
      classType: "3rd AC (3A)",
      badge: "Premier Overnight"
    },
    {
      id: "TR-VB-20633",
      trainName: "Vande Bharat Express (Kerala)",
      trainNumber: "20633",
      fromStation: "Kasaragod (KGQ)",
      toStation: "Thiruvananthapuram Central (TVC)",
      departureTime: "02:30 PM",
      arrivalTime: "10:40 PM",
      duration: "8h 10m",
      price: 2550,
      classType: "AC Chair Car (CC)",
      badge: "Scenic Route"
    },
    {
      id: "TR-SH-12005",
      trainName: "Kalka Shatabdi Express",
      trainNumber: "12005",
      fromStation: "New Delhi (NDLS)",
      toStation: "Chandigarh (CDG)",
      departureTime: "05:15 PM",
      arrivalTime: "08:30 PM",
      duration: "3h 15m",
      price: 1120,
      classType: "Executive Class (EC)",
      badge: "On-board Catering"
    }
  ],

  hotels: [
    {
      id: "HT-SAMODE-101",
      name: "Samode Haveli Heritage Palace",
      location: "Gangapole, Jaipur Old City",
      destinationId: "dest-jaipur",
      pricePerNight: 8500,
      rating: 4.95,
      roomType: "Deluxe Heritage Suite with Courtyard View",
      badge: "Royal Heritage",
      photoUrl: "https://images.unsplash.com/photo-1582719508461-905c673771fd?w=600&auto=format&fit=crop"
    },
    {
      id: "HT-KERALA-201",
      name: "Vembanad Luxury Royal Houseboat",
      location: "Punnamada Jetty, Alleppey",
      destinationId: "dest-kerala",
      pricePerNight: 9500,
      rating: 4.92,
      roomType: "Private AC Bedroom with Sun Deck & Chef",
      badge: "Backwater Experience",
      photoUrl: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600&auto=format&fit=crop"
    },
    {
      id: "HT-GOA-301",
      name: "Taj Fort Aguada Beach Resort & Spa",
      location: "Sinquerim Beach, North Goa",
      destinationId: "dest-goa",
      pricePerNight: 12500,
      rating: 4.96,
      roomType: "Sea View Villa with Private Balcony",
      badge: "Luxury Beachfront",
      photoUrl: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=600&auto=format&fit=crop"
    },
    {
      id: "HT-ZOSTEL-401",
      name: "Zostel Jaipur Backpacker Hub",
      location: "Hawa Mahal Road, Jaipur",
      destinationId: "dest-jaipur",
      pricePerNight: 1100,
      rating: 4.8,
      roomType: "Private Superior Double Room / Dorm Bed",
      badge: "Budget Friendly",
      photoUrl: "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=600&auto=format&fit=crop"
    }
  ],

  buses: [
    {
      id: "BS-ZB-701",
      operator: "Zingbus Electric & Sleeper",
      serviceNumber: "ZB-9104 Royal Class",
      route: "Kashmere Gate ISBT, Delhi → Sindhi Camp, Jaipur",
      departureTime: "06:30 AM",
      duration: "5h 15m",
      busType: "AC BharatBenz Multi-Axle Sleeper (2+1)",
      price: 850,
      badge: "Free Snacks & Water"
    },
    {
      id: "BS-KSRTC-802",
      operator: "KSRTC Airavat Club Class",
      serviceNumber: "KA-01-F-9920",
      route: "Bengaluru Majestic → Panaji KSRTC Bus Stand, Goa",
      departureTime: "08:30 PM",
      duration: "12h 00m",
      busType: "Volvo Multi-Axle Semi-Sleeper AC",
      price: 1450,
      badge: "Overnight Sleeper"
    },
    {
      id: "BS-INTRCITY-903",
      operator: "IntrCity SmartBus",
      serviceNumber: "IC-883",
      route: "Majnu Ka Tilla, Delhi → Private Bus Stand, Manali",
      departureTime: "07:00 PM",
      duration: "13h 30m",
      busType: "Scania AC Sleeper Lounge with WiFi",
      price: 1650,
      badge: "Comfort Lounge"
    }
  ],

  cabs: [
    {
      id: "CB-OLA-01",
      serviceType: "Ola Prime Sedan",
      vehicle: "Maruti Dzire / Honda Amaze AC",
      route: "Jaipur Airport (JAI) → Heritage City Hotel",
      price: 650,
      badge: "Instant Driver Confirmation"
    },
    {
      id: "CB-UBER-02",
      serviceType: "Uber Premier SUV",
      vehicle: "Toyota Innova Crysta 7-Seater",
      route: "Kochi Airport (COK) → Alleppey Houseboat Jetty",
      price: 2450,
      badge: "Chauffeur & AC Luggage Room"
    },
    {
      id: "CB-LOCAL-03",
      serviceType: "Himalayan 4x4 Mountain Cab",
      vehicle: "Mahindra Scorpio 4WD",
      route: "Manali Mall Road → Solang Valley & Atal Tunnel",
      price: 2800,
      badge: "Snow Chain & High Altitude Permitted"
    }
  ],

  // 4. PRE-CONFIGURED SAMPLE INDIAN TRIPS & ITINERARIES
  sampleTrips: [
    {
      id: "trip-rajasthan-royal",
      title: "Royal Rajasthan Heritage Odyssey",
      destination: "Jaipur, Rajasthan",
      destinationId: "dest-jaipur",
      startDate: "2026-10-15",
      endDate: "2026-10-20",
      daysCount: 6,
      travelersCount: 2,
      coverPhoto: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=800&auto=format&fit=crop",
      totalBudget: 45000,
      spentBudget: 18450,
      status: "Active"
    },
    {
      id: "trip-kerala-backwaters",
      title: "Kerala Backwaters & Tea Trails",
      destination: "Alleppey & Munnar, Kerala",
      destinationId: "dest-kerala",
      startDate: "2026-11-05",
      endDate: "2026-11-10",
      daysCount: 5,
      travelersCount: 2,
      coverPhoto: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=800&auto=format&fit=crop",
      totalBudget: 38000,
      spentBudget: 16350,
      status: "Upcoming"
    },
    {
      id: "trip-goa-escape",
      title: "Goa Coastal & Heritage Getaway",
      destination: "Goa Coastal, India",
      destinationId: "dest-goa",
      startDate: "2026-12-18",
      endDate: "2026-12-22",
      daysCount: 4,
      travelersCount: 3,
      coverPhoto: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=800&auto=format&fit=crop",
      totalBudget: 32000,
      spentBudget: 8400,
      status: "Draft"
    }
  ],

  // 5. SAMPLE INDIAN BOOKINGS IN INR (₹)
  sampleBookings: [
    {
      id: "BK-FL-6E204",
      tripId: "trip-rajasthan-royal",
      category: "flight",
      title: "IndiGo Flight 6E-204 (Delhi to Jaipur)",
      carrier: "IndiGo Airlines",
      serviceNumber: "6E-204",
      route: "DEL (Indira Gandhi Int'l, Delhi) → JAI (Jaipur)",
      date: "2026-10-15",
      time: "07:15 AM",
      seatDetails: "Seat 12A (Window)",
      status: "Confirmed",
      price: 3450,
      pnr: "6E8921FL",
      passenger: "Ayush Sharma"
    },
    {
      id: "BK-TR-20901",
      tripId: "trip-rajasthan-royal",
      category: "train",
      title: "IRCTC Vande Bharat Express",
      carrier: "Indian Railways (IRCTC)",
      serviceNumber: "20901 Vande Bharat",
      route: "New Delhi (NDLS) → Jaipur Junction (JP)",
      date: "2026-10-15",
      time: "06:10 AM",
      seatDetails: "Coach C3, Seat 18 (Chair Car)",
      status: "Confirmed",
      price: 1350,
      pnr: "4218925532",
      passenger: "Ayush Sharma"
    },
    {
      id: "BK-HT-1204",
      tripId: "trip-rajasthan-royal",
      category: "hotel",
      title: "Samode Haveli Heritage Palace",
      carrier: "Samode Hotels & Havelis",
      serviceNumber: "Deluxe Heritage Courtyard Suite",
      route: "Gangapole, Jaipur Old City",
      date: "2026-10-15 to 2026-10-19",
      time: "Check-in: 02:00 PM",
      seatDetails: "Room 104 (Courtyard View)",
      status: "Confirmed",
      price: 12800,
      pnr: "HT1204RJ",
      passenger: "Ayush Sharma"
    },
    {
      id: "BK-CB-3391",
      tripId: "trip-rajasthan-royal",
      category: "cab",
      title: "Ola Prime Airport Transfer",
      carrier: "Ola Prime Sedan",
      serviceNumber: "Maruti Dzire • #RJ14-CB-9920",
      route: "Jaipur Airport (JAI) → Samode Haveli",
      date: "2026-10-15",
      time: "08:45 AM",
      seatDetails: "Driver: Rajesh Gurjar (4.9★)",
      status: "Confirmed",
      price: 850,
      pnr: "CB3391IN",
      passenger: "Ayush Sharma"
    }
  ],

  // 6. SAMPLE DAY-BY-DAY ITINERARIES IN INDIA
  sampleItineraries: {
    "trip-rajasthan-royal": [
      {
        day: 1,
        title: "Arrival & The Royal Amber Citadel",
        date: "Oct 15, 2026",
        activities: [
          {
            id: "act-101",
            time: "10:30 AM",
            title: "Amber Fort & Palace Tour",
            location: "Amer, Jaipur",
            category: "Sightseeing & Forts",
            duration: "3 hours",
            lat: 26.9855,
            lng: 75.8513,
            notes: "Explore Sheesh Mahal mirror palace; audio guide highly recommended",
            isMustDo: true
          },
          {
            id: "act-102",
            time: "02:30 PM",
            title: "Traditional Lunch at 1135 AD",
            location: "Amer Fort Complex",
            category: "Dining & Culinary",
            duration: "1.5 hours",
            lat: 26.9855,
            lng: 75.8513,
            notes: "Fine royal dining with silver cutlery and live sarangi music",
            isMustDo: false
          },
          {
            id: "act-103",
            time: "05:00 PM",
            title: "Nahargarh Fort Sunset Panorama",
            location: "Aravalli Hills, Jaipur",
            category: "Nature & Views",
            duration: "2 hours",
            lat: 26.9378,
            lng: 75.8156,
            notes: "Watch the Pink City transition into a sparkling sea of lights",
            isMustDo: true
          }
        ]
      },
      {
        day: 2,
        title: "Wonders of the Walled Pink City",
        date: "Oct 16, 2026",
        activities: [
          {
            id: "act-201",
            time: "09:00 AM",
            title: "Hawa Mahal & City Palace Walk",
            location: "Badi Choupad, Old City",
            category: "Sightseeing & Culture",
            duration: "3 hours",
            lat: 26.9239,
            lng: 75.8267,
            notes: "Photograph the honeycomb facade from Wind View Cafe across the street",
            isMustDo: true
          },
          {
            id: "act-202",
            time: "01:00 PM",
            title: "Laxmi Mishthan Bhandar (LMB) Feast",
            location: "Johari Bazaar",
            category: "Dining & Culinary",
            duration: "1.5 hours",
            lat: 26.9205,
            lng: 75.8285,
            notes: "Famous for authentic Rajasthani Dal Baati Churma and Ghewar sweets",
            isMustDo: false
          },
          {
            id: "act-203",
            time: "04:30 PM",
            title: "Johari Bazaar & Bapu Bazaar Shopping",
            location: "Old City Markets",
            category: "Shopping & Leisure",
            duration: "2.5 hours",
            lat: 26.9205,
            lng: 75.8285,
            notes: "Bargain for Jaipuri quilts, Bandhani dupattas, and handcrafted juttis",
            isMustDo: false
          }
        ]
      },
      {
        day: 3,
        title: "Village Culture & Rajasthani Folk Festivities",
        date: "Oct 17, 2026",
        activities: [
          {
            id: "act-301",
            time: "06:00 PM",
            title: "Chokhi Dhani Ethnic Village Experience",
            location: "Tonk Road, Jaipur",
            category: "Culture & Dining",
            duration: "4 hours",
            lat: 26.7663,
            lng: 75.8361,
            notes: "Includes grand traditional thali, Kalbelia dance, puppet shows, and fire acts",
            isMustDo: true
          }
        ]
      }
    ]
  }
};


// Export globally for browser client-side usage
if (typeof window !== "undefined") {
  window.MOCK_DATA = MOCK_DATA;
}
