/**
 * WANDERWISE INDIA - LOCALSTORAGE PERSISTENCE HELPER (storage.js)
 * Manages reactive browser persistence for:
 * - Current logged-in user
 * - Indian Trips & Active trip selection
 * - Daily itineraries & activities (with embedded CRUD support)
 * - Indian Transport & Hotel bookings in INR (₹)
 * - Splitwise Group Expenses & Debt Simplification
 * - Auto-syncs header navigation state across every page
 */

(function (root) {
  const STORAGE_KEYS = {
    USER: "WW_USER",
    TRIPS: "WW_TRIPS",
    ITINERARIES: "WW_ITINERARIES",
    BOOKINGS: "WW_BOOKINGS",
    ACTIVE_TRIP: "WW_ACTIVE_TRIP_ID",
    NOTIFICATIONS: "WW_NOTIFICATIONS",
    EXPENSES: "WW_EXPENSES",
    TRIP_MEMBERS: "WW_TRIP_MEMBERS"
  };

  const DEFAULT_USER = {
    id: "usr-ayush-01",
    name: "Ayush Sharma",
    email: "ayush@wanderwise.in",
    avatar: "AS",
    role: "Verified Indian Explorer",
    joinedDate: "2026-01-15"
  };

  const Storage = {
    keys: STORAGE_KEYS,

    // Safe retrieval with JSON parse
    _get(key, fallback = null) {
      try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : fallback;
      } catch (err) {
        console.error(`Error reading ${key} from localStorage`, err);
        return fallback;
      }
    },

    // Safe persistence with JSON stringify
    _set(key, value) {
      try {
        localStorage.setItem(key, JSON.stringify(value));
        return true;
      } catch (err) {
        console.error(`Error saving ${key} to localStorage`, err);
        return false;
      }
    },

    // Format numbers with Indian numbering system (e.g. ₹45,000, ₹1,20,000)
    formatINR(amount) {
      if (amount === undefined || amount === null || isNaN(amount)) return "₹0";
      const val = Math.round(Number(amount));
      const str = Math.abs(val).toString();
      let lastThree = str.substring(str.length - 3);
      const otherNumbers = str.substring(0, str.length - 3);
      if (otherNumbers !== '') {
        lastThree = ',' + lastThree;
      }
      const res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
      return (val < 0 ? "-₹" : "₹") + res;
    },

    // Initialize mock data on first visit
    init() {
      const mock = (typeof window !== "undefined" && window.MOCK_DATA) ? window.MOCK_DATA : null;

      // Force migration to pure India v5 to purge old Kyoto/Japan cache in existing browsers
      const CURRENT_VERSION = "WANDERWISE_INDIA_V5";
      const savedVersion = this._get("WW_DATA_VERSION");
      const savedTrips = this._get(STORAGE_KEYS.TRIPS);

      const hasForeignTrips = savedTrips && Array.isArray(savedTrips) && savedTrips.some(t => {
        const dest = (t.destination || "").toLowerCase();
        const title = (t.title || "").toLowerCase();
        return dest.includes("kyoto") || dest.includes("japan") || dest.includes("paris") || dest.includes("bali") || title.includes("kyoto");
      });

      if (savedVersion !== CURRENT_VERSION || hasForeignTrips) {
        console.log("Migrating WanderWise storage to Pure-India dataset (v5)...");
        localStorage.removeItem(STORAGE_KEYS.TRIPS);
        localStorage.removeItem(STORAGE_KEYS.ACTIVE_TRIP);
        localStorage.removeItem(STORAGE_KEYS.ITINERARIES);
        localStorage.removeItem(STORAGE_KEYS.BOOKINGS);
        localStorage.removeItem(STORAGE_KEYS.EXPENSES);
        localStorage.removeItem(STORAGE_KEYS.TRIP_MEMBERS);
        this._set("WW_DATA_VERSION", CURRENT_VERSION);
      }

      if (!this._get(STORAGE_KEYS.TRIPS) && mock && mock.sampleTrips) {
        this._set(STORAGE_KEYS.TRIPS, mock.sampleTrips);
        this._set(STORAGE_KEYS.ACTIVE_TRIP, mock.sampleTrips[0].id);
      }

      if (!this._get(STORAGE_KEYS.ITINERARIES) && mock && mock.sampleItineraries) {
        this._set(STORAGE_KEYS.ITINERARIES, mock.sampleItineraries);
      }

      if (!this._get(STORAGE_KEYS.BOOKINGS) && mock && mock.sampleBookings) {
        this._set(STORAGE_KEYS.BOOKINGS, mock.sampleBookings);
      }

      // Clean up legacy predefined mock members so users can enter their own crew names
      const savedMembers = this._get(STORAGE_KEYS.TRIP_MEMBERS);
      if (savedMembers && typeof savedMembers === "object") {
        let changed = false;
        Object.keys(savedMembers).forEach(tid => {
          const list = savedMembers[tid];
          if (Array.isArray(list)) {
            const cleaned = list.filter(m =>
              !["mem-1", "mem-2", "mem-3", "mem-4"].includes(m.id) &&
              !["Ayush Sharma", "Priya Patel", "Rohan Verma", "Sneha Reddy"].includes(m.name)
            );
            if (cleaned.length !== list.length) {
              savedMembers[tid] = cleaned;
              changed = true;
            }
          }
        });
        if (changed) {
          this._set(STORAGE_KEYS.TRIP_MEMBERS, savedMembers);
        }
      }

      if (!this._get(STORAGE_KEYS.EXPENSES)) {
        const defaultExpenses = {
          "trip-rajasthan-royal": [
            {
              id: "exp-1",
              title: "Amber Fort Entry & Audio Guides",
              category: "Sightseeing",
              amount: 1500,
              paidBy: "mem-1",
              splitBetween: ["mem-1", "mem-2", "mem-3", "mem-4"],
              date: "2026-10-15"
            },
            {
              id: "exp-2",
              title: "Lunch at 1135 AD Amer",
              category: "Food",
              amount: 3200,
              paidBy: "mem-2",
              splitBetween: ["mem-1", "mem-2", "mem-3", "mem-4"],
              date: "2026-10-15"
            },
            {
              id: "exp-3",
              title: "Ola Cab Airport to Samode",
              category: "Transit",
              amount: 850,
              paidBy: "mem-1",
              splitBetween: ["mem-1", "mem-2", "mem-3", "mem-4"],
              date: "2026-10-15"
            },
            {
              id: "exp-4",
              title: "Chokhi Dhani Dinner & Folk Passes",
              category: "Dining",
              amount: 4800,
              paidBy: "mem-3",
              splitBetween: ["mem-1", "mem-2", "mem-3", "mem-4"],
              date: "2026-10-16"
            }
          ]
        };
        this._set(STORAGE_KEYS.EXPENSES, defaultExpenses);
      }

      // Initialize default notifications if not present
      this.getNotifications();
    },

    resetDefaults() {
      localStorage.removeItem(STORAGE_KEYS.TRIPS);
      localStorage.removeItem(STORAGE_KEYS.ITINERARIES);
      localStorage.removeItem(STORAGE_KEYS.BOOKINGS);
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_TRIP);
      localStorage.removeItem(STORAGE_KEYS.NOTIFICATIONS);
      localStorage.removeItem(STORAGE_KEYS.EXPENSES);
      localStorage.removeItem(STORAGE_KEYS.TRIP_MEMBERS);
      this.init();
      this.showToast("All data successfully reset to All-India defaults!", "success");
      setTimeout(() => location.reload(), 600);
    },

    // ==========================================
    // 1. AUTH & USER MANAGEMENT
    // ==========================================
    getUser() {
      return this._get(STORAGE_KEYS.USER, null);
    },

    setUser(user) {
      this._set(STORAGE_KEYS.USER, user);
      this.syncHeaderAuth();
    },

    logout() {
      localStorage.removeItem(STORAGE_KEYS.USER);
      this.syncHeaderAuth();
      window.location.reload();
    },

    loginDemo(name = "Ayush Sharma", email = "ayush@wanderwise.in") {
      const user = {
        ...DEFAULT_USER,
        name: name,
        email: email
      };
      this.setUser(user);
      return user;
    },

    syncHeaderAuth() {
      const user = this.getUser();
      const userSlot = document.getElementById("header-user-slot");
      if (!userSlot) return;

      if (user) {
        const initials = user.avatar || (user.name ? user.name.split(" ").map(n => n[0]).join("") : "U");
        userSlot.innerHTML = `
          <div class="header-user-badge" style="display: flex; align-items: center; gap: 8px;">
            <div class="user-avatar-circle" title="${user.name}" style="width: 32px; height: 32px; border-radius: 50%; background: #0d9488; color: white; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 12px;">
              ${initials}
            </div>
            <span class="user-name" style="font-size: 13px; font-weight: 500;">${user.name.split(" ")[0]}</span>
            <button onclick="WanderStorage.logout()" class="btn btn-ghost btn-sm" style="font-size: 11px; padding: 2px 6px;">Sign Out</button>
          </div>
        `;
      } else {
        userSlot.innerHTML = `
          <a href="login.html" class="btn btn-outline btn-sm">Sign In</a>
          <a href="signup.html" class="btn btn-primary btn-sm">Get Started</a>
        `;
      }
    },

    // ==========================================
    // 2. TRIPS & ACTIVE EXPEDITION
    // ==========================================
    getTrips() {
      return this._get(STORAGE_KEYS.TRIPS, []);
    },

    getTripById(id) {
      const trips = this.getTrips();
      return trips.find(t => t.id === id) || null;
    },

    saveTrip(trip) {
      const trips = this.getTrips();
      const existingIdx = trips.findIndex(t => t.id === trip.id);
      if (existingIdx >= 0) {
        trips[existingIdx] = trip;
      } else {
        trips.unshift(trip);
      }
      this._set(STORAGE_KEYS.TRIPS, trips);
      return trip;
    },

    deleteTrip(id) {
      let trips = this.getTrips();
      trips = trips.filter(t => t.id !== id);
      this._set(STORAGE_KEYS.TRIPS, trips);

      if (this.getActiveTripId() === id) {
        const nextActive = trips.length > 0 ? trips[0].id : null;
        this.setActiveTrip(nextActive);
      }

      // Cleanup associated itinerary, bookings & expenses
      const allItin = this._get(STORAGE_KEYS.ITINERARIES, {});
      delete allItin[id];
      this._set(STORAGE_KEYS.ITINERARIES, allItin);

      const allExp = this._get(STORAGE_KEYS.EXPENSES, {});
      delete allExp[id];
      this._set(STORAGE_KEYS.EXPENSES, allExp);

      return true;
    },

    getActiveTripId() {
      return this._get(STORAGE_KEYS.ACTIVE_TRIP, null);
    },

    getActiveTrip() {
      const activeId = this.getActiveTripId();
      if (!activeId) {
        const trips = this.getTrips();
        return trips.length > 0 ? trips[0] : null;
      }
      return this.getTripById(activeId);
    },

    setActiveTrip(id) {
      this._set(STORAGE_KEYS.ACTIVE_TRIP, id);
      return id;
    },

    duplicateTrip(tripId) {
      const orig = this.getTripById(tripId);
      if (!orig) return null;

      const newId = `trip-${Date.now()}`;
      const clone = {
        ...orig,
        id: newId,
        title: `${orig.title} (Copy)`,
        status: "Draft",
        spentBudget: 0
      };

      this.saveTrip(clone);

      const origItin = this.getItinerary(tripId);
      if (origItin) {
        this.saveItinerary(newId, JSON.parse(JSON.stringify(origItin)));
      }

      this.setActiveTrip(newId);
      return clone;
    },

    // ==========================================
    // 3. ITINERARIES & EMBEDDED DAY ACTIVITIES
    // ==========================================
    getItinerary(tripId) {
      const all = this._get(STORAGE_KEYS.ITINERARIES, {});
      return all[tripId] || [];
    },

    saveItinerary(tripId, schedule) {
      const all = this._get(STORAGE_KEYS.ITINERARIES, {});
      all[tripId] = schedule;
      this._set(STORAGE_KEYS.ITINERARIES, all);
      return schedule;
    },

    _resolveDay(schedule, dayNumOrIdx) {
      if (!schedule || schedule.length === 0) return null;
      let day = schedule.find(d => d.day === dayNumOrIdx);
      if (!day && typeof dayNumOrIdx === "number") {
        day = schedule.find(d => d.day === (dayNumOrIdx + 1));
      }
      if (!day && schedule[dayNumOrIdx]) {
        day = schedule[dayNumOrIdx];
      }
      return day || schedule[0];
    },

    addActivity(tripId, dayNumOrIdx, activity) {
      const schedule = this.getItinerary(tripId);
      let day = this._resolveDay(schedule, dayNumOrIdx);
      if (!day) {
        const dayNumber = (typeof dayNumOrIdx === 'number' && dayNumOrIdx > 0) ? dayNumOrIdx : 1;
        day = {
          day: dayNumber,
          title: `Day ${dayNumber} Exploration`,
          date: `Day ${dayNumber}`,
          activities: []
        };
        schedule.push(day);
        schedule.sort((a, b) => a.day - b.day);
      }
      if (!day.activities) day.activities = [];
      if (!activity.id) activity.id = `act-${Date.now()}-${Math.floor(Math.random()*1000)}`;

      day.activities.push(activity);
      this.saveItinerary(tripId, schedule);
      return activity;
    },

    updateActivity(tripId, dayNumOrIdx, actId, updates) {
      const schedule = this.getItinerary(tripId);
      const day = this._resolveDay(schedule, dayNumOrIdx);
      if (day && day.activities) {
        const actIndex = day.activities.findIndex(a => a.id === actId);
        if (actIndex >= 0) {
          day.activities[actIndex] = { ...day.activities[actIndex], ...updates };
          this.saveItinerary(tripId, schedule);
          return day.activities[actIndex];
        }
      }
      return null;
    },

    deleteActivity(tripId, dayNumOrIdx, actIdOrIdx) {
      const schedule = this.getItinerary(tripId);
      const day = this._resolveDay(schedule, dayNumOrIdx);
      if (day && day.activities) {
        if (typeof actIdOrIdx === "number" && actIdOrIdx >= 0 && actIdOrIdx < day.activities.length) {
          day.activities.splice(actIdOrIdx, 1);
        } else {
          day.activities = day.activities.filter(a => a.id !== actIdOrIdx);
        }
        this.saveItinerary(tripId, schedule);
        return true;
      }
      return false;
    },

    toggleMustDo(tripId, dayNumOrIdx, actIdOrIdx) {
      const schedule = this.getItinerary(tripId);
      const day = this._resolveDay(schedule, dayNumOrIdx);
      if (day && day.activities) {
        let act = null;
        if (typeof actIdOrIdx === "number" && actIdOrIdx >= 0 && actIdOrIdx < day.activities.length) {
          act = day.activities[actIdOrIdx];
        } else {
          act = day.activities.find(a => a.id === actIdOrIdx);
        }
        if (act) {
          act.isMustDo = !act.isMustDo;
          this.saveItinerary(tripId, schedule);
          return act.isMustDo;
        }
      }
      return false;
    },

    // AUTOMATICALLY SEEDS CURATED PLACES INTO A TRIP ITINERARY
    async seedItineraryForDestination(tripId, destinationName, daysCount = 5, startDate = null) {
      let matchedPlaces = [];
      if (typeof window !== "undefined" && window.DestinationService) {
        try {
          matchedPlaces = await window.DestinationService.getPlacesForDestination(destinationName);
        } catch (e) {
          console.warn("Error fetching places from DestinationService", e);
        }
      }

      if (!matchedPlaces || matchedPlaces.length === 0) {
        const mock = (typeof window !== "undefined" && window.MOCK_DATA) ? window.MOCK_DATA : null;
        const allPlaces = (mock && mock.places) ? mock.places : [];
        const destLower = (destinationName || "").toLowerCase();

        // Filter matching places for this destination
        matchedPlaces = allPlaces.filter(p => {
          const destId = (p.destinationId || "").toLowerCase();
          const pLoc = (p.name + " " + (p.description || "") + " " + destId).toLowerCase();
          return pLoc.includes(destLower.split(",")[0].trim()) || destLower.includes(destId.replace("dest-", ""));
        });

        if (matchedPlaces.length < 2) {
          matchedPlaces = allPlaces;
        }
      }

      const schedule = [];
      const start = new Date(startDate || Date.now());
      let pIdx = 0;

      for (let i = 1; i <= daysCount; i++) {
        const d = new Date(start);
        d.setDate(d.getDate() + (i - 1));
        const dateStr = d.toLocaleDateString("en-IN", { month: "short", day: "numeric", year: "numeric" });

        let dayTheme = "Historic Monuments & Cultural Sights";
        if (i === 1) dayTheme = "Arrival & Grand Citadel Tour";
        else if (i === 2) dayTheme = "Palaces, Architecture & Bazaars";
        else if (i === 3) dayTheme = "Folk Village & Royal Culinary Feast";
        else if (i === daysCount) dayTheme = "Local Handicrafts & Farewell";

        const dayActs = [];
        // Add 2 real places for this day
        for (let k = 0; k < 2; k++) {
          if (matchedPlaces.length > 0) {
            const p = matchedPlaces[pIdx % matchedPlaces.length];
            pIdx++;
            const timeSlot = k === 0 ? "10:00 AM" : "03:30 PM";
            dayActs.push({
              id: `act-${tripId}-d${i}-${k+1}-${Date.now()}`,
              time: timeSlot,
              title: p.name,
              location: p.name + (p.distanceFromCenter ? ` (${p.distanceFromCenter})` : ""),
              category: p.category || "attractions",
              duration: p.duration || "2.5 hours",
              lat: p.lat,
              lng: p.lng,
              notes: p.description || "Iconic Indian sight recommended by WanderWise.",
              cost: p.cost || "Free Entry",
              isMustDo: k === 0
            });
          }
        }

        schedule.push({
          day: i,
          title: `Day ${i}: ${dayTheme}`,
          date: dateStr,
          activities: dayActs
        });
      }

      this.saveItinerary(tripId, schedule);
      return schedule;
    },

    addDayToTrip(tripId) {
      const schedule = this.getItinerary(tripId);
      const trip = this.getTripById(tripId);
      const newDayNum = schedule.length + 1;

      let dateStr = `Day ${newDayNum}`;
      if (trip && trip.startDate) {
        const d = new Date(trip.startDate);
        d.setDate(d.getDate() + (newDayNum - 1));
        dateStr = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
      }

      schedule.push({
        day: newDayNum,
        title: `Day ${newDayNum} Exploration`,
        date: dateStr,
        activities: []
      });

      if (trip) {
        trip.daysCount = Math.max(trip.daysCount || 0, newDayNum);
        this.saveTrip(trip);
      }

      this.saveItinerary(tripId, schedule);
      return newDayNum;
    },

    // ==========================================
    // 4. BOOKINGS & UNIFIED TIMELINE
    // ==========================================
    getBookings() {
      return this._get(STORAGE_KEYS.BOOKINGS, []);
    },

    getBookingById(id) {
      const bookings = this.getBookings();
      return bookings.find(b => b.id === id) || null;
    },

    getBookingsForTrip(tripId) {
      const bookings = this.getBookings();
      return bookings.filter(b => b.tripId === tripId);
    },

    getTripActivities(tripId) {
      const itinerary = this.getItinerary(tripId);
      const activities = [];
      itinerary.forEach(day => {
        if (day.activities && Array.isArray(day.activities)) {
          day.activities.forEach(act => {
            activities.push({
              ...act,
              dayNumber: day.day,
              dayTitle: day.title,
              dayDate: day.date
            });
          });
        }
      });
      return activities;
    },

    getTripUnifiedTimeline(tripId) {
      const trip = this.getTripById(tripId);
      if (!trip) return [];

      const itinerary = this.getItinerary(tripId);
      const bookings = this.getBookingsForTrip(tripId);

      const daysMap = {};

      itinerary.forEach(d => {
        daysMap[d.day] = {
          day: d.day,
          title: d.title || `Day ${d.day}`,
          date: d.date || `Day ${d.day}`,
          activities: [...(d.activities || [])],
          bookings: []
        };
      });

      if (Object.keys(daysMap).length === 0) {
        daysMap[1] = {
          day: 1,
          title: "Day 1 Exploration",
          date: trip.startDate || "Day 1",
          activities: [],
          bookings: []
        };
      }

      bookings.forEach(b => {
        let assignedDay = 1;

        if (b.date && trip.startDate) {
          const tripStart = new Date(trip.startDate);
          const bookingDate = new Date(b.date.split(" to ")[0]);
          if (!isNaN(tripStart) && !isNaN(bookingDate)) {
            const diffDays = Math.floor((bookingDate - tripStart) / (1000 * 60 * 60 * 24)) + 1;
            if (diffDays >= 1 && diffDays <= (trip.daysCount || 10)) {
              assignedDay = diffDays;
            }
          }
        }

        if (!daysMap[assignedDay]) {
          daysMap[assignedDay] = {
            day: assignedDay,
            title: `Day ${assignedDay} Exploration`,
            date: b.date || `Day ${assignedDay}`,
            activities: [],
            bookings: []
          };
        }

        daysMap[assignedDay].bookings.push(b);
      });

      const sortedDays = Object.keys(daysMap).map(Number).sort((a, b) => a - b);
      return sortedDays.map(dayNum => daysMap[dayNum]);
    },

    linkBookingToTrip(bookingId, tripId) {
      const updated = this.updateBooking(bookingId, { tripId });
      if (updated && tripId) {
        const trip = this.getTripById(tripId);
        if (trip) {
          trip.spentBudget = (trip.spentBudget || 0) + (updated.price || 0);
          this.saveTrip(trip);
        }
      }
      return updated;
    },

    unlinkBookingFromTrip(bookingId) {
      const booking = this.getBookingById(bookingId);
      if (booking && booking.tripId) {
        const trip = this.getTripById(booking.tripId);
        if (trip) {
          trip.spentBudget = Math.max(0, (trip.spentBudget || 0) - (booking.price || 0));
          this.saveTrip(trip);
        }
      }
      return this.updateBooking(bookingId, { tripId: null });
    },

    addBooking(booking) {
      const bookings = this.getBookings();
      if (!booking.id) {
        const prefix = (booking.category || "BK").slice(0, 2).toUpperCase();
        booking.id = `BK-${prefix}-${Math.floor(1000 + Math.random() * 9000)}`;
      }
      if (!booking.pnr) {
        booking.pnr = booking.category === 'train' ? `${Math.floor(1000000000 + Math.random() * 9000000000)}` : `IN${Math.floor(10000 + Math.random() * 90000)}`;
      }
      if (!booking.status) {
        booking.status = "Confirmed";
      }

      if (!booking.tripId) {
        const activeTrip = this.getActiveTrip();
        if (activeTrip) {
          booking.tripId = activeTrip.id;
        }
      }

      if (booking.tripId) {
        const trip = this.getTripById(booking.tripId);
        if (trip) {
          trip.spentBudget = (trip.spentBudget || 0) + (booking.price || 0);
          this.saveTrip(trip);
        }
      }

      bookings.unshift(booking);
      this._set(STORAGE_KEYS.BOOKINGS, bookings);

      this.addNotification({
        type: "booking_confirmed",
        title: "Booking Confirmed",
        message: `${booking.title || 'Reservation'} confirmed! PNR: ${booking.pnr}. Total: ${this.formatINR(booking.price || 0)}`,
        bookingId: booking.id,
        timestamp: new Date().toISOString()
      });

      return booking;
    },

    updateBooking(bookingId, updates) {
      const bookings = this.getBookings();
      const targetIndex = bookings.findIndex(b => b.id === bookingId);
      if (targetIndex >= 0) {
        bookings[targetIndex] = { ...bookings[targetIndex], ...updates };
        this._set(STORAGE_KEYS.BOOKINGS, bookings);
        return bookings[targetIndex];
      }
      return null;
    },

    cancelBooking(bookingId) {
      const bookings = this.getBookings();
      const target = bookings.find(b => b.id === bookingId);
      if (target) {
        target.status = "Cancelled";
        this._set(STORAGE_KEYS.BOOKINGS, bookings);

        if (target.tripId) {
          const trip = this.getTripById(target.tripId);
          if (trip) {
            trip.spentBudget = Math.max(0, (trip.spentBudget || 0) - (target.price || 0));
            this.saveTrip(trip);
          }
        }

        this.addNotification({
          type: "booking_cancelled",
          title: "Booking Cancelled",
          message: `${target.title || 'Reservation'} (${target.pnr}) was successfully cancelled. Refund initiated to source.`,
          bookingId: target.id,
          timestamp: new Date().toISOString()
        });

        return true;
      }
      return false;
    },

    // ==========================================
    // 5. SPLITWISE GROUP EXPENSE SHARING ENGINE
    // ==========================================
    getTripMembers(tripId) {
      const all = this._get(STORAGE_KEYS.TRIP_MEMBERS, {});
      return all[tripId] || [];
    },

    clearTripMembers(tripId) {
      const all = this._get(STORAGE_KEYS.TRIP_MEMBERS, {});
      all[tripId] = [];
      this._set(STORAGE_KEYS.TRIP_MEMBERS, all);
      return true;
    },

    addTripMember(tripId, memberName) {
      if (!memberName || !memberName.trim()) return null;
      const all = this._get(STORAGE_KEYS.TRIP_MEMBERS, {});
      if (!all[tripId]) all[tripId] = [];

      const cleanName = memberName.trim();
      const initials = cleanName.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);
      const colors = ["#0d9488", "#f59e0b", "#6366f1", "#ec4899", "#10b981", "#8b5cf6"];
      const color = colors[all[tripId].length % colors.length];

      const newMember = {
        id: `mem-${Date.now()}`,
        name: cleanName,
        avatar: initials,
        color: color
      };

      all[tripId].push(newMember);
      this._set(STORAGE_KEYS.TRIP_MEMBERS, all);
      return newMember;
    },

    deleteTripMember(tripId, memberId) {
      const all = this._get(STORAGE_KEYS.TRIP_MEMBERS, {});
      if (all[tripId]) {
        all[tripId] = all[tripId].filter(m => m.id !== memberId);
        this._set(STORAGE_KEYS.TRIP_MEMBERS, all);
        return true;
      }
      return false;
    },

    getExpenses(tripId) {
      const all = this._get(STORAGE_KEYS.EXPENSES, {});
      return all[tripId] || [];
    },

    addExpense(tripId, expense) {
      const all = this._get(STORAGE_KEYS.EXPENSES, {});
      if (!all[tripId]) all[tripId] = [];

      if (!expense.id) expense.id = `exp-${Date.now()}`;
      if (!expense.date) expense.date = new Date().toISOString().split("T")[0];
      if (!expense.paidBy && expense.paidById) expense.paidBy = expense.paidById;
      if (!expense.paidById && expense.paidBy) expense.paidById = expense.paidBy;
      if (!expense.description && expense.title) expense.description = expense.title;
      if (!expense.title && expense.description) expense.title = expense.description;

      all[tripId].unshift(expense);
      this._set(STORAGE_KEYS.EXPENSES, all);
      return expense;
    },

    deleteExpense(tripId, expenseId) {
      const all = this._get(STORAGE_KEYS.EXPENSES, {});
      if (all[tripId]) {
        all[tripId] = all[tripId].filter(e => e.id !== expenseId);
        this._set(STORAGE_KEYS.EXPENSES, all);
        return true;
      }
      return false;
    },

    // Splitwise Solver: Greedy Min-Cashflow Debt Simplification
    calculateSplitwise(tripId) {
      const members = this.getTripMembers(tripId);
      const expenses = this.getExpenses(tripId);

      const netBalances = {};
      const totalPaidMap = {};
      const totalShareMap = {};
      let totalGroupSpend = 0;

      members.forEach(m => {
        netBalances[m.id] = 0;
        totalPaidMap[m.id] = 0;
        totalShareMap[m.id] = 0;
      });

      expenses.forEach(exp => {
        const amount = Number(exp.amount) || 0;
        if (!exp.isSettlement) totalGroupSpend += amount;

        const payerId = exp.paidBy || exp.paidById;
        if (totalPaidMap[payerId] !== undefined) {
          totalPaidMap[payerId] += amount;
        }

        const participants = exp.splitBetween && exp.splitBetween.length > 0
          ? exp.splitBetween
          : members.map(m => m.id);

        const sharePerPerson = amount / (participants.length || 1);

        participants.forEach(pId => {
          if (totalShareMap[pId] !== undefined) {
            totalShareMap[pId] += sharePerPerson;
          }
        });
      });

      members.forEach(m => {
        netBalances[m.id] = Math.round(totalPaidMap[m.id] - totalShareMap[m.id]);
      });

      // Split into Creditors (owed money > 0) and Debtors (owe money < 0)
      const creditors = [];
      const debtors = [];

      members.forEach(m => {
        const bal = netBalances[m.id];
        if (bal > 1) {
          creditors.push({ id: m.id, name: m.name, amount: bal });
        } else if (bal < -1) {
          debtors.push({ id: m.id, name: m.name, amount: -bal });
        }
      });

      creditors.sort((a, b) => b.amount - a.amount);
      debtors.sort((a, b) => b.amount - a.amount);

      const debts = [];
      let cIdx = 0;
      let dIdx = 0;

      while (cIdx < creditors.length && dIdx < debtors.length) {
        const creditor = creditors[cIdx];
        const debtor = debtors[dIdx];
        const minAmount = Math.min(creditor.amount, debtor.amount);

        debts.push({
          id: `debt-${debtor.id}-${creditor.id}-${minAmount}`,
          fromId: debtor.id,
          fromName: debtor.name,
          toId: creditor.id,
          toName: creditor.name,
          amount: Math.round(minAmount)
        });

        creditor.amount -= minAmount;
        debtor.amount -= minAmount;

        if (creditor.amount < 1) cIdx++;
        if (debtor.amount < 1) dIdx++;
      }

      const decoratedMembers = members.map(m => ({
        ...m,
        paid: totalPaidMap[m.id] || 0,
        share: Math.round(totalShareMap[m.id] || 0),
        net: netBalances[m.id] || 0
      }));

      return {
        totalGroupSpend,
        totalExpenses: totalGroupSpend,
        members: decoratedMembers,
        totalPaidMap,
        totalShareMap,
        netBalances,
        debts
      };
    },

    settleDebt(tripId, fromId, toId, amount) {
      const fromMember = this.getTripMembers(tripId).find(m => m.id === fromId);
      const toMember = this.getTripMembers(tripId).find(m => m.id === toId);

      const settlement = {
        id: `settle-${Date.now()}`,
        title: `UPI Settlement: ${fromMember ? fromMember.name : 'Debtor'} -> ${toMember ? toMember.name : 'Creditor'}`,
        category: "Settlement",
        amount: Number(amount),
        paidBy: fromId,
        splitBetween: [toId],
        date: new Date().toISOString().split("T")[0],
        isSettlement: true
      };

      this.addExpense(tripId, settlement);
      this.showToast(`Recorded ₹${amount.toLocaleString('en-IN')} settlement via UPI!`, "success");
      return settlement;
    },

    // ==========================================
    // 6. NOTIFICATIONS (INDIAN LOCALIZED)
    // ==========================================
    getNotifications() {
      let notifs = this._get(STORAGE_KEYS.NOTIFICATIONS, null);
      if (!notifs) {
        notifs = [
          {
            id: "notif-1",
            type: "upcoming_reminder",
            title: "Upcoming Travel Reminder",
            message: "IndiGo Flight 6E-204 to Jaipur departs on Oct 15, 2026. Web check-in opens 48 hours prior.",
            bookingId: "BK-FL-6E204",
            timestamp: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
            read: false
          },
          {
            id: "notif-2",
            type: "status_change",
            title: "Platform Assigned",
            message: "IRCTC Vande Bharat Express (20978) departure platform confirmed: Platform 1 at New Delhi (NDLS).",
            bookingId: "BK-TR-20978",
            timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
            read: false
          },
          {
            id: "notif-3",
            type: "booking_confirmed",
            title: "Booking Confirmed",
            message: "Reservation confirmed for Samode Haveli Heritage Palace (PNR: HT1204RJ).",
            bookingId: "BK-HT-1204",
            timestamp: new Date(Date.now() - 1000 * 60 * 360).toISOString(),
            read: true
          }
        ];
        this._set(STORAGE_KEYS.NOTIFICATIONS, notifs);
      }
      return notifs;
    },

    addNotification(notif) {
      const notifs = this.getNotifications();
      if (!notif.id) notif.id = "notif-" + Date.now();
      notifs.unshift(notif);
      this._set(STORAGE_KEYS.NOTIFICATIONS, notifs);
      this.syncHeaderNotifications();
      return notif;
    },

    markNotificationsAsRead() {
      const notifs = this.getNotifications();
      notifs.forEach(n => n.read = true);
      this._set(STORAGE_KEYS.NOTIFICATIONS, notifs);
      this.syncHeaderNotifications();
    },

    syncHeaderNotifications() {
      const notifs = this.getNotifications();
      const count = notifs.filter(n => !n.read).length;
      const badge = document.getElementById("header-notif-badge");
      if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? "inline-flex" : "none";
      }
    },

    setupMobileNavToggle() {
      const toggle = document.querySelector(".mobile-nav-toggle");
      const navMenu = document.querySelector(".nav-menu");

      if (toggle && navMenu) {
        toggle.addEventListener("click", (e) => {
          e.stopPropagation();
          const isOpen = navMenu.classList.toggle("show-mobile");
          toggle.textContent = isOpen ? "✕" : "☰";
          toggle.setAttribute("aria-expanded", isOpen);
        });

        document.addEventListener("click", (e) => {
          if (!navMenu.contains(e.target) && !toggle.contains(e.target) && navMenu.classList.contains("show-mobile")) {
            navMenu.classList.remove("show-mobile");
            toggle.textContent = "☰";
            toggle.setAttribute("aria-expanded", "false");
          }
        });

        const dropdownTrigger = navMenu.querySelector(".nav-dropdown-trigger");
        const dropdown = navMenu.querySelector(".nav-dropdown");
        if (dropdownTrigger && dropdown) {
          dropdownTrigger.addEventListener("click", (e) => {
            if (window.innerWidth <= 768) {
              e.preventDefault();
              e.stopPropagation();
              dropdown.classList.toggle("mobile-open");
            }
          });
        }
      }
    },

    showToast(message, type = "success", duration = 3200) {
      let toastContainer = document.getElementById("ww-toast-container");
      if (!toastContainer) {
        toastContainer = document.createElement("div");
        toastContainer.id = "ww-toast-container";
        toastContainer.className = "toast-container";
        document.body.appendChild(toastContainer);
      }

      const toast = document.createElement("div");
      toast.className = `toast-item toast-${type}`;
      const icons = {
        success: "✓",
        danger: "✕",
        info: "ℹ",
        warning: "⚠"
      };
      toast.innerHTML = `
        <span class="toast-icon">${icons[type] || "•"}</span>
        <span class="toast-text">${message}</span>
      `;
      toastContainer.appendChild(toast);

      requestAnimationFrame(() => toast.classList.add("visible"));

      setTimeout(() => {
        toast.classList.remove("visible");
        setTimeout(() => toast.remove(), 300);
      }, duration);
    }
  };

  // Initialize and mount
  root.WanderStorage = Storage;
  Storage.init();

  if (typeof document !== "undefined") {
    document.addEventListener("DOMContentLoaded", () => {
      Storage.syncHeaderAuth();
      Storage.syncHeaderNotifications();
      Storage.setupMobileNavToggle();
    });
  }
})(typeof window !== "undefined" ? window : global);
