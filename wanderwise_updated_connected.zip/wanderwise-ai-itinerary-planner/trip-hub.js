/**
 * WANDERWISE INDIA - AI ITINERARY PLANNER CONTROLLER (trip-hub.js)
 * 
 * Remade Trip Hub page featuring a client-side AI Itinerary Planner:
 * - Reads existing destinations directly from MOCK_DATA.destinations (NO hardcoded destination lists).
 * - Autocomplete and validation powered by getAvailableDestinations().
 * - Empty/unselected default inputs for true user-driven input.
 * - Dynamic date and duration calculation.
 * - Budget-aware and style-aware mock AI itinerary generation.
 * - Reusable generateItinerary() designed for future backend/AI API migration.
 * - Complete results actions: Edit, Regenerate, Save to LocalStorage, Print, Download.
 */

(function () {
  'use strict';

  // Global State for Planner
  let currentItinerary = null;
  let lastTripInput = null;
  let activeDayIndex = 0;
  let selectedDestinationObj = null;

  // =========================================================================
  // 1. REUSABLE FUNCTION: getAvailableDestinations()
  // =========================================================================
  /**
   * Retrieves destinations that ALREADY exist in the website.
   * Reads from MOCK_DATA.destinations, plus any custom-cached destinations.
   * Does NOT use hardcoded destination lists.
   */
  window.getAvailableDestinations = function () {
    const list = [];
    const seenIds = new Set();

    // 1. Existing Seed Destinations in MOCK_DATA
    if (typeof window !== 'undefined' && window.MOCK_DATA && Array.isArray(window.MOCK_DATA.destinations)) {
      window.MOCK_DATA.destinations.forEach(d => {
        if (d && d.id && !seenIds.has(d.id)) {
          seenIds.add(d.id);
          list.push(d);
        }
      });
    }

    // 2. Custom or cached destinations from DestinationService if present
    if (typeof window !== 'undefined' && window.DestinationService && typeof window.DestinationService.getCachedDestinations === 'function') {
      try {
        const cached = window.DestinationService.getCachedDestinations();
        cached.forEach(d => {
          if (d && d.id && !seenIds.has(d.id)) {
            seenIds.add(d.id);
            list.push(d);
          }
        });
      } catch (e) {
        console.warn("Could not read cached destinations", e);
      }
    }

    return list;
  };

  /**
   * Finds an existing destination by ID or by matching name/query.
   */
  function findDestination(queryOrId) {
    if (!queryOrId) return null;
    const q = String(queryOrId).trim().toLowerCase();
    const all = window.getAvailableDestinations();

    // Exact ID match
    const byId = all.find(d => d.id.toLowerCase() === q);
    if (byId) return byId;

    // Exact name match
    const byExactName = all.find(d => d.name.toLowerCase() === q);
    if (byExactName) return byExactName;

    // Starts with match
    const byStart = all.find(d => d.name.toLowerCase().startsWith(q));
    if (byStart) return byStart;

    // Substring match
    const bySub = all.find(d => d.name.toLowerCase().includes(q) || (d.state && d.state.toLowerCase().includes(q)));
    if (bySub) return bySub;

    return null;
  }

  // =========================================================================
  // 2. DYNAMIC DESTINATION SEARCH & AUTOCOMPLETE
  // =========================================================================
  function setupDestinationAutocomplete() {
    const inputEl = document.getElementById('dest-search-input');
    const dropdownEl = document.getElementById('dest-autocomplete-dropdown');
    const hiddenIdEl = document.getElementById('selected-dest-id');
    const statusBadgeEl = document.getElementById('dest-status-badge');

    if (!inputEl || !dropdownEl) return;

    let highlightedIndex = -1;
    let currentMatches = [];

    function renderDropdown(matches) {
      currentMatches = matches;
      highlightedIndex = -1;

      if (!matches || matches.length === 0) {
        dropdownEl.innerHTML = `
          <div style="padding: 12px 16px; color: var(--text-muted); font-size: var(--text-xs);">
            No matching destinations found in website database. Please select an available destination.
          </div>
        `;
        dropdownEl.style.display = 'block';
        return;
      }

      dropdownEl.innerHTML = matches.map((d, idx) => {
        const themeIcon = (d.theme || '').includes('Beach') ? '🏖️' :
                          (d.theme || '').includes('Hill') || (d.theme || '').includes('Snow') ? '⛰️' :
                          (d.theme || '').includes('Spiritual') ? '🛕' :
                          (d.theme || '').includes('Backwater') || (d.theme || '').includes('Lake') ? '🛶' :
                          (d.theme || '').includes('Heritage') || (d.theme || '').includes('Fort') ? '🏰' : '📍';
        return `
          <div class="ai-autocomplete-item" data-index="${idx}">
            <div style="display: flex; align-items: center; gap: 10px; overflow: hidden;">
              <span style="font-size: 1.1rem;">${themeIcon}</span>
              <div style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                <strong style="color: var(--text-main); font-size: var(--text-sm);">${d.name}</strong>
                <div style="font-size: 11px; color: var(--text-muted);">
                  ${d.state ? d.state + ' • ' : ''}${d.region || 'India'}
                </div>
              </div>
            </div>
            <span style="font-size: 11px; font-weight: 600; color: var(--primary-color); background: var(--primary-light); padding: 2px 8px; border-radius: var(--radius-sm); white-space: nowrap;">
              ${d.avgBudget ? d.avgBudget.split('/')[0].trim() : 'Explore'}
            </span>
          </div>
        `;
      }).join('');

      dropdownEl.style.display = 'block';

      dropdownEl.querySelectorAll('.ai-autocomplete-item').forEach(item => {
        item.addEventListener('click', () => {
          const idx = parseInt(item.dataset.index, 10);
          selectDestination(currentMatches[idx]);
        });
      });
    }

    function selectDestination(dest) {
      if (!dest) return;
      selectedDestinationObj = dest;
      inputEl.value = dest.name;
      if (hiddenIdEl) hiddenIdEl.value = dest.id;
      dropdownEl.style.display = 'none';

      if (statusBadgeEl) {
        statusBadgeEl.innerHTML = `✓ Selected: <strong>${dest.name}</strong>`;
        statusBadgeEl.style.color = 'var(--success)';
      }
      clearFormError();
    }

    inputEl.addEventListener('input', (e) => {
      const val = e.target.value.trim().toLowerCase();
      selectedDestinationObj = null;
      if (hiddenIdEl) hiddenIdEl.value = '';

      if (statusBadgeEl) {
        statusBadgeEl.textContent = val.length > 0 ? 'Searching available destinations...' : 'No destination selected';
        statusBadgeEl.style.color = 'var(--text-subtle)';
      }

      if (val.length === 0) {
        dropdownEl.style.display = 'none';
        return;
      }

      const all = window.getAvailableDestinations();
      const filtered = all.filter(d => {
        const nameMatch = d.name.toLowerCase().includes(val);
        const stateMatch = (d.state || '').toLowerCase().includes(val);
        const regionMatch = (d.region || '').toLowerCase().includes(val);
        const tagMatch = (d.tags || []).some(t => t.toLowerCase().includes(val));
        return nameMatch || stateMatch || regionMatch || tagMatch;
      });

      renderDropdown(filtered);
    });

    inputEl.addEventListener('keydown', (e) => {
      if (dropdownEl.style.display === 'none') return;
      const items = dropdownEl.querySelectorAll('.ai-autocomplete-item');
      if (items.length === 0) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        highlightedIndex = Math.min(highlightedIndex + 1, items.length - 1);
        updateHighlight(items);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        highlightedIndex = Math.max(highlightedIndex - 1, 0);
        updateHighlight(items);
      } else if (e.key === 'Enter') {
        if (highlightedIndex >= 0 && currentMatches[highlightedIndex]) {
          e.preventDefault();
          selectDestination(currentMatches[highlightedIndex]);
        } else if (currentMatches.length === 1) {
          e.preventDefault();
          selectDestination(currentMatches[0]);
        }
      } else if (e.key === 'Escape') {
        dropdownEl.style.display = 'none';
      }
    });

    function updateHighlight(items) {
      items.forEach((item, idx) => {
        if (idx === highlightedIndex) {
          item.classList.add('active-item');
          item.scrollIntoView({ block: 'nearest' });
        } else {
          item.classList.remove('active-item');
        }
      });
    }

    // Close dropdown on outside click
    document.addEventListener('click', (e) => {
      if (!inputEl.contains(e.target) && !dropdownEl.contains(e.target)) {
        dropdownEl.style.display = 'none';
      }
    });

    // Check query params if user clicked from another page like destination.html
    const params = new URLSearchParams(window.location.search);
    const destParam = params.get('dest') || params.get('destination');
    if (destParam) {
      const match = findDestination(destParam);
      if (match) {
        selectDestination(match);
      }
    }
  }

  // =========================================================================
  // 3. FORM VALIDATION & DATE CALCULATION
  // =========================================================================
  function showFormError(msg) {
    const alertBox = document.getElementById('form-error-alert');
    const msgEl = document.getElementById('form-error-message');
    if (alertBox && msgEl) {
      msgEl.textContent = msg;
      alertBox.style.display = 'flex';
      alertBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  function clearFormError() {
    const alertBox = document.getElementById('form-error-alert');
    if (alertBox) alertBox.style.display = 'none';
  }

  function calculateDays(startDateStr, endDateStr) {
    if (!startDateStr || !endDateStr) return 0;
    const start = new Date(startDateStr);
    const end = new Date(endDateStr);
    const diffTime = end.getTime() - start.getTime();
    if (diffTime < 0) return -1;
    const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24)) + 1;
    return diffDays;
  }

  window.handleFormSubmit = async function (e) {
    e.preventDefault();
    clearFormError();

    const startingLocationInput = document.getElementById('starting-location-input');
    const destInput = document.getElementById('dest-search-input');
    const startDateInput = document.getElementById('trip-start-date');
    const endDateInput = document.getElementById('trip-end-date');
    const travelersInput = document.getElementById('trip-travelers');
    const budgetInput = document.getElementById('trip-budget');
    const currencySelect = document.getElementById('trip-currency');
    const travelStyleSelect = document.getElementById('trip-travel-style');
    const interestsInput = document.getElementById('trip-interests');

    const startingLocation = (startingLocationInput ? startingLocationInput.value : '').trim();
    const destQuery = (destInput ? destInput.value : '').trim();
    const startDate = (startDateInput ? startDateInput.value : '').trim();
    const endDate = (endDateInput ? endDateInput.value : '').trim();
    const travelers = parseInt((travelersInput ? travelersInput.value : '0'), 10);
    const budget = parseFloat((budgetInput ? budgetInput.value : '0'));
    const currency = (currencySelect ? currencySelect.value : 'INR');
    const travelStyle = (travelStyleSelect ? travelStyleSelect.value : '').trim();
    const interests = (interestsInput ? interestsInput.value : '').trim();

    // 0. Starting Location Validation
    if (!startingLocation) {
      showFormError("Please enter your starting city/location (Travelling From).");
      if (startingLocationInput) startingLocationInput.focus();
      return;
    }

    // 1. Destination Validation
    if (!destQuery) {
      showFormError("Please enter or select a destination from the website.");
      if (destInput) destInput.focus();
      return;
    }

    let destObj = selectedDestinationObj;
    if (!destObj) {
      destObj = findDestination(destQuery);
    }

    if (!destObj) {
      showFormError(`"${destQuery}" is not recognized as an existing destination on this website. Please choose from our available destinations.`);
      if (destInput) destInput.focus();
      return;
    }

    // 2. Start Date Validation
    if (!startDate) {
      showFormError("Please select your trip start date.");
      if (startDateInput) startDateInput.focus();
      return;
    }

    // 3. End Date Validation
    if (!endDate) {
      showFormError("Please select your trip end date.");
      if (endDateInput) endDateInput.focus();
      return;
    }

    const tripDays = calculateDays(startDate, endDate);
    if (tripDays <= 0) {
      showFormError("End date must be on or after the start date.");
      if (endDateInput) endDateInput.focus();
      return;
    }

    if (tripDays > 14) {
      showFormError("AI Itinerary Planner currently optimizes trips up to 14 days for optimal detail.");
      if (endDateInput) endDateInput.focus();
      return;
    }

    // 4. Travelers Validation
    if (!travelers || isNaN(travelers) || travelers < 1) {
      showFormError("Please enter a valid number of travelers (at least 1).");
      if (travelersInput) travelersInput.focus();
      return;
    }

    // 5. Budget Validation
    if (!budget || isNaN(budget) || budget <= 0) {
      showFormError("Please enter a valid total trip budget.");
      if (budgetInput) budgetInput.focus();
      return;
    }

    const minBudget = currency === 'USD' ? 50 : 1500;
    if (budget < minBudget) {
      showFormError(`Total budget must be at least ${currency === 'USD' ? '$50' : '₹1,500'}.`);
      if (budgetInput) budgetInput.focus();
      return;
    }

    // 6. Travel Style Validation
    if (!travelStyle) {
      showFormError("Please select your preferred travel style.");
      if (travelStyleSelect) travelStyleSelect.focus();
      return;
    }

    // Form is completely valid! Construct payload
    const tripInput = {
      startingLocation: startingLocation,
      destination: destObj.name,
      destinationObj: destObj,
      startDate: startDate,
      endDate: endDate,
      daysCount: tripDays,
      travelers: travelers,
      budget: budget,
      currency: currency,
      travelStyle: travelStyle,
      interests: interests
    };

    lastTripInput = tripInput;

    // Launch Simulated AI Loading and Generation
    await runAIGeneration(tripInput);
  };

  // =========================================================================
  // 4. SIMULATED AI LOADING EXPERIENCE
  // =========================================================================
  async function runAIGeneration(tripInput) {
    const formSection = document.getElementById('planner-form-section');
    const emptyState = document.getElementById('planner-empty-state');
    const loadingSection = document.getElementById('planner-loading-section');
    const resultsSection = document.getElementById('planner-result-section');
    const loadingHeading = document.getElementById('ai-loading-heading');

    if (emptyState) emptyState.style.display = 'none';
    if (resultsSection) resultsSection.style.display = 'none';
    if (formSection) formSection.style.display = 'none';
    if (loadingSection) loadingSection.style.display = 'block';

    const steps = [
      { el: document.getElementById('ai-step-1'), text: `Connecting to ${tripInput.destination} sights & database...` },
      { el: document.getElementById('ai-step-2'), text: `Selecting authentic places tailored for ${tripInput.travelStyle} style...` },
      { el: document.getElementById('ai-step-3'), text: `Optimizing budget allocation (${tripInput.currency === 'USD' ? '$' : '₹'}${tripInput.budget.toLocaleString()})...` },
      { el: document.getElementById('ai-step-4'), text: `Constructing ${tripInput.daysCount}-day personalized itinerary...` }
    ];

    // Reset steps UI
    steps.forEach((s, idx) => {
      if (s.el) {
        s.el.className = 'ai-step-item' + (idx === 0 ? ' active' : '');
      }
    });

    const stepDelay = 420; // Simulated AI timing per step

    for (let i = 0; i < steps.length; i++) {
      if (loadingHeading) {
        loadingHeading.textContent = steps[i].text;
      }
      if (steps[i].el) {
        steps[i].el.classList.add('active');
      }
      await new Promise(r => setTimeout(r, stepDelay));
      if (steps[i].el) {
        steps[i].el.classList.remove('active');
        steps[i].el.classList.add('done');
      }
    }

    // Call Generator function
    const generated = await generateItinerary(tripInput);
    currentItinerary = generated;
    activeDayIndex = 0;

    // Render results
    if (loadingSection) loadingSection.style.display = 'none';
    renderStructuredItinerary(currentItinerary);
    if (resultsSection) {
      resultsSection.style.display = 'block';
      resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  // =========================================================================
  // 5. MOCK AI ITINERARY GENERATOR: generateItinerary()
  // =========================================================================
  /**
   * Generates a structured mock itinerary using the selected destination's
   * actual existing data from MOCK_DATA.places.
   * 
   * Ready for future AI backend replacement:
   * async function generateItinerary(tripInput) {
   *   const res = await fetch('/api/itinerary-ai', { method: 'POST', body: JSON.stringify(tripInput) });
   *   return await res.json();
   * }
   */
  async function generateItinerary(tripInput) {
    const dest = tripInput.destinationObj;
    const daysCount = tripInput.daysCount;
    const travelers = tripInput.travelers;
    const totalBudget = tripInput.budget;
    const currency = tripInput.currency;
    const currSym = currency === 'USD' ? '$' : '₹';
    const travelStyle = tripInput.travelStyle;
    const interests = (tripInput.interests || '').toLowerCase();

    // 1. Gather authentic places for this destination from existing database
    let destPlaces = [];
    if (window.MOCK_DATA && Array.isArray(window.MOCK_DATA.places)) {
      destPlaces = window.MOCK_DATA.places.filter(p => p.destinationId === dest.id);
    }

    // If needed, check DestinationService synthesized places
    if (destPlaces.length < 3 && window.DestinationService && typeof window.DestinationService.getPlacesForDestination === 'function') {
      try {
        const fetched = await window.DestinationService.getPlacesForDestination(dest.id);
        if (Array.isArray(fetched) && fetched.length > 0) {
          destPlaces = fetched;
        }
      } catch (e) {
        console.warn("Could not retrieve extended places", e);
      }
    }

    // Fallback if destination has sparse places
    if (destPlaces.length === 0) {
      destPlaces = [
        {
          name: `${dest.name} Historic Heart`,
          category: "attractions",
          cost: "₹250",
          duration: "2.5 hours",
          description: `Signature cultural landmark in ${dest.name}.`
        },
        {
          name: `Authentic ${dest.name} Dining`,
          category: "food",
          cost: "₹450",
          duration: "1.5 hours",
          description: `Famous local delicacies and culinary heritage.`
        },
        {
          name: `${dest.name} Sunset Promenade`,
          category: "nature",
          cost: "Free Entry",
          duration: "2 hours",
          description: `Scenic views and tranquil evening atmosphere.`
        }
      ];
    }

    // 2. Budget Factor Calculation
    // Budget influences activities selection and estimated spending
    const dailyBudget = totalBudget / daysCount;
    const perPersonDailyBudget = dailyBudget / travelers;
    const isBudgetConscious = (currency === 'INR' && perPersonDailyBudget < 2500) || (currency === 'USD' && perPersonDailyBudget < 35);
    const isLuxury = (currency === 'INR' && perPersonDailyBudget > 8000) || (currency === 'USD' && perPersonDailyBudget > 120);

    // 3. Transportation Recommendation by destination theme
    function getTransitRecommendation(period, theme) {
      const t = (theme || '').toLowerCase();
      if (t.includes('hill') || t.includes('mountain') || t.includes('snow')) {
        return isLuxury ? "Private 4x4 Mountain Cab" : "Local Shared Taxi / Hired Scooter";
      }
      if (t.includes('backwater') || t.includes('island') || t.includes('beach')) {
        return isLuxury ? "Private Speedboat / AC Chauffeur" : "Local Tuk-Tuk / Tourist Ferry";
      }
      if (t.includes('city') || t.includes('metro')) {
        return isBudgetConscious ? "Metro Rail / AC City Bus" : "Ola / Uber Pre-paid Sedan";
      }
      return isBudgetConscious ? "E-Rickshaw / Auto Rickshaw" : "Chauffeur Tourist Taxi";
    }

    // 3b. Trip-level Transportation Recommendation (destination theme + budget + group size)
    function getTransportationRecommendation(theme) {
      const t = (theme || '').toLowerCase();
      const isGroup = travelers >= 4;
      let mode, category;

      if (t.includes('hill') || t.includes('mountain') || t.includes('snow')) {
        category = "Mountain / Hill Transport";
        if (isLuxury) mode = isGroup ? "Private 4x4 Mountain Cab (Group Booking)" : "Private 4x4 Mountain Cab";
        else if (isBudgetConscious) mode = isGroup ? "Shared Jeep / Local Bus" : "Local Shared Taxi / Hired Scooter";
        else mode = isGroup ? "Shared Taxi (Group Booking)" : "Local Shared Taxi / Hired Scooter";
      } else if (t.includes('backwater') || t.includes('island') || t.includes('beach')) {
        category = "Coastal / Water Transport";
        if (isLuxury) mode = "Private Speedboat / AC Chauffeur";
        else if (isBudgetConscious) mode = isGroup ? "Shared Tourist Ferry / Group Auto" : "Local Tuk-Tuk / Tourist Ferry";
        else mode = isGroup ? "Shared App-based Cab / Tourist Van" : "App-based Cab / Rental Scooter";
      } else if (t.includes('city') || t.includes('metro')) {
        category = "City Transport";
        if (isBudgetConscious) mode = "Metro Rail / AC City Bus";
        else if (isLuxury) mode = isGroup ? "Private Cab (Group Booking)" : "Private Cab / Premium Sedan";
        else mode = isGroup ? "Shared App-based Cab (Group)" : "Ola / Uber Pre-paid Sedan";
      } else {
        category = "Local Transport";
        if (isBudgetConscious) mode = "E-Rickshaw / Auto Rickshaw";
        else if (isLuxury) mode = "Chauffeur Tourist Taxi";
        else mode = isGroup ? "Shared Tourist Taxi (Group)" : "Local Taxi / Rental Scooter";
      }

      const budgetTier = isLuxury ? "higher" : isBudgetConscious ? "tighter" : "moderate";
      const groupNote = isGroup ? `shared across ${travelers} travelers` : `sized for ${travelers} traveler${travelers > 1 ? 's' : ''}`;
      const reason = `Matched to your ${budgetTier} per-person daily budget (${currSym}${Math.round(perPersonDailyBudget)}) and ${groupNote}, suited for a ${category.toLowerCase()} destination.`;

      return { mode, category, reason };
    }

    // 3c. Intercity "How to Reach" Recommendation (starting location -> destination)
    function getIntercityRecommendation() {
      const from = (tripInput.startingLocation || '').trim();
      const to = dest.name;
      const isGroup = travelers >= 4;

      // Distance proximity estimated from existing state/region data (no external APIs)
      const fromLower = from.toLowerCase();
      const stateLower = (dest.state || '').toLowerCase();
      const regionLower = (dest.region || '').toLowerCase();
      const regionZone = regionLower.split('/')[0].trim();

      let distanceCategory;
      if (stateLower && fromLower.includes(stateLower)) {
        distanceCategory = "Short";
      } else if (regionZone && fromLower.includes(regionZone)) {
        distanceCategory = "Medium";
      } else {
        distanceCategory = "Long";
      }

      // Mode selection: combines distance, per-person budget tier, group size & trip length
      let mode;
      if (distanceCategory === "Short") {
        mode = isLuxury ? "Private Car / Cab" : isBudgetConscious ? "Intercity Bus" : "Train (AC Chair Car)";
      } else if (distanceCategory === "Medium") {
        if (isBudgetConscious) mode = isGroup ? "Intercity Bus (Group Booking)" : "Train (Sleeper / 3AC)";
        else if (isLuxury) mode = isGroup ? "Train (2AC, Group Booking)" : "Flight";
        else mode = "Train (3AC / 2AC)";
      } else {
        if (isBudgetConscious) mode = isGroup ? "Train (Sleeper, Group Booking)" : "Train (Sleeper / 3AC)";
        else if (isLuxury) mode = "Flight";
        else mode = (daysCount <= 4 && !isGroup) ? "Flight" : "Train (2AC / 3AC)";
      }

      // Demo-estimate cost model (frontend-only, clearly marked as mock)
      const baseCostINR = { "Intercity Bus": 450, "Intercity Bus (Group Booking)": 400, "Train (Sleeper / 3AC)": 650,
        "Train (Sleeper, Group Booking)": 600, "Train (3AC / 2AC)": 900, "Train (2AC / 3AC)": 950,
        "Train (2AC, Group Booking)": 900, "Train (AC Chair Car)": 550, "Flight": 3200, "Private Car / Cab": 1500 };
      const distanceMultiplier = { Short: 1, Medium: 2.4, Long: 4.2 };
      const base = baseCostINR[mode] || 800;
      const mult = distanceMultiplier[distanceCategory];

      let estimatedCostPerPersonINR, estimatedGroupCostINR;
      if (mode === "Private Car / Cab") {
        // Shared vehicle: flat group cost, scales up slightly for larger groups needing bigger vehicle
        estimatedGroupCostINR = Math.round(base * mult * (isGroup ? 1.4 : 1));
        estimatedCostPerPersonINR = Math.round(estimatedGroupCostINR / travelers);
      } else {
        estimatedCostPerPersonINR = Math.round(base * mult);
        estimatedGroupCostINR = estimatedCostPerPersonINR * travelers;
      }

      const estimatedGroupCost = currency === 'USD' ? Math.round(estimatedGroupCostINR / 85) : estimatedGroupCostINR;
      const estimatedCostPerPerson = currency === 'USD' ? Math.round(estimatedCostPerPersonINR / 85) : estimatedCostPerPersonINR;

      const reason = `Recommended because this option fits your ${currSym}${Math.round(perPersonDailyBudget)} per-person daily budget for ${travelers} traveler${travelers > 1 ? 's' : ''} over a ${distanceCategory.toLowerCase()}-distance route.`;

      return {
        from,
        to,
        recommendedMode: mode,
        estimatedGroupCost,
        estimatedCostPerPerson,
        travelers,
        budgetPerPersonPerDay: Math.round(perPersonDailyBudget),
        reason,
        category: `Intercity Transport (${distanceCategory} Distance) — Estimated / Demo Estimate`
      };
    }

    // 4. Local Food Recommendation based on destination & style
    function getFoodRecommendation(period, destName, tags) {
      const d = destName.toLowerCase();
      if (d.includes('jaipur') || d.includes('rajasthan') || d.includes('udaipur')) {
        if (period === 'morning') return "Authentic Pyaaz Kachori & Masala Chai at historic city sweets stall";
        if (period === 'afternoon') return "Traditional Rajasthani Royal Thali with Dal Baati Churma and Gatte ki Sabzi";
        return "Rooftop dining with Lal Maas / Ker Sangri and live folk sarangi music";
      }
      if (d.includes('kerala') || d.includes('alleppey') || d.includes('munnar')) {
        if (period === 'morning') return "Steaming hot Idiyappam with coconut stew & fresh filter coffee";
        if (period === 'afternoon') return "Kerala Sadya feast served on fresh plantain banana leaf";
        return "Backwater fresh Karimeen Pollichathu (pearl spot fish baked in banana leaf)";
      }
      if (d.includes('goa')) {
        if (period === 'morning') return "Fresh Poi bread with Goan chorizo or cheese omelette & coconut water";
        if (period === 'afternoon') return "Authentic Goan Fish Curry Thali with Kingfish & sol kadhi";
        return "Candlelit beach shack dining with butter garlic prawns & Bebinca dessert";
      }
      if (d.includes('varanasi')) {
        if (period === 'morning') return "Traditional hot Kachori Jalebi breakfast near Godowlia crossing";
        if (period === 'afternoon') return "Pure vegetarian sattvic thali followed by famous chilled Kashi lassi";
        return "Banarasi Tamatar Chaat and world-renowned fragrant Banarasi Paan";
      }
      if (d.includes('manali') || d.includes('ladakh') || d.includes('darjeeling')) {
        if (period === 'morning') return "Warm butter tea, freshly baked cinnamon rolls & apple crumble";
        if (period === 'afternoon') return "Steaming Himalayan Thukpa noodle soup and authentic handmade Momos";
        return "Local trout preparation or authentic Tibetan Tingmo with herbal spiced broth";
      }
      if (d.includes('amritsar')) {
        if (period === 'morning') return "Crispy Amritsari Kulcha topped with melting butter & tall glass of lassi";
        if (period === 'afternoon') return "Revered sacred community Langar meal inside Sri Harmandir Sahib";
        return "Iconic Maa ki Dal, Butter Chicken / Paneer Bhurji at historic dhabas";
      }
      // General authentic Indian cuisine fallback
      if (period === 'morning') return `Regional specialty breakfast & artisanal morning tea in ${destName}`;
      if (period === 'afternoon') return `Curated local thali showcasing authentic spices of ${destName}`;
      return `Atmospheric dinner featuring traditional delicacies and local flavors of ${destName}`;
    }

    // 5. Travel Tips generator
    function getTravelTip(dayIdx, period, destObj, style) {
      const tips = [
        `Carry a refillable water bottle and comfortable walking shoes for heritage exploration.`,
        `Local artisans appreciate respectful bargaining; carry small cash denominations in ${currSym}.`,
        `Early mornings provide the clearest photo lighting and avoid major tourist queues.`,
        `Respect local dress codes: keep shoulders and knees covered when entering sacred shrines.`,
        `Hire only licensed government guides (ASI registered) for rich authentic lore.`,
        `Golden hour right before sunset offers breathtaking panoramic viewpoints in ${destObj.name}.`
      ];
      return tips[(dayIdx * 3 + (period === 'morning' ? 0 : period === 'afternoon' ? 1 : 2)) % tips.length];
    }

    // 6. Build Day-by-Day schedule
    const days = [];
    const startDateObj = new Date(tripInput.startDate);

    for (let i = 0; i < daysCount; i++) {
      const currentDayDate = new Date(startDateObj);
      currentDayDate.setDate(startDateObj.getDate() + i);
      const dateString = currentDayDate.toLocaleDateString('en-IN', {
        weekday: 'short',
        month: 'short',
        day: 'numeric'
      });

      // Distribute places across days
      const morningPlace = destPlaces[(i * 3) % destPlaces.length];
      const afternoonPlace = destPlaces[(i * 3 + 1) % destPlaces.length];
      const eveningPlace = destPlaces[(i * 3 + 2) % destPlaces.length];

      // Cost estimation tailored to budget and place cost
      function parseOrEstimateCost(place, baseINR) {
        if (place && place.cost && place.cost.toLowerCase().includes('free')) {
          return `${currSym}0 (Free Entry)`;
        }
        if (isBudgetConscious) {
          const c = Math.round(baseINR * 0.6);
          return currency === 'USD' ? `$${Math.max(2, Math.round(c / 85))}` : `₹${c}`;
        }
        if (isLuxury) {
          const c = Math.round(baseINR * 1.8);
          return currency === 'USD' ? `$${Math.round(c / 85)}` : `₹${c}`;
        }
        const c = baseINR;
        return currency === 'USD' ? `$${Math.max(3, Math.round(c / 85))}` : `₹${c}`;
      }

      const dayObj = {
        dayNumber: i + 1,
        date: dateString,
        title: i === 0 ? `Arrival & First Impressions of ${dest.name}` :
               i === daysCount - 1 ? `Final Highlights & Souvenirs of ${dest.name}` :
               `Immersive ${dest.theme || 'Cultural'} Discoveries (Day ${i + 1})`,
        morning: {
          period: "Morning",
          time: "08:30 AM – 11:30 AM",
          activity: morningPlace ? morningPlace.name : `Morning Cultural Heritage Tour`,
          location: morningPlace && morningPlace.distanceFromCenter ? `${morningPlace.distanceFromCenter} from Center` : dest.name,
          duration: morningPlace && morningPlace.duration ? morningPlace.duration : "2.5 hours",
          estimatedCost: parseOrEstimateCost(morningPlace, 350),
          description: morningPlace && morningPlace.description ? morningPlace.description : `Explore the architectural and scenic heritage of ${dest.name}.`,
          transport: getTransitRecommendation('morning', dest.theme),
          food: getFoodRecommendation('morning', dest.name, dest.tags),
          tip: getTravelTip(i, 'morning', dest, travelStyle)
        },
        afternoon: {
          period: "Afternoon",
          time: "12:30 PM – 04:00 PM",
          activity: afternoonPlace ? afternoonPlace.name : `Historic Sights & Artisan Quarter`,
          location: afternoonPlace && afternoonPlace.distanceFromCenter ? `${afternoonPlace.distanceFromCenter}` : dest.name,
          duration: afternoonPlace && afternoonPlace.duration ? afternoonPlace.duration : "3 hours",
          estimatedCost: parseOrEstimateCost(afternoonPlace, 450),
          description: afternoonPlace && afternoonPlace.description ? afternoonPlace.description : `Immerse in authentic regional art, landmarks, and traditions.`,
          transport: getTransitRecommendation('afternoon', dest.theme),
          food: getFoodRecommendation('afternoon', dest.name, dest.tags),
          tip: getTravelTip(i, 'afternoon', dest, travelStyle)
        },
        evening: {
          period: "Evening",
          time: "05:00 PM – 08:30 PM",
          activity: eveningPlace ? eveningPlace.name : `Sunset Overlook & Local Night Bazaar`,
          location: eveningPlace && eveningPlace.distanceFromCenter ? `${eveningPlace.distanceFromCenter}` : dest.name,
          duration: eveningPlace && eveningPlace.duration ? eveningPlace.duration : "2 hours",
          estimatedCost: parseOrEstimateCost(eveningPlace, 250),
          description: eveningPlace && eveningPlace.description ? eveningPlace.description : `Enjoy starlit views, vibrant markets, and regional dining.`,
          transport: getTransitRecommendation('evening', dest.theme),
          food: getFoodRecommendation('evening', dest.name, dest.tags),
          tip: getTravelTip(i, 'evening', dest, travelStyle)
        }
      };

      days.push(dayObj);
    }

    // 7. Budget Breakdown Allocations
    // Clean proportional breakdown based on travel industry benchmarks
    const accommodationPercent = 38;
    const foodPercent = 24;
    const transitPercent = 16;
    const activitiesPercent = 14;
    const miscPercent = 8;

    const accommodationEst = Math.round(totalBudget * (accommodationPercent / 100));
    const foodEst = Math.round(totalBudget * (foodPercent / 100));
    const transitEst = Math.round(totalBudget * (transitPercent / 100));
    const activitiesEst = Math.round(totalBudget * (activitiesPercent / 100));
    const miscEst = Math.round(totalBudget * (miscPercent / 100));

    // Calculate total estimated spending (~92% of budget to ensure realistic buffer)
    const totalEstimatedSpending = Math.round(totalBudget * 0.92);
    const remainingBudget = Math.max(0, totalBudget - totalEstimatedSpending);

    // 7b. Intercity "How to Reach" estimate — separate from Local Transportation below,
    // integrated against the remaining buffer so it doesn't duplicate the transit category total.
    const intercityTransport = getIntercityRecommendation();
    const remainingAfterIntercity = remainingBudget - intercityTransport.estimatedGroupCost;

    // 7c. Recommended Local Transportation (trip-level, reuses transitEst from budget breakdown)
    const transportPick = getTransportationRecommendation(dest.theme);
    const recommendedTransport = {
      recommendedMode: transportPick.mode,
      category: transportPick.category,
      estimatedCost: transitEst,
      costPerPerson: Math.round(transitEst / travelers),
      travelers: travelers,
      budgetPerPersonPerDay: Math.round(perPersonDailyBudget),
      reason: transportPick.reason,
      currencySymbol: currSym
    };

    const budgetBreakdown = {
      totalBudget: totalBudget,
      currency: currency,
      currencySymbol: currSym,
      estimatedTotalSpending: totalEstimatedSpending,
      remainingBuffer: remainingBudget,
      remainingAfterIntercity: remainingAfterIntercity,
      categories: [
        { name: "Accommodation & Stay", amount: accommodationEst, percentage: accommodationPercent, color: "#0d9488" },
        { name: "Food & Culinary Dining", amount: foodEst, percentage: foodPercent, color: "#f59e0b" },
        { name: "Local Transportation", amount: transitEst, percentage: transitPercent, color: "#6366f1" },
        { name: "Sightseeing & Entry Tickets", amount: activitiesEst, percentage: activitiesPercent, color: "#10b981" },
        { name: "Miscellaneous / Buffer", amount: miscEst, percentage: miscPercent, color: "#94a3b8" }
      ],
      recommendedTransport: recommendedTransport
    };

    return {
      id: `itin-${Date.now()}`,
      generatedAt: new Date().toISOString(),
      destination: dest.name,
      destinationObj: dest,
      startDate: tripInput.startDate,
      endDate: tripInput.endDate,
      daysCount: daysCount,
      travelers: travelers,
      travelStyle: travelStyle,
      interests: tripInput.interests,
      startingLocation: tripInput.startingLocation,
      budgetBreakdown: budgetBreakdown,
      recommendedTransport: recommendedTransport,
      intercityTransport: intercityTransport,
      days: days
    };
  }

  // =========================================================================
  // 6. UI RENDERERS
  // =========================================================================
  function renderStructuredItinerary(itin) {
    if (!itin) return;

    renderTripOverview(itin);
    renderDayTabs(itin);
    renderActiveDayContent(itin, activeDayIndex);
    renderBudgetBreakdown(itin);
  }

  function renderTripOverview(itin) {
    const cardEl = document.getElementById('itinerary-overview-card');
    if (!cardEl) return;

    const dest = itin.destinationObj || {};
    const sym = itin.budgetBreakdown.currencySymbol;

    cardEl.innerHTML = `
      <div class="itinerary-hero-split">
        <div class="itinerary-hero-media">
          <img src="${dest.heroImage || 'https://images.unsplash.com/photo-1599661046289-e31897846e41?w=800&auto=format&fit=crop'}" alt="${itin.destination}">
          <div class="itinerary-hero-badge">
            <span>✨ AI Planned Itinerary</span>
          </div>
        </div>

        <div class="itinerary-hero-content">
          <div>
            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: var(--space-3); flex-wrap: wrap;">
              <div>
                <span class="badge badge-primary" style="margin-bottom: var(--space-2); display: inline-block;">
                  ${dest.theme || 'Indian Circuit'}
                </span>
                <h2 style="color: var(--text-main); font-size: var(--text-2xl); margin: 0; line-height: 1.2;">
                  ${itin.daysCount}-Day Expedition to ${itin.destination}
                </h2>
                <p style="color: var(--text-muted); font-size: var(--text-xs); margin-top: 4px;">
                  ${dest.tagline || dest.description || 'Custom curated journey across Incredible India'}
                </p>
              </div>

              <!-- Link to existing destination page -->
              <a href="destination.html?dest=${encodeURIComponent(dest.id || itin.destination)}" class="btn btn-outline btn-sm btn-link-dest" style="font-weight: 600;">
                Explore ${dest.name.split(',')[0]} Page →
              </a>
            </div>

            <!-- Parameters ribbon -->
            <div class="itinerary-param-chips">
              ${itin.startingLocation ? `
                <div class="itinerary-chip">
                  <span>🧳</span>
                  <span>From: <strong>${itin.startingLocation}</strong></span>
                </div>
              ` : ''}
              <div class="itinerary-chip">
                <span>📅</span>
                <span>Dates: <strong>${itin.startDate} to ${itin.endDate}</strong></span>
              </div>
              <div class="itinerary-chip">
                <span>⏳</span>
                <span>Duration: <strong>${itin.daysCount} Days / ${Math.max(1, itin.daysCount - 1)} Nights</strong></span>
              </div>
              <div class="itinerary-chip">
                <span>👥</span>
                <span>Travelers: <strong>${itin.travelers} ${itin.travelers === 1 ? 'Person' : 'People'}</strong></span>
              </div>
              <div class="itinerary-chip">
                <span>🎒</span>
                <span>Style: <strong>${itin.travelStyle}</strong></span>
              </div>
              <div class="itinerary-chip">
                <span>💰</span>
                <span>Budget: <strong>${sym}${itin.budgetBreakdown.totalBudget.toLocaleString()}</strong></span>
              </div>
              ${itin.interests ? `
                <div class="itinerary-chip">
                  <span>✨</span>
                  <span>Interests: <strong>${itin.interests}</strong></span>
                </div>
              ` : ''}
            </div>
          </div>

          <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--border-color); padding-top: var(--space-3); margin-top: var(--space-3);">
            <div style="font-size: var(--text-xs); color: var(--text-muted);">
              Best Season: <strong style="color: var(--text-main);">${dest.bestTimeToVisit || 'October - March'}</strong>
            </div>
            <div style="font-size: var(--text-xs); color: var(--text-subtle);">
              Status: <span style="color: var(--success); font-weight: 600;">● Ready to Travel</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function renderDayTabs(itin) {
    const tabsEl = document.getElementById('ai-day-tabs');
    if (!tabsEl) return;

    tabsEl.innerHTML = itin.days.map((day, idx) => `
      <button 
        type="button" 
        class="ai-day-tab ${idx === activeDayIndex ? 'active' : ''}" 
        onclick="switchDayTab(${idx})"
      >
        Day ${day.dayNumber} (${day.date})
      </button>
    `).join('') + `
      <button 
        type="button" 
        class="ai-day-tab ${activeDayIndex === -1 ? 'active' : ''}" 
        onclick="switchDayTab(-1)"
        style="margin-left: auto;"
      >
        View Full Itinerary (All Days)
      </button>
    `;
  }

  window.switchDayTab = function (idx) {
    activeDayIndex = idx;
    if (currentItinerary) {
      renderDayTabs(currentItinerary);
      renderActiveDayContent(currentItinerary, activeDayIndex);
    }
  };

  function renderActiveDayContent(itin, dayIdx) {
    const containerEl = document.getElementById('ai-day-content-container');
    if (!containerEl) return;

    const daysToRender = dayIdx === -1 ? itin.days : [itin.days[dayIdx]];

    containerEl.innerHTML = daysToRender.map(day => `
      <div class="ai-day-section" style="margin-bottom: var(--space-8);">
        <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: var(--space-4); border-bottom: 1px solid var(--border-color); padding-bottom: var(--space-2);">
          <div>
            <h3 style="color: var(--text-main); font-size: var(--text-xl); margin: 0;">
              Day ${day.dayNumber}: ${day.title}
            </h3>
            <span style="font-size: var(--text-xs); color: var(--text-muted);">
              ${day.date} • Tailored for ${itin.travelStyle} style
            </span>
          </div>
          <span style="font-size: var(--text-xs); font-weight: 600; color: var(--primary-color);">
            3 Scheduled Stops
          </span>
        </div>

        <!-- MORNING SLOT -->
        <div class="ai-slot-card">
          <div class="ai-slot-header">
            <div class="ai-slot-period morning">
              <span>🌅 Morning</span>
              <span style="color: var(--text-subtle); font-weight: normal;">• ${day.morning.time}</span>
            </div>
            <span class="ai-slot-cost-pill">
              Estimated: ${day.morning.estimatedCost}
            </span>
          </div>
          <h4 style="font-size: var(--text-base); color: var(--text-main); margin-bottom: 4px;">
            ${day.morning.activity}
          </h4>
          <p style="font-size: var(--text-xs); color: var(--text-muted); margin-bottom: var(--space-2);">
            ${day.morning.description}
          </p>
          <div class="ai-slot-details">
            <div class="ai-detail-block">
              <span>📍</span>
              <div>Location: <strong>${day.morning.location}</strong> (${day.morning.duration})</div>
            </div>
            <div class="ai-detail-block">
              <span>🚖</span>
              <div>Transit: <strong>${day.morning.transport}</strong></div>
            </div>
            <div class="ai-detail-block">
              <span>☕</span>
              <div>Food: <strong>${day.morning.food}</strong></div>
            </div>
            <div class="ai-detail-block">
              <span>💡</span>
              <div>Tip: <em>${day.morning.tip}</em></div>
            </div>
          </div>
        </div>

        <!-- AFTERNOON SLOT -->
        <div class="ai-slot-card">
          <div class="ai-slot-header">
            <div class="ai-slot-period afternoon">
              <span>☀️ Afternoon</span>
              <span style="color: var(--text-subtle); font-weight: normal;">• ${day.afternoon.time}</span>
            </div>
            <span class="ai-slot-cost-pill">
              Estimated: ${day.afternoon.estimatedCost}
            </span>
          </div>
          <h4 style="font-size: var(--text-base); color: var(--text-main); margin-bottom: 4px;">
            ${day.afternoon.activity}
          </h4>
          <p style="font-size: var(--text-xs); color: var(--text-muted); margin-bottom: var(--space-2);">
            ${day.afternoon.description}
          </p>
          <div class="ai-slot-details">
            <div class="ai-detail-block">
              <span>📍</span>
              <div>Location: <strong>${day.afternoon.location}</strong> (${day.afternoon.duration})</div>
            </div>
            <div class="ai-detail-block">
              <span>🚖</span>
              <div>Transit: <strong>${day.afternoon.transport}</strong></div>
            </div>
            <div class="ai-detail-block">
              <span>🍛</span>
              <div>Food: <strong>${day.afternoon.food}</strong></div>
            </div>
            <div class="ai-detail-block">
              <span>💡</span>
              <div>Tip: <em>${day.afternoon.tip}</em></div>
            </div>
          </div>
        </div>

        <!-- EVENING SLOT -->
        <div class="ai-slot-card">
          <div class="ai-slot-header">
            <div class="ai-slot-period evening">
              <span>🌙 Evening</span>
              <span style="color: var(--text-subtle); font-weight: normal;">• ${day.evening.time}</span>
            </div>
            <span class="ai-slot-cost-pill">
              Estimated: ${day.evening.estimatedCost}
            </span>
          </div>
          <h4 style="font-size: var(--text-base); color: var(--text-main); margin-bottom: 4px;">
            ${day.evening.activity}
          </h4>
          <p style="font-size: var(--text-xs); color: var(--text-muted); margin-bottom: var(--space-2);">
            ${day.evening.description}
          </p>
          <div class="ai-slot-details">
            <div class="ai-detail-block">
              <span>📍</span>
              <div>Location: <strong>${day.evening.location}</strong> (${day.evening.duration})</div>
            </div>
            <div class="ai-detail-block">
              <span>🚖</span>
              <div>Transit: <strong>${day.evening.transport}</strong></div>
            </div>
            <div class="ai-detail-block">
              <span>🍽️</span>
              <div>Food: <strong>${day.evening.food}</strong></div>
            </div>
            <div class="ai-detail-block">
              <span>💡</span>
              <div>Tip: <em>${day.evening.tip}</em></div>
            </div>
          </div>
        </div>
      </div>
    `).join('');
  }

  function renderBudgetBreakdown(itin) {
    const budgetEl = document.getElementById('ai-budget-container');
    if (!budgetEl) return;

    const b = itin.budgetBreakdown;
    const sym = b.currencySymbol;

    budgetEl.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: var(--space-4); margin-bottom: var(--space-5);">
        <div>
          <span class="badge" style="background: rgba(13, 148, 136, 0.12); color: var(--primary-color); border: 1px solid rgba(13, 148, 136, 0.25);">
            💰 AI Budget Breakdown
          </span>
          <h3 style="color: var(--text-main); margin-top: var(--space-2); margin-bottom: 4px;">
            Estimated Trip Budget Allocations
          </h3>
          <p style="font-size: var(--text-xs); color: var(--text-muted);">
            Proportional financial forecast based on your total entered budget of <strong>${sym}${b.totalBudget.toLocaleString()}</strong>.
          </p>
        </div>

        <div style="display: flex; gap: var(--space-4); flex-wrap: wrap;">
          <div style="background: var(--bg-subtle); padding: 10px 16px; border-radius: var(--radius-md); border: 1px solid var(--border-color); text-align: center;">
            <div style="font-size: var(--text-xs); color: var(--text-muted);">Estimated Total Spending</div>
            <div style="font-size: var(--text-lg); font-weight: var(--font-bold); color: var(--text-main);">
              ${sym}${b.estimatedTotalSpending.toLocaleString()}
            </div>
          </div>

          <div style="background: var(--bg-subtle); padding: 10px 16px; border-radius: var(--radius-md); border: 1px solid var(--border-color); text-align: center;">
            <div style="font-size: var(--text-xs); color: var(--text-muted);">Remaining Buffer</div>
            <div style="font-size: var(--text-lg); font-weight: var(--font-bold); color: var(--success);">
              ${sym}${b.remainingBuffer.toLocaleString()}
            </div>
          </div>
        </div>
      </div>

      <!-- Categories Progress Bars -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: var(--space-4); margin-bottom: var(--space-6);">
        ${b.categories.map(cat => `
          <div class="ai-budget-meter-row">
            <div class="ai-meter-header">
              <span style="color: var(--text-main);">${cat.name} (${cat.percentage}%)</span>
              <span style="color: var(--text-muted); font-weight: 600;">${sym}${cat.amount.toLocaleString()}</span>
            </div>
            <div class="ai-progress-track">
              <div class="ai-progress-fill" style="width: ${cat.percentage}%; background-color: ${cat.color};"></div>
            </div>
          </div>
        `).join('')}
      </div>

      ${(() => {
        const ic = b.intercityTransport;
        if (!ic) return '';
        return `
        <!-- Intercity "How to Reach" (compact) -->
        <div style="background: var(--bg-subtle); border: 1px solid var(--border-color); border-left: 4px solid #f59e0b; border-radius: var(--radius-sm); padding: var(--space-3) var(--space-4); margin-bottom: var(--space-4);">
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: var(--space-2); margin-bottom: 6px;">
            <span style="font-size: var(--text-xs); font-weight: 700; color: #f59e0b;">🚆 How to Reach (${ic.from} → ${ic.to})</span>
            <span style="font-size: var(--text-xs); color: var(--text-muted);">Estimated / Demo Estimate</span>
          </div>
          <div style="font-size: var(--text-sm); color: var(--text-main); font-weight: 600; margin-bottom: 4px;">
            ${ic.recommendedMode}
          </div>
          <div style="font-size: var(--text-xs); color: var(--text-muted); margin-bottom: 6px;">
            Estimated: <strong>${sym}${ic.estimatedGroupCost.toLocaleString()}</strong> for group
            (~${sym}${ic.estimatedCostPerPerson.toLocaleString()} per person, ${ic.travelers} traveler${ic.travelers > 1 ? 's' : ''})
          </div>
          <div style="font-size: var(--text-xs); color: var(--text-muted);">
            ${ic.reason}
          </div>
          <div style="font-size: 11px; color: var(--text-subtle); margin-top: 6px;">
            Separate from Local Transportation below. Not included in the transit budget category; check against your remaining buffer (${sym}${b.remainingAfterIntercity.toLocaleString()} after this estimate).
          </div>
        </div>
        `;
      })()}

      ${(() => {
        const rt = b.recommendedTransport;
        if (!rt) return '';
        return `
        <!-- Recommended Local Transportation (compact) -->
        <div style="background: var(--bg-subtle); border: 1px solid var(--border-color); border-left: 4px solid #6366f1; border-radius: var(--radius-sm); padding: var(--space-3) var(--space-4); margin-bottom: var(--space-4);">
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: var(--space-2); margin-bottom: 6px;">
            <span style="font-size: var(--text-xs); font-weight: 700; color: #6366f1;">🚐 Recommended Local Transportation (${rt.category})</span>
            <span style="font-size: var(--text-xs); color: var(--text-muted);">Estimated, mock data</span>
          </div>
          <div style="font-size: var(--text-sm); color: var(--text-main); font-weight: 600; margin-bottom: 4px;">
            ${rt.recommendedMode}
          </div>
          <div style="font-size: var(--text-xs); color: var(--text-muted); margin-bottom: 6px;">
            Estimated: <strong>${sym}${rt.estimatedCost.toLocaleString()}</strong> total
            (~${sym}${rt.costPerPerson.toLocaleString()} per person, ${rt.travelers} traveler${rt.travelers > 1 ? 's' : ''})
          </div>
          <div style="font-size: var(--text-xs); color: var(--text-muted);">
            ${rt.reason}
          </div>
        </div>
        `;
      })()}

      <!-- Disclaimers Notice -->
      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-left: 4px solid var(--primary-color); padding: var(--space-3) var(--space-4); border-radius: var(--radius-sm); font-size: var(--text-xs); color: var(--text-muted);">
        <strong>Estimated Cost Notice:</strong> Demo estimate — actual prices will require live data / API integration. Accommodation, meals, local transit and entrance fees may fluctuate with seasonal demand.
      </div>
    `;
  }

  // =========================================================================
  // 7. RESULTS ACTIONS (Edit, Regenerate, Save, Print, Download)
  // =========================================================================
  window.handleEditTrip = function () {
    const formSection = document.getElementById('planner-form-section');
    const resultsSection = document.getElementById('planner-result-section');

    if (formSection) {
      formSection.style.display = 'block';
      formSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (resultsSection) {
      // Keep results visible below form so user can review while editing
    }
  };

  window.handleRegenerate = async function () {
    if (!lastTripInput) return;
    // Shuffle or re-run generator with same parameters
    await runAIGeneration(lastTripInput);
  };

  window.handleSaveItinerary = function () {
    if (!currentItinerary) return;

    try {
      const storageKey = 'WW_SAVED_AI_ITINERARIES';
      const existing = JSON.parse(localStorage.getItem(storageKey) || '[]');
      existing.unshift(currentItinerary);
      // Keep up to 10 itineraries
      localStorage.setItem(storageKey, JSON.stringify(existing.slice(0, 10)));

      // Also register as an active trip in WanderStorage if available
      if (window.WanderStorage && typeof window.WanderStorage.saveTrip === 'function') {
        const tripRecord = {
          id: currentItinerary.id,
          title: `${currentItinerary.daysCount}-Day ${currentItinerary.destination}`,
          destination: currentItinerary.destination,
          destinationId: currentItinerary.destinationObj ? currentItinerary.destinationObj.id : 'dest-custom',
          startDate: currentItinerary.startDate,
          endDate: currentItinerary.endDate,
          daysCount: currentItinerary.daysCount,
          travelersCount: currentItinerary.travelers,
          totalBudget: currentItinerary.budgetBreakdown.totalBudget,
          spentBudget: 0,
          status: "Upcoming",
          coverPhoto: currentItinerary.destinationObj ? currentItinerary.destinationObj.heroImage : ''
        };
        window.WanderStorage.saveTrip(tripRecord);
      }

      const indicator = document.getElementById('save-status-indicator');
      if (indicator) {
        indicator.style.display = 'inline-block';
        indicator.textContent = '✓ Saved locally to browser';
        setTimeout(() => {
          indicator.style.display = 'none';
        }, 3000);
      }
    } catch (e) {
      console.error("Could not save itinerary to localStorage", e);
      alert("Itinerary saved in browser session.");
    }
  };

  window.handlePrintItinerary = function () {
    // Switch to all days for printing
    if (currentItinerary) {
      renderActiveDayContent(currentItinerary, -1);
    }
    window.print();
  };

  window.handleDownloadItinerary = function () {
    if (!currentItinerary) return;

    const itin = currentItinerary;
    const sym = itin.budgetBreakdown.currencySymbol;

    let textContent = `====================================================\n`;
    textContent += `WANDERWISE INDIA - AI ITINERARY PLANNER\n`;
    textContent += `Travelling From: ${itin.startingLocation || 'N/A'}\n`;
    textContent += `Destination: ${itin.destination}\n`;
    textContent += `Dates: ${itin.startDate} to ${itin.endDate} (${itin.daysCount} Days)\n`;
    textContent += `Travelers: ${itin.travelers} | Style: ${itin.travelStyle}\n`;
    textContent += `Total Budget: ${sym}${itin.budgetBreakdown.totalBudget.toLocaleString()}\n`;
    textContent += `Estimated Spending: ${sym}${itin.budgetBreakdown.estimatedTotalSpending.toLocaleString()} (Demo estimate)\n`;
    textContent += `====================================================\n\n`;

    itin.days.forEach(day => {
      textContent += `----------------------------------------------------\n`;
      textContent += `DAY ${day.dayNumber}: ${day.title} (${day.date})\n`;
      textContent += `----------------------------------------------------\n`;
      
      textContent += `[MORNING: ${day.morning.time}]\n`;
      textContent += `Activity: ${day.morning.activity}\n`;
      textContent += `Location: ${day.morning.location} (Duration: ${day.morning.duration})\n`;
      textContent += `Estimated Cost: ${day.morning.estimatedCost}\n`;
      textContent += `Transit: ${day.morning.transport}\n`;
      textContent += `Food Suggestion: ${day.morning.food}\n`;
      textContent += `Tip: ${day.morning.tip}\n\n`;

      textContent += `[AFTERNOON: ${day.afternoon.time}]\n`;
      textContent += `Activity: ${day.afternoon.activity}\n`;
      textContent += `Location: ${day.afternoon.location} (Duration: ${day.afternoon.duration})\n`;
      textContent += `Estimated Cost: ${day.afternoon.estimatedCost}\n`;
      textContent += `Transit: ${day.afternoon.transport}\n`;
      textContent += `Food Suggestion: ${day.afternoon.food}\n`;
      textContent += `Tip: ${day.afternoon.tip}\n\n`;

      textContent += `[EVENING: ${day.evening.time}]\n`;
      textContent += `Activity: ${day.evening.activity}\n`;
      textContent += `Location: ${day.evening.location} (Duration: ${day.evening.duration})\n`;
      textContent += `Estimated Cost: ${day.evening.estimatedCost}\n`;
      textContent += `Transit: ${day.evening.transport}\n`;
      textContent += `Food Suggestion: ${day.evening.food}\n`;
      textContent += `Tip: ${day.evening.tip}\n\n`;
    });

    if (itin.intercityTransport) {
      const ic = itin.intercityTransport;
      textContent += `====================================================\n`;
      textContent += `HOW TO REACH (${ic.from} -> ${ic.to}) - Estimated / Demo Estimate\n`;
      textContent += `Recommended Mode: ${ic.recommendedMode}\n`;
      textContent += `Estimated Group Cost: ${sym}${ic.estimatedGroupCost.toLocaleString()} (~${sym}${ic.estimatedCostPerPerson.toLocaleString()} per person)\n`;
      textContent += `${ic.reason}\n\n`;
    }

    textContent += `====================================================\n`;
    textContent += `BUDGET BREAKDOWN (${sym})\n`;
    itin.budgetBreakdown.categories.forEach(c => {
      textContent += `- ${c.name} (${c.percentage}%): ${sym}${c.amount.toLocaleString()}\n`;
    });
    textContent += `\n* Notice: Demo estimate — actual prices will require live data/API integration.\n`;
    textContent += `Generated by WanderWise India AI Engine: https://wanderwise.in\n`;

    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const filename = `Itinerary_${itin.destination.replace(/[^a-zA-Z0-9]+/g, '_')}_${itin.daysCount}Days.txt`;
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
  };

  window.resetPlannerForm = function () {
    const form = document.getElementById('ai-itinerary-form');
    if (form) form.reset();
    selectedDestinationObj = null;
    const hiddenIdEl = document.getElementById('selected-dest-id');
    if (hiddenIdEl) hiddenIdEl.value = '';
    const statusBadgeEl = document.getElementById('dest-status-badge');
    if (statusBadgeEl) {
      statusBadgeEl.textContent = 'No destination selected';
      statusBadgeEl.style.color = 'var(--text-subtle)';
    }
    clearFormError();
  };

  // =========================================================================
  // 8. INITIALIZATION
  // =========================================================================
  function initPlanner() {
    // Sync header auth & storage if WanderStorage available
    if (window.WanderStorage) {
      window.WanderStorage.init();
      window.WanderStorage.syncHeaderAuth();
      window.WanderStorage.setupMobileNavToggle();
    }

    // Set minimum date to today for date pickers
    const todayStr = new Date().toISOString().split('T')[0];
    const startDateInput = document.getElementById('trip-start-date');
    const endDateInput = document.getElementById('trip-end-date');
    if (startDateInput) startDateInput.min = todayStr;
    if (endDateInput) endDateInput.min = todayStr;

    // Dynamically update end date minimum when start date is picked
    if (startDateInput && endDateInput) {
      startDateInput.addEventListener('change', () => {
        if (startDateInput.value) {
          endDateInput.min = startDateInput.value;
          if (endDateInput.value && endDateInput.value < startDateInput.value) {
            endDateInput.value = startDateInput.value;
          }
        }
      });
    }

    // Attach dynamic destination autocomplete
    setupDestinationAutocomplete();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPlanner);
  } else {
    initPlanner();
  }
})();
