/**
 * WANDERWISE - DESTINATION EXPLORER (destination.js)
 * Full dynamic behavior for destination.html:
 * - Real-time lookup of destinations & places from MOCK_DATA (or public API)
 * - Dynamic Hero banner (photo, description, best season, costs, rating)
 * - Categorized sections: Attractions, Food & Restaurants, Nightlife, Nature/Outdoors, Museums & Culture, Shopping
 * - Interactive client-side OpenStreetMap / Leaflet map with category-coded pins & rich popups
 * - Real-time search & filtering by Rating, Price Level, and Category
 * - "Add to Trip" modal writing directly to trips and itineraries in localStorage
 */

(function () {
  'use strict';

  // =========================================================================
  // 1. CONSTANTS & CATEGORY CONFIGURATION
  // =========================================================================
  const CATEGORIES = [
    { key: "Attractions", label: "Attractions", icon: "🏛️", desc: "Iconic landmarks, heritage sites, and architectural wonders" },
    { key: "Food & Restaurants", label: "Food & Restaurants", icon: "🍜", desc: "Authentic street food, Michelin-starred gastronomy, and local dining" },
    { key: "Nightlife", label: "Nightlife", icon: "🍸", desc: "Craft cocktail speakeasies, jazz clubs, rooftop bars, and vibrant lounges" },
    { key: "Nature/Outdoors", label: "Nature/Outdoors", icon: "🌲", desc: "Breathtaking summits, alpine lakes, bamboo trails, and coastal treks" },
    { key: "Museums & Culture", label: "Museums & Culture", icon: "🎨", desc: "World-class art collections, royal palaces, and ancient shrines" },
    { key: "Shopping", label: "Shopping", icon: "🛍️", desc: "Artisan crafts, designer boutiques, night markets, and heritage arcades" }
  ];

  const CATEGORY_STYLES = {
    "Attractions": { bg: "#0d9488", icon: "🏛️" },
    "Food & Restaurants": { bg: "#f59e0b", icon: "🍜" },
    "Nightlife": { bg: "#8b5cf6", icon: "🍸" },
    "Nature/Outdoors": { bg: "#10b981", icon: "🌲" },
    "Museums & Culture": { bg: "#3b82f6", icon: "🎨" },
    "Shopping": { bg: "#ec4899", icon: "🛍️" }
  };

  // =========================================================================
  // 2. STATE MANAGEMENT
  // =========================================================================
  const state = {
    currentDestId: "dest-jaipur",
    currentDestObj: null,
    allDestPlaces: [],
    isLoading: false,
    searchQuery: "",
    selectedCategory: "all",
    minRating: 0,
    selectedPrice: "all",
    leafletMap: null,
    markerLayer: null,
    markersByPlaceId: {},
    selectedPlaceForTrip: null,
    modalMode: "existing" // "existing" or "new"
  };

  // Asynchronously load destination and its places from DestinationService
  async function loadDestinationData(destIdOrName) {
    state.isLoading = true;
    if (window.DestinationService) {
      state.currentDestObj = await window.DestinationService.getDestination(destIdOrName);
      state.currentDestId = state.currentDestObj ? state.currentDestObj.id : destIdOrName;
      state.allDestPlaces = await window.DestinationService.getPlacesForDestination(state.currentDestObj);
    } else if (window.MOCK_DATA) {
      state.currentDestObj = (window.MOCK_DATA.destinations || []).find(d => d.id === destIdOrName || d.name.toLowerCase().includes(destIdOrName.toLowerCase())) || window.MOCK_DATA.destinations[0];
      state.currentDestId = state.currentDestObj ? state.currentDestObj.id : "dest-jaipur";
      state.allDestPlaces = (window.MOCK_DATA.places || []).filter(p => p.destinationId === state.currentDestId);
    }
    state.isLoading = false;
  }

  // =========================================================================
  // 3. INITIALIZATION
  // =========================================================================
  async function init() {
    // Ensure MOCK_DATA and WanderStorage are available
    if (!window.MOCK_DATA) {
      console.warn("MOCK_DATA not loaded yet. Waiting...");
      setTimeout(init, 100);
      return;
    }

    if (window.WanderStorage) {
      window.WanderStorage.init();
      window.WanderStorage.syncHeaderAuth();
      window.WanderStorage.setupMobileNavToggle();
    }

    // Read query params if user arrived with ?dest=... or ?search=...
    const urlParams = new URLSearchParams(window.location.search);
    const destParam = urlParams.get("dest") || urlParams.get("id");
    const searchParam = urlParams.get("search") || urlParams.get("q");

    const targetDest = destParam || searchParam || state.currentDestId;
    await loadDestinationData(targetDest);

    if (searchParam && searchParam !== destParam) {
      state.searchQuery = searchParam;
      const searchInput = document.getElementById("dest-search-input");
      if (searchInput) searchInput.value = searchParam;
    }

    initMap();
    setupEventListeners();
    renderPage();
  }

  // =========================================================================
  // 4. MAP INITIALIZATION & PIN CONTROLLER (OpenStreetMap / Leaflet)
  // =========================================================================
  function initMap() {
    const mapEl = document.getElementById("destination-map");
    if (!mapEl || typeof L === "undefined") return;

    // Center coordinates from destination object or default
    const defaultCoords = state.currentDestObj && state.currentDestObj.lat && state.currentDestObj.lng
      ? [state.currentDestObj.lat, state.currentDestObj.lng]
      : [26.9124, 75.7873];

    state.leafletMap = L.map("destination-map", {
      center: defaultCoords,
      zoom: 12,
      scrollWheelZoom: false,
      zoomControl: true
    });

    // Add clean OpenStreetMap tiles
    L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a> | WanderWise'
    }).addTo(state.leafletMap);

    // Layer group for dynamic markers
    state.markerLayer = L.layerGroup().addTo(state.leafletMap);
  }

  function updateMapMarkers(placesList) {
    if (!state.leafletMap || !state.markerLayer || typeof L === "undefined") return;

    state.markerLayer.clearLayers();
    state.markersByPlaceId = {};

    if (!placesList || placesList.length === 0) {
      if (state.currentDestObj && state.currentDestObj.lat && state.currentDestObj.lng) {
        state.leafletMap.setView([state.currentDestObj.lat, state.currentDestObj.lng], 12);
      }
      return;
    }

    const bounds = [];

    placesList.forEach(place => {
      if (!place.lat || !place.lng) return;

      const style = CATEGORY_STYLES[place.category] || { bg: "#0d9488", icon: "📍" };

      // Custom rounded teardrop HTML marker
      const customIcon = L.divIcon({
        className: "custom-dest-pin-wrapper",
        html: `<div class="custom-dest-pin" style="background: ${style.bg};" title="${place.name}">
                 <span>${style.icon}</span>
               </div>`,
        iconSize: [34, 34],
        iconAnchor: [17, 34],
        popupAnchor: [0, -32]
      });

      const marker = L.marker([place.lat, place.lng], { icon: customIcon });

      // Build rich Leaflet Popup content
      const popupHtml = `
        <div class="dest-leaflet-popup">
          <div class="popup-img-wrap">
            <img src="${place.photoUrl}" alt="${place.name}" class="popup-img">
            <span class="popup-category-badge">${place.category}</span>
          </div>
          <div class="popup-body">
            <div class="popup-title">${place.name}</div>
            <div class="popup-meta-row">
              <span>★ ${place.rating} (${place.reviewCount})</span>
              <span>📍 ${place.distanceFromCenter || ''}</span>
            </div>
            <div class="popup-footer">
              <span class="popup-cost">${place.cost}</span>
              <button class="btn btn-primary btn-sm" style="padding: 3px 8px; font-size: 11px;" onclick="window.DestinationExplorer.openAddToTripModal('${place.id}')">
                + Add to Trip
              </button>
            </div>
          </div>
        </div>
      `;

      marker.bindPopup(popupHtml, { maxWidth: 280 });

      // Highlight corresponding card on marker click
      marker.on("click", () => {
        highlightPlaceCard(place.id);
      });

      marker.addTo(state.markerLayer);
      state.markersByPlaceId[place.id] = marker;
      bounds.push([place.lat, place.lng]);
    });

    // Update map view to fit visible places with gentle padding
    if (bounds.length === 1) {
      state.leafletMap.setView(bounds[0], 13);
    } else if (bounds.length > 1) {
      state.leafletMap.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
    }

    // Update count in map header
    const pinBadge = document.getElementById("dest-map-pin-count");
    if (pinBadge) {
      pinBadge.textContent = `${placesList.length} places mapped`;
    }
  }

  function focusPlaceOnMap(placeId) {
    const marker = state.markersByPlaceId[placeId];
    if (marker && state.leafletMap) {
      const latLng = marker.getLatLng();
      state.leafletMap.setView(latLng, 15, { animate: true });
      marker.openPopup();

      const mapCard = document.querySelector(".dest-map-card");
      if (mapCard) {
        mapCard.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
  }

  function highlightPlaceCard(placeId) {
    document.querySelectorAll(".place-card").forEach(card => card.classList.remove("highlighted-pin"));
    const targetCard = document.getElementById(`place-card-${placeId}`);
    if (targetCard) {
      targetCard.classList.add("highlighted-pin");
      targetCard.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }

  // =========================================================================
  // 5. DATA FILTERING ENGINE
  // =========================================================================
  function getFilteredPlaces() {
    let places = (state.allDestPlaces && state.allDestPlaces.length > 0)
      ? [...state.allDestPlaces]
      : (window.MOCK_DATA?.places || []).filter(p => p.destinationId === state.currentDestId);

    const query = state.searchQuery.toLowerCase().trim();

    // 1. Keyword Search Scope with Exact Place Detection
    if (query) {
      places = places.filter(p => {
        const nameMatch = (p.name || '').toLowerCase().includes(query);
        const descMatch = (p.description || '').toLowerCase().includes(query);
        const subMatch = (p.subCategory || '').toLowerCase().includes(query);
        const catMatch = (p.category || '').toLowerCase().includes(query);
        return nameMatch || descMatch || subMatch || catMatch;
      });
    }

    // 2. Category Filter
    if (state.selectedCategory !== "all") {
      places = places.filter(p => p.category === state.selectedCategory);
    }

    // 3. Minimum Rating Filter
    if (state.minRating > 0) {
      places = places.filter(p => p.rating >= state.minRating);
    }

    // 4. Price Level Filter
    if (state.selectedPrice !== "all") {
      places = places.filter(p => p.priceLevel === state.selectedPrice);
    }

    return places;
  }

  // =========================================================================
  // 6. HERO SECTION RENDERER
  // =========================================================================
  function renderHero() {
    const heroEl = document.getElementById("dest-hero-section");
    if (!heroEl) return;

    const dest = state.currentDestObj || (window.MOCK_DATA?.destinations.find(d => d.id === state.currentDestId)) || window.MOCK_DATA?.destinations[0];
    if (!dest) return;

    // Set dynamic hero background image
    heroEl.style.backgroundImage = `url('${dest.heroImage}')`;

    // Destination Switcher Pills
    const seedDests = window.MOCK_DATA?.destinations || [];
    const isCustom = !seedDests.some(d => d.id === dest.id);
    const pillsList = isCustom ? [dest, ...seedDests.slice(0, 7)] : seedDests.slice(0, 8);

    const switcherHtml = `
      <div class="dest-switcher-wrap">
        <span class="dest-switcher-title">Featured:</span>
        ${pillsList.map(d => `
          <button class="dest-switch-btn ${d.id === state.currentDestId ? 'active' : ''}" 
                  onclick="window.DestinationExplorer.switchDestination('${d.id}')">
            ${d.primaryName || d.name.split(',')[0]}
          </button>
        `).join('')}
      </div>
    `;

    heroEl.innerHTML = `
      <div class="container">
        <div class="dest-hero-badge-row">
          <span class="dest-hero-badge">📍 ${dest.state ? `${dest.state}, ` : ''}${dest.country || 'Incredible India'}</span>
          <span class="dest-hero-badge">★ ${dest.rating || 4.8} (${(dest.reviewCount || 1500).toLocaleString()} Explorer Reviews)</span>
        </div>

        <h1>${dest.name}</h1>
        <div class="dest-hero-tagline">${dest.tagline || 'Experience the authentic culture & sights'}</div>
        <p class="dest-hero-desc">${dest.description || 'An unforgettable travel destination filled with historic architecture, cultural landmarks, and delicious local food.'}</p>

        <!-- Key Meta Highlights Strip -->
        <div class="dest-hero-meta-grid">
          <div class="dest-hero-meta-card">
            <span class="dest-hero-meta-icon">🗓️</span>
            <div>
              <div class="dest-hero-meta-label">Best Time To Visit</div>
              <div class="dest-hero-meta-val">${dest.bestTimeToVisit || 'October - March'}</div>
            </div>
          </div>

          <div class="dest-hero-meta-card">
            <span class="dest-hero-meta-icon">💰</span>
            <div>
              <div class="dest-hero-meta-label">Est. Daily Budget</div>
              <div class="dest-hero-meta-val">${dest.avgBudget || '₹3,500 / day'}</div>
            </div>
          </div>

          <div class="dest-hero-meta-card">
            <span class="dest-hero-meta-icon">🏷️</span>
            <div>
              <div class="dest-hero-meta-label">Primary Styles</div>
              <div class="dest-hero-meta-val">${(dest.tags || ['Culture', 'Sights', 'Travel']).slice(0, 3).join(" • ")}</div>
            </div>
          </div>
        </div>

        ${switcherHtml}
      </div>
    `;
  }



  // =========================================================================
  // 7. CATEGORY TABS & FILTER BAR RENDERER
  // =========================================================================
  function renderCategoryTabs(placesList) {
    const tabsContainer = document.getElementById("dest-category-tab-bar");
    if (!tabsContainer) return;

    // Calculate count per category
    const allCount = placesList.length;
    const countMap = {};
    CATEGORIES.forEach(c => countMap[c.key] = 0);
    placesList.forEach(p => {
      if (countMap[p.category] !== undefined) countMap[p.category]++;
    });

    let html = `
      <button class="dest-cat-tab ${state.selectedCategory === 'all' ? 'active' : ''}" 
              onclick="window.DestinationExplorer.setCategory('all')">
        <span>✨ All Categories</span>
        <span class="dest-cat-count">${allCount}</span>
      </button>
    `;

    CATEGORIES.forEach(cat => {
      const isSelected = state.selectedCategory === cat.key;
      const count = countMap[cat.key] || 0;
      html += `
        <button class="dest-cat-tab ${isSelected ? 'active' : ''}" 
                onclick="window.DestinationExplorer.setCategory('${cat.key}')">
          <span>${cat.icon} ${cat.label}</span>
          <span class="dest-cat-count">${count}</span>
        </button>
      `;
    });

    tabsContainer.innerHTML = html;

    // Update filter summary text
    const summaryEl = document.getElementById("dest-results-count");
    if (summaryEl) {
      const dest = window.MOCK_DATA.destinations.find(d => d.id === state.currentDestId);
      const destName = dest ? dest.name : "destination";
      if (state.searchQuery) {
        summaryEl.textContent = `Showing ${allCount} place${allCount === 1 ? '' : 's'} matching "${state.searchQuery}"`;
      } else {
        summaryEl.textContent = `Showing ${allCount} curated place${allCount === 1 ? '' : 's'} in ${destName}`;
      }
    }
  }

  // =========================================================================
  // 8. CATEGORIZED PLACES SECTIONS & CARDS RENDERER
  // =========================================================================
  function renderPlaces(filteredPlaces) {
    const container = document.getElementById("dest-places-container");
    if (!container) return;

    if (filteredPlaces.length === 0) {
      container.innerHTML = `
        <div class="empty-state" style="padding: var(--space-12) var(--space-4); text-align: center;">
          <div class="empty-state-icon" style="font-size: 3rem; margin-bottom: var(--space-3);">🔍</div>
          <h3 style="margin-bottom: var(--space-2);">No places match your search or filters</h3>
          <p style="color: var(--text-muted); max-width: 460px; margin: 0 auto var(--space-6);">
            Try adjusting your keyword, resetting the rating or price filter, or explore another category.
          </p>
          <button class="btn btn-primary" onclick="window.DestinationExplorer.resetFilters()">
            Reset All Filters
          </button>
        </div>
      `;
      return;
    }

    // If a specific category is active, render single category view
    if (state.selectedCategory !== "all") {
      const activeCat = CATEGORIES.find(c => c.key === state.selectedCategory) || {
        icon: "📍",
        label: state.selectedCategory,
        desc: "Curated recommendations"
      };

      container.innerHTML = `
        <section class="dest-category-section">
          <div class="dest-category-header">
            <div class="dest-category-title-group">
              <div class="dest-category-icon-box">${activeCat.icon}</div>
              <div>
                <h2>${activeCat.label}</h2>
                <p>${activeCat.desc}</p>
              </div>
            </div>
            <span class="dest-section-count-badge">${filteredPlaces.length} places</span>
          </div>
          <div class="dest-places-grid">
            ${filteredPlaces.map(place => renderPlaceCard(place)).join('')}
          </div>
        </section>
      `;
      return;
    }

    // Render grouped categorized sections for ALL 6 categories
    let html = "";
    CATEGORIES.forEach(cat => {
      const catPlaces = filteredPlaces.filter(p => p.category === cat.key);
      if (catPlaces.length === 0) return;

      html += `
        <section class="dest-category-section" id="cat-section-${cat.key.replace(/\s+/g, '-').toLowerCase()}">
          <div class="dest-category-header">
            <div class="dest-category-title-group">
              <div class="dest-category-icon-box">${cat.icon}</div>
              <div>
                <h2>${cat.label}</h2>
                <p>${cat.desc}</p>
              </div>
            </div>
            <span class="dest-section-count-badge">${catPlaces.length} places</span>
          </div>
          <div class="dest-places-grid">
            ${catPlaces.map(place => renderPlaceCard(place)).join('')}
          </div>
        </section>
      `;
    });

    container.innerHTML = html;
  }

  function renderPlaceCard(place) {
    const style = CATEGORY_STYLES[place.category] || { bg: "#0d9488", icon: "📍" };

    return `
      <article class="place-card" id="place-card-${place.id}">
        <div class="place-card-img-wrap">
          <img src="${place.photoUrl}" alt="${place.name}" class="place-card-img" loading="lazy">
          <span class="place-card-category-tag">${style.icon} ${place.category}</span>
          <span class="place-card-price-tag">${place.priceLevel || '$$'}</span>
        </div>

        <div class="place-card-body">
          <div class="place-card-title-row">
            <h3 class="place-card-title">${place.name}</h3>
            <span class="place-card-rating">★ ${place.rating}</span>
          </div>

          <div class="place-card-subcat">${place.subCategory || place.category}</div>

          <div class="place-card-meta-row">
            <div class="place-card-meta-item">
              <span>📍</span> ${place.distanceFromCenter || 'Central'}
            </div>
            <div class="place-card-meta-item">
              <span>⏳</span> ${place.duration || '1 - 2 hours'}
            </div>
          </div>

          <p class="place-card-desc">${place.description}</p>

          <div class="place-card-footer">
            <div class="place-card-cost-wrap">
              <span class="place-card-cost-label">Est. Cost</span>
              <span class="place-card-cost-value">${place.cost}</span>
            </div>
            <div class="place-card-actions">
              <button class="btn-pin-map" onclick="window.DestinationExplorer.focusPlaceOnMap('${place.id}')" title="Show Pin on Map">
                📍 Map
              </button>
              <button class="btn btn-primary btn-sm" onclick="window.DestinationExplorer.openAddToTripModal('${place.id}')">
                + Add to Trip
              </button>
            </div>
          </div>
        </div>
      </article>
    `;
  }

  // =========================================================================
  // 9. FULL PAGE RENDER PIPELINE
  // =========================================================================
  function renderPage() {
    renderHero();
    const places = getFilteredPlaces();
    renderCategoryTabs(places);
    renderPlaces(places);
    updateMapMarkers(places);
  }

  // =========================================================================
  // 10. "ADD TO TRIP" MODAL & LOCALSTORAGE PERSISTENCE
  // =========================================================================
  function openAddToTripModal(placeId) {
    if (window.Auth && !window.Auth.requireAuth("save attractions and plan custom itineraries")) {
      return;
    }
    const allAvailable = [...(state.allDestPlaces || []), ...(window.MOCK_DATA?.places || [])];
    const place = allAvailable.find(p => p.id === placeId);
    if (!place) return;

    state.selectedPlaceForTrip = place;
    state.modalMode = "existing";

    const modalBackdrop = document.getElementById("dest-trip-modal-backdrop");
    const previewContainer = document.getElementById("dest-modal-preview");
    if (!modalBackdrop || !previewContainer) return;

    // Render selected place preview
    previewContainer.innerHTML = `
      <img src="${place.photoUrl}" alt="${place.name}" class="dest-modal-place-thumb">
      <div class="dest-modal-place-info">
        <h4>${place.name}</h4>
        <p><strong>Category:</strong> ${place.category} (${place.subCategory || ''})</p>
        <p><strong>Duration:</strong> ⏳ ${place.duration} &nbsp;|&nbsp; <strong>Cost:</strong> 💰 ${place.cost}</p>
      </div>
    `;

    // Populate modal body
    renderModalBody();

    // Show modal
    modalBackdrop.classList.add("open");
  }

  function closeAddToTripModal() {
    const modalBackdrop = document.getElementById("dest-trip-modal-backdrop");
    if (modalBackdrop) modalBackdrop.classList.remove("open");
    state.selectedPlaceForTrip = null;
  }

  function setModalMode(mode) {
    state.modalMode = mode;
    renderModalBody();
  }

  function renderModalBody() {
    const bodyEl = document.getElementById("dest-modal-body-content");
    const tabsEl = document.getElementById("dest-modal-tabs");
    const submitBtn = document.getElementById("dest-modal-submit-btn");
    if (!bodyEl || !tabsEl || !submitBtn) return;

    // Mode tabs
    tabsEl.innerHTML = `
      <button class="dest-modal-tab-btn ${state.modalMode === 'existing' ? 'active' : ''}" 
              onclick="window.DestinationExplorer.setModalMode('existing')">
        Select Existing Trip
      </button>
      <button class="dest-modal-tab-btn ${state.modalMode === 'new' ? 'active' : ''}" 
              onclick="window.DestinationExplorer.setModalMode('new')">
        + Create New Trip
      </button>
    `;

    const trips = (window.WanderStorage && window.WanderStorage.getTrips) 
      ? window.WanderStorage.getTrips() 
      : [];

    if (state.modalMode === "existing") {
      submitBtn.textContent = "+ Add to Itinerary";

      if (trips.length === 0) {
        bodyEl.innerHTML = `
          <div style="text-align: center; padding: var(--space-4) 0;">
            <p style="color: var(--text-muted); margin-bottom: var(--space-3);">No existing trips found in your account.</p>
            <button class="btn btn-primary btn-sm" onclick="window.DestinationExplorer.setModalMode('new')">
              Create Your First Trip &rarr;
            </button>
          </div>
        `;
        return;
      }

      const activeTrip = (window.WanderStorage && window.WanderStorage.getActiveTrip) 
        ? window.WanderStorage.getActiveTrip() 
        : trips[0];
      const selectedTripId = activeTrip ? activeTrip.id : trips[0].id;

      bodyEl.innerHTML = `
        <label class="form-label" style="margin-bottom: var(--space-2); display: block;">Select Destination Trip:</label>
        <div class="dest-trip-cards-list" id="modal-trip-list">
          ${trips.map(trip => `
            <div class="dest-trip-radio-card ${trip.id === selectedTripId ? 'selected' : ''}" 
                 onclick="window.DestinationExplorer.selectTripInModal('${trip.id}')" 
                 id="modal-trip-card-${trip.id}">
              <img src="${trip.coverPhoto}" alt="${trip.title}" class="dest-trip-radio-thumb">
              <div style="flex: 1;">
                <strong style="font-size: var(--text-sm); display: block;">${trip.title}</strong>
                <span style="font-size: 11px; color: var(--text-muted);">${trip.destination} • ${trip.daysCount} Days</span>
              </div>
              <input type="radio" name="modal_trip_selection" value="${trip.id}" ${trip.id === selectedTripId ? 'checked' : ''} style="accent-color: var(--primary-color);">
            </div>
          `).join('')}
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); margin-top: var(--space-3);">
          <div>
            <label class="form-label" for="modal-day-select">Target Itinerary Day:</label>
            <select class="form-input" id="modal-day-select">
              <!-- Populated dynamically -->
            </select>
          </div>
          <div>
            <label class="form-label" for="modal-time-slot">Preferred Time Slot:</label>
            <select class="form-input" id="modal-time-slot">
              <option value="09:00 AM">Morning (09:00 AM)</option>
              <option value="01:30 PM" selected>Afternoon (01:30 PM)</option>
              <option value="06:30 PM">Evening (06:30 PM)</option>
              <option value="09:00 PM">Night (09:00 PM)</option>
            </select>
          </div>
        </div>

        <div style="margin-top: var(--space-3);">
          <label class="form-label" for="modal-activity-notes">Personal Notes (Optional):</label>
          <input type="text" class="form-input" id="modal-activity-notes" placeholder="e.g. Bring camera, book tickets in advance...">
        </div>
      `;

      updateModalDaysDropdown(selectedTripId);
    } else {
      // "Create New Trip" Form
      submitBtn.textContent = "Create Trip & Add";

      const dest = window.MOCK_DATA.destinations.find(d => d.id === state.currentDestId) || { name: "Jaipur", country: "India" };
      const place = state.selectedPlaceForTrip;

      bodyEl.innerHTML = `
        <div style="display: flex; flex-direction: column; gap: var(--space-3);">
          <div>
            <label class="form-label" for="new-trip-title">Trip Name:</label>
            <input type="text" class="form-input" id="new-trip-title" value="${dest.name} Getaway & Exploration" required>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3);">
            <div>
              <label class="form-label" for="new-trip-dest">Destination:</label>
              <input type="text" class="form-input" id="new-trip-dest" value="${dest.name}, ${dest.country}" required>
            </div>
            <div>
              <label class="form-label" for="new-trip-budget">Target Budget (₹):</label>
              <input type="number" class="form-input" id="new-trip-budget" value="45000">
            </div>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3);">
            <div>
              <label class="form-label" for="new-trip-start">Start Date:</label>
              <input type="date" class="form-input" id="new-trip-start" value="2026-10-15">
            </div>
            <div>
              <label class="form-label" for="new-trip-end">End Date:</label>
              <input type="date" class="form-input" id="new-trip-end" value="2026-10-21">
            </div>
          </div>

          <p style="font-size: var(--text-xs); color: var(--text-muted); margin-top: var(--space-2);">
            ✨ "${place.name}" will be automatically scheduled onto Day 1 of your new expedition!
          </p>
        </div>
      `;
    }
  }

  function selectTripInModal(tripId) {
    document.querySelectorAll(".dest-trip-radio-card").forEach(card => card.classList.remove("selected"));
    const target = document.getElementById(`modal-trip-card-${tripId}`);
    if (target) {
      target.classList.add("selected");
      const radio = target.querySelector("input[type='radio']");
      if (radio) radio.checked = true;
    }
    updateModalDaysDropdown(tripId);
  }

  function updateModalDaysDropdown(tripId) {
    const daySelect = document.getElementById("modal-day-select");
    if (!daySelect || !window.WanderStorage) return;

    const trips = window.WanderStorage.getTrips();
    const trip = trips.find(t => t.id === tripId);
    const daysCount = trip ? (trip.daysCount || 5) : 5;

    let optionsHtml = "";
    for (let i = 1; i <= daysCount; i++) {
      optionsHtml += `<option value="${i}">Day ${i} Itinerary</option>`;
    }
    daySelect.innerHTML = optionsHtml;
  }

  function handleModalSubmit() {
    const place = state.selectedPlaceForTrip;
    if (!place || !window.WanderStorage) return;

    if (state.modalMode === "existing") {
      const selectedRadio = document.querySelector("input[name='modal_trip_selection']:checked");
      if (!selectedRadio) {
        if (window.WanderStorage && window.WanderStorage.showToast) {
          window.WanderStorage.showToast("Please select a trip first!", "warning");
        } else {
          showToast("Please select a trip first!");
        }
        return;
      }
      const tripId = selectedRadio.value;
      const dayNumber = parseInt(document.getElementById("modal-day-select").value, 10) || 1;
      const timeSlot = document.getElementById("modal-time-slot").value || "11:00 AM";
      const notes = document.getElementById("modal-activity-notes").value || "";

      const newActivity = {
        id: "act-" + Date.now(),
        time: timeSlot,
        title: place.name,
        location: place.name,
        category: place.category,
        duration: place.duration,
        notes: notes || `Added from Destination Explorer (${place.distanceFromCenter || ''})`,
        cost: place.cost,
        photoUrl: place.photoUrl
      };

      // Persist to localStorage
      window.WanderStorage.addActivity(tripId, dayNumber, newActivity);
      window.WanderStorage.setActiveTrip(tripId);

      const trip = window.WanderStorage.getTripById(tripId);
      const tripTitle = trip ? trip.title : "your trip";

      closeAddToTripModal();
      showToast(`Added <strong>${place.name}</strong> to Day ${dayNumber} of "${tripTitle}"!`);
    } else {
      // Create new trip flow
      const title = document.getElementById("new-trip-title").value.trim() || `${place.name} Adventure`;
      const destination = document.getElementById("new-trip-dest").value.trim() || "Planned Destination";
      const budget = parseFloat(document.getElementById("new-trip-budget").value) || 2000;
      const startDate = document.getElementById("new-trip-start").value || "2026-10-15";
      const endDate = document.getElementById("new-trip-end").value || "2026-10-21";

      const start = new Date(startDate);
      const end = new Date(endDate);
      const diffTime = Math.abs(end - start);
      const daysCount = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1) || 6;

      const newTrip = {
        id: "trip-" + Date.now(),
        title: title,
        destination: destination,
        destinationId: state.currentDestId,
        startDate: startDate,
        endDate: endDate,
        daysCount: daysCount,
        travelersCount: 2,
        coverPhoto: place.photoUrl,
        totalBudget: budget,
        spentBudget: 0,
        status: "Active"
      };

      // Save new trip to localStorage
      window.WanderStorage.saveTrip(newTrip);
      window.WanderStorage.setActiveTrip(newTrip.id);

      // Add place as Day 1 activity
      window.WanderStorage.addActivity(newTrip.id, 1, {
        id: "act-" + Date.now(),
        time: "10:00 AM",
        title: place.name,
        location: place.name,
        category: place.category,
        duration: place.duration,
        notes: "Initial highlight for newly created trip",
        cost: place.cost,
        photoUrl: place.photoUrl
      });

      closeAddToTripModal();
      showToast(`Created trip "${title}" & added <strong>${place.name}</strong>!`);
    }
  }

  // =========================================================================
  // 11. TOAST NOTIFICATION SYSTEM
  // =========================================================================
  function showToast(messageHtml) {
    let container = document.getElementById("dest-toast-container");
    if (!container) {
      container = document.createElement("div");
      container.id = "dest-toast-container";
      container.className = "dest-toast-container";
      document.body.appendChild(container);
    }

    const toast = document.createElement("div");
    toast.className = "dest-toast";
    toast.innerHTML = `
      <span class="dest-toast-icon">✓</span>
      <div style="flex: 1;">
        ${messageHtml}
        <a href="trip-hub.html" class="dest-toast-link">Trip Hub &rarr;</a>
      </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateX(50px)";
      toast.style.transition = "all 0.3s ease";
      setTimeout(() => toast.remove(), 300);
    }, 4500);
  }

  // =========================================================================
  // 12. EVENT LISTENERS
  // =========================================================================
  function setupEventListeners() {
    const searchInput = document.getElementById("dest-search-input");
    const searchDropdown = document.getElementById("dest-search-dropdown");
    const clearBtn = document.getElementById("dest-search-clear");

    // Live Place & Universal Destination Auto-Detection Dropdown
    if (searchInput && searchDropdown) {
      let searchDebounce = null;

      searchInput.addEventListener("input", function() {
        const q = searchInput.value.trim();
        clearTimeout(searchDebounce);

        if (q.length < 1) {
          searchDropdown.style.display = "none";
          state.searchQuery = "";
          if (clearBtn) clearBtn.classList.remove("visible");
          renderPage();
          return;
        }

        if (clearBtn) clearBtn.classList.add("visible");
        state.searchQuery = q;

        // Debounced search for places and any global destination
        searchDebounce = setTimeout(async () => {
          // 1. Check local places in current destination
          const currentPlaces = state.allDestPlaces || [];
          const qLower = q.toLowerCase();
          const matchPlaces = currentPlaces.filter(p => 
            (p.name && p.name.toLowerCase().includes(qLower)) ||
            (p.subCategory && p.subCategory.toLowerCase().includes(qLower)) ||
            (p.category && p.category.toLowerCase().includes(qLower))
          ).slice(0, 5);

          // 2. Search all destinations via DestinationService
          let matchDests = [];
          if (window.DestinationService) {
            matchDests = await window.DestinationService.search(q, { limit: 5 });
          } else {
            matchDests = (window.MOCK_DATA?.destinations || []).filter(d =>
              d.name.toLowerCase().includes(qLower) || (d.state && d.state.toLowerCase().includes(qLower))
            ).slice(0, 4);
          }

          if (matchDests.length === 0 && matchPlaces.length === 0) {
            searchDropdown.innerHTML = `
              <div style="padding: 12px 14px; font-size: 12px; color: #64748b; text-align: center;">
                <div style="font-size: 18px; margin-bottom: 2px;">🌍</div>
                <strong>Press Enter to explore "${q}"</strong>
                <div style="font-size: 11px; color: #94a3b8; margin-top: 2px;">We'll dynamically load attractions, sights & map pins!</div>
              </div>
            `;
            searchDropdown.style.display = "block";
            renderPage();
            return;
          }

          let html = "";
          if (matchDests.length > 0) {
            html += '<div style="padding: 6px 12px; font-size: 10px; font-weight: bold; color: #94a3b8; text-transform: uppercase; background: #f8fafc; border-bottom: 1px solid #f1f5f9;">📍 Explore Destinations</div>';
            matchDests.forEach(d => {
              const safeName = d.name.replace(/'/g, "\\'");
              const safeId = (d.id || d.name).replace(/'/g, "\\'");
              const sub = d.state ? `${d.state}${d.country ? ', ' + d.country : ''}` : (d.tagline || 'Scenic Destination');
              html += `
                <div class="dest-dropdown-row" style="display: flex; align-items: center; justify-content: space-between; padding: 8px 12px; border-bottom: 1px solid #f1f5f9; cursor: pointer;" onclick="window.DestinationExplorer.switchDestination('${safeId}'); document.getElementById('dest-search-dropdown').style.display='none'; document.getElementById('dest-search-input').value='${safeName}';">
                  <div>
                    <div style="font-weight: 600; font-size: 13px; color: #0f172a;">${d.name}</div>
                    <div style="font-size: 11px; color: #64748b;">${sub}</div>
                  </div>
                  <span class="badge badge-primary" style="font-size: 10px;">Switch &rarr;</span>
                </div>
              `;
            });
          }

          if (matchPlaces.length > 0) {
            html += '<div style="padding: 6px 12px; font-size: 10px; font-weight: bold; color: #94a3b8; text-transform: uppercase; background: #f8fafc; border-bottom: 1px solid #f1f5f9;">🏛️ Sights & Landmarks in Current View</div>';
            matchPlaces.forEach(p => {
              const safeName = p.name.replace(/'/g, "\\'");
              html += `
                <div class="dest-dropdown-row" style="display: flex; align-items: center; justify-content: space-between; padding: 8px 12px; border-bottom: 1px solid #f1f5f9; cursor: pointer;" onclick="window.DestinationExplorer.focusPlaceOnMap('${p.id}'); document.getElementById('dest-search-dropdown').style.display='none'; document.getElementById('dest-search-input').value='${safeName}';">
                  <div>
                    <strong style="font-size: 13px; color: #0f172a;">${p.name}</strong>
                    <div style="font-size: 11px; color: #64748b;">${p.category} &bull; ${p.cost}</div>
                  </div>
                  <span class="badge badge-neutral" style="font-size: 10px;">📍 Show on Map</span>
                </div>
              `;
            });
          }

          searchDropdown.innerHTML = html;
          searchDropdown.style.display = "block";

          // Add hover styles
          searchDropdown.querySelectorAll(".dest-dropdown-row").forEach(row => {
            row.addEventListener("mouseenter", () => row.style.background = "#f0fdfa");
            row.addEventListener("mouseleave", () => row.style.background = "");
          });

          renderPage();
        }, 200);
      });

      // Handle Enter key in search input to switch directly to any destination
      searchInput.addEventListener("keydown", async (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          const q = searchInput.value.trim();
          if (q.length > 1) {
            searchDropdown.style.display = "none";
            await window.DestinationExplorer.switchDestination(q);
          }
        } else if (e.key === "Escape") {
          searchDropdown.style.display = "none";
        }
      });

      document.addEventListener("click", function(e) {
        if (!searchInput.contains(e.target) && !searchDropdown.contains(e.target)) {
          searchDropdown.style.display = "none";
        }
      });
    }

    if (clearBtn && searchInput) {
      clearBtn.addEventListener("click", () => {
        searchInput.value = "";
        state.searchQuery = "";
        clearBtn.classList.remove("visible");
        if (searchDropdown) searchDropdown.style.display = "none";
        renderPage();
        searchInput.focus();
      });
    }

    // Rating filter dropdown
    const ratingFilter = document.getElementById("dest-rating-filter");
    if (ratingFilter) {
      ratingFilter.addEventListener("change", (e) => {
        state.minRating = parseFloat(e.target.value) || 0;
        renderPage();
      });
    }

    // Price level filter dropdown
    const priceFilter = document.getElementById("dest-price-filter");
    if (priceFilter) {
      priceFilter.addEventListener("change", (e) => {
        state.selectedPrice = e.target.value;
        renderPage();
      });
    }

    // Modal close & backdrop clicks
    const modalCloseBtn = document.getElementById("dest-modal-close-btn");
    const modalBackdrop = document.getElementById("dest-trip-modal-backdrop");
    if (modalCloseBtn) modalCloseBtn.addEventListener("click", closeAddToTripModal);
    if (modalBackdrop) {
      modalBackdrop.addEventListener("click", (e) => {
        if (e.target === modalBackdrop) closeAddToTripModal();
      });
    }

    // Modal submit button
    const submitBtn = document.getElementById("dest-modal-submit-btn");
    if (submitBtn) submitBtn.addEventListener("click", handleModalSubmit);
  }

  // =========================================================================
  // 13. PUBLIC API FOR INLINE HANDLERS
  // =========================================================================
  window.DestinationExplorer = {
    init: init,
    switchDestination: async function (destIdOrName) {
      await loadDestinationData(destIdOrName);
      state.searchQuery = "";
      state.selectedCategory = "all";
      const searchInput = document.getElementById("dest-search-input");
      if (searchInput) searchInput.value = "";
      const clearBtn = document.getElementById("dest-search-clear");
      if (clearBtn) clearBtn.classList.remove("visible");

      // Update map center on destination coordinates
      if (state.leafletMap && state.currentDestObj && state.currentDestObj.lat && state.currentDestObj.lng) {
        state.leafletMap.setView([state.currentDestObj.lat, state.currentDestObj.lng], 12);
      }

      renderPage();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    setCategory: function (catKey) {
      state.selectedCategory = catKey;
      renderPage();
    },
    resetFilters: function () {
      state.searchQuery = "";
      state.selectedCategory = "all";
      state.minRating = 0;
      state.selectedPrice = "all";

      const searchInput = document.getElementById("dest-search-input");
      if (searchInput) searchInput.value = "";
      const clearBtn = document.getElementById("dest-search-clear");
      if (clearBtn) clearBtn.classList.remove("visible");

      const ratingFilter = document.getElementById("dest-rating-filter");
      if (ratingFilter) ratingFilter.value = "0";

      const priceFilter = document.getElementById("dest-price-filter");
      if (priceFilter) priceFilter.value = "all";

      renderPage();
    },
    focusPlaceOnMap: focusPlaceOnMap,
    openAddToTripModal: openAddToTripModal,
    closeAddToTripModal: closeAddToTripModal,
    setModalMode: setModalMode,
    selectTripInModal: selectTripInModal
  };

  // Launch on DOM ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
