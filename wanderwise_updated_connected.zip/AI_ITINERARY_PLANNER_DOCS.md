# WanderWise India - AI Itinerary Planner: Technical Architecture & Integration Guide

## 1. Overview & Frontend Architecture

The **AI Itinerary Planner** is a client-side travel design engine that seamlessly integrates into WanderWise India via the remade `trip-hub.html` page and `trip-hub.js` controller.

It allows travelers to search authentic destinations from the website's existing repository, define their trip parameters (dates, travelers, budget, travel style, and interests), and receive a day-by-day, budget-optimized travel itinerary without needing any backend, server, or paid AI API keys.

```text
+-------------------------------------------------------------------------+
|                       WANDERWISE ARCHITECTURE                           |
+-------------------------------------------------------------------------+
|  MOCK_DATA.destinations & MOCK_DATA.places (data.js / destination-service)
|                                |
|                                v
|                   getAvailableDestinations()
|                                |
|                                v
|              Dynamic Search & Autocomplete Dropdown
|                                |
|                                v
|             Trip Parameters Form (Empty by default)
|                                |
|                                v
|                     Client-Side Validation
|                                |
|                                v
|                    Simulated AI Loading State
|                                |
|                                v
|              generateItinerary(tripInput) Engine
|                                |
|                                v
|              Structured Itinerary JSON Data Model
|                                |
|                                v
|             Interactive UI: Overview | Days | Budget
|                                |
|                                v
|     Actions: Edit Trip | Regenerate | Save | Print | Download
+-------------------------------------------------------------------------+
```

---

## 2. Existing Destination Data Integration

### Data Source
Destination data is retrieved from `window.MOCK_DATA.destinations` in `data.js` and enriched by `DestinationService` (`destination-service.js`). No new or duplicate destination database was created.

### Retrieval Function
The planner relies on the core reusable function:
```javascript
window.getAvailableDestinations = function () {
  const list = [];
  const seenIds = new Set();

  if (window.MOCK_DATA && Array.isArray(window.MOCK_DATA.destinations)) {
    window.MOCK_DATA.destinations.forEach(d => {
      if (d && d.id && !seenIds.has(d.id)) {
        seenIds.add(d.id);
        list.push(d);
      }
    });
  }

  if (window.DestinationService && typeof window.DestinationService.getCachedDestinations === 'function') {
    const cached = window.DestinationService.getCachedDestinations();
    cached.forEach(d => {
      if (d && d.id && !seenIds.has(d.id)) {
        seenIds.add(d.id);
        list.push(d);
      }
    });
  }

  return list;
};
```

### Direct Destination Linking
Every generated itinerary card includes a direct link to the existing destination detail page:
```html
<a href="destination.html?dest=${encodeURIComponent(dest.id)}">Explore Destination Page →</a>
```

---

## 3. Dynamic Destination Search & Autocomplete

* **Input Field**: `<input id="dest-search-input" placeholder="Search destination...">`
* **Behavior**:
  - Initializes completely empty (no default destination pre-filled).
  - Listens to the `input` event, filtering against `getAvailableDestinations()` across `name`, `state`, `region`, and `tags`.
  - Renders matched results in `#dest-autocomplete-dropdown` with theme icons (`🏖️`, `⛰️`, `🛕`, `🛶`, `🏰`) and average budget indicators.
  - Supports keyboard navigation (`ArrowDown`, `ArrowUp`, `Enter`, `Escape`) and outside-click dismissal.
  - Sets the hidden `#selected-dest-id` upon selection.

---

## 4. Form Structure & Zero-Default Inputs

Every input starts unselected and empty to respect genuine user intent:

| Field | Element ID | Initial State | Purpose |
|---|---|---|---|
| **Destination** | `#dest-search-input` | Empty | User types and selects an authentic destination |
| **Start Date** | `#trip-start-date` | Empty (`min = today`) | User specifies commencement date |
| **End Date** | `#trip-end-date` | Empty (`min = today`) | User specifies conclusion date |
| **Travelers** | `#trip-travelers` | Empty (`placeholder="e.g. 2"`) | Number of travelers in party |
| **Budget** | `#trip-budget` | Empty (`placeholder="e.g. 40000"`) | Total financial allowance for entire trip |
| **Currency** | `#trip-currency` | INR (₹) / USD ($) | Currency system applied to estimates |
| **Travel Style** | `#trip-travel-style` | Disabled placeholder selected | Relaxed, Adventure, Family, Romantic, Cultural, Food, Balanced |
| **Interests** | `#trip-interests` | Empty (Optional) | Free-text nuances (e.g. photography, street food, temples) |

---

## 5. Input Validation

The planner performs client-side validation before triggering generation:
1. **Destination**: Must be selected or match a known destination in `getAvailableDestinations()`.
2. **Start Date & End Date**: Both required.
3. **Date Sequence**: `endDate` must be on or after `startDate`.
4. **Duration Cap**: Trips must be between 1 and 14 days for optimal detail.
5. **Travelers**: Must be an integer >= 1.
6. **Budget**: Must be >= ₹1,500 (or >= $50 USD).
7. **Travel Style**: Must be selected from the predefined travel style categories.

Errors are displayed in a styled alert box (`#form-error-alert`) that smoothly scrolls into view.

---

## 6. Dynamic Date Calculation

The trip duration is computed dynamically from user dates:
```javascript
function calculateDays(startDateStr, endDateStr) {
  const start = new Date(startDateStr);
  const end = new Date(endDateStr);
  const diffTime = end.getTime() - start.getTime();
  if (diffTime < 0) return -1;
  return Math.round(diffTime / (1000 * 60 * 60 * 24)) + 1;
}
```
The generator builds exactly the number of days corresponding to the selected dates.

---

## 7. Mock AI Itinerary Generator (`generateItinerary`)

The mock generation logic is isolated in an asynchronous function designed for clean future API substitution:

```javascript
async function generateItinerary(tripInput) {
  // Current Phase: Client-side synthesis using MOCK_DATA.places
  // Future Phase: Replace with fetch('/api/v1/generate-itinerary', { ... })
}
```

### Destination Sensitivity
Activities are sourced directly from `MOCK_DATA.places` matching `p.destinationId === dest.id`:
* **Jaipur**: Amber Fort, Hawa Mahal, Nahargarh Fort, Chokhi Dhani, Johari Bazaar.
* **Kerala**: Vembanad Lake Houseboat cruise, Kolukkumalai tea estates, Kathakali show.
* **Goa**: Fontainhas Latin Quarter, Dudhsagar Waterfalls, beach shacks.
* **Amritsar**: Golden Temple (Sri Harmandir Sahib), Wagah Border, Jallianwala Bagh.
* **Varanasi**: Dashashwamedh Ghat Aarti, Kashi Vishwanath, Sarnath ruins.
* **Manali**: Solang Valley, Rohtang Pass, Old Manali cafes.
* **Andaman**: Radhanagar Beach, Elephant Beach snorkeling, Cellular Jail.

### Schedule Pacing
For every day, three slots are constructed:
* **Morning** (08:30 AM – 11:30 AM): Cultural/Monumental visits or nature explorations.
* **Afternoon** (12:30 PM – 04:00 PM): Sightseeing, heritage palaces, tea gardens, or artisan markets.
* **Evening** (05:00 PM – 08:30 PM): Sunset viewpoints, river ghats, night bazaars, or local dinners.

Each slot provides:
1. Activity name & description
2. Location & duration
3. Estimated cost (explicitly labeled with "Estimated")
4. Recommended local transportation (auto-rickshaw, metro, houseboat, 4x4 mountain cab)
5. Authentic local food recommendation tailored to the destination
6. Actionable travel tip / insight

---

## 8. Budget Logic & Visual Breakdown

The user's budget actively shapes the plan:
* **Lower Budget / Conscious**:
  - Highlights free-entry sights and viewpoints.
  - Suggests walking tours, auto-rickshaws, and metro.
  - Recommends authentic street food stalls and traditional thali houses.
* **Higher Budget / Luxury**:
  - Includes private boat cruises, entry tickets, and heritage tours.
  - Suggests private chauffeur cabs and fine-dining rooftop lounges.

### Category Breakdown
Allocations use travel industry benchmarks:
* **Accommodation & Stay**: 38%
* **Food & Culinary Dining**: 24%
* **Local Transportation**: 16%
* **Sightseeing & Entry Tickets**: 14%
* **Miscellaneous / Buffer**: 8%

**Total estimated spending** is targeted at ~92% of the total budget, leaving a safe ~8% buffer.

### Disclaimers
All displays clearly feature:
> **"Estimated Cost"**
> **"Demo estimate — actual prices will require live data/API integration."**

---

## 9. Structured Itinerary JSON Schema

Between the generator and the UI, data flows via a clean, type-friendly schema:

```json
{
  "id": "itin-1773752834190",
  "generatedAt": "2026-09-16T19:35:00.000Z",
  "destination": "Jaipur, Rajasthan",
  "destinationObj": {
    "id": "dest-jaipur",
    "name": "Jaipur, Rajasthan",
    "state": "Rajasthan",
    "theme": "Heritage & Forts",
    "heroImage": "https://..."
  },
  "startDate": "2026-10-15",
  "endDate": "2026-10-18",
  "daysCount": 4,
  "travelers": 2,
  "travelStyle": "Cultural",
  "interests": "Forts, street food",
  "budgetBreakdown": {
    "totalBudget": 35000,
    "currency": "INR",
    "currencySymbol": "₹",
    "estimatedTotalSpending": 32200,
    "remainingBuffer": 2800,
    "categories": [
      { "name": "Accommodation & Stay", "amount": 13300, "percentage": 38, "color": "#0d9488" },
      { "name": "Food & Culinary Dining", "amount": 8400, "percentage": 24, "color": "#f59e0b" },
      { "name": "Local Transportation", "amount": 5600, "percentage": 16, "color": "#6366f1" },
      { "name": "Sightseeing & Entry Tickets", "amount": 4900, "percentage": 14, "color": "#10b981" },
      { "name": "Miscellaneous / Buffer", "amount": 2800, "percentage": 8, "color": "#94a3b8" }
    ]
  },
  "days": [
    {
      "dayNumber": 1,
      "date": "Thu, Oct 15",
      "title": "Arrival & First Impressions of Jaipur, Rajasthan",
      "morning": {
        "period": "Morning",
        "time": "08:30 AM – 11:30 AM",
        "activity": "Amber Fort & Palace (Amer)",
        "location": "Amer, Jaipur",
        "duration": "3 hours",
        "estimatedCost": "₹350",
        "description": "Magnificent Rajput hill fortress with Sheesh Mahal...",
        "transport": "Chauffeur Tourist Taxi",
        "food": "Authentic Pyaaz Kachori & Masala Chai...",
        "tip": "Hire only licensed government guides for rich lore."
      },
      "afternoon": { ... },
      "evening": { ... }
    }
  ]
}
```

---

## 10. State Management & Lifecycle

```text
[Initial / Empty State]
       ↓ User types in form
[Dirty / Form Input State]
       ↓ User clicks "Generate My Itinerary"
[Validating State] ──(Validation Error)──> [Error Alert State]
       ↓ (Valid)
[Simulated AI Loading State] (Steps 1 → 2 → 3 → 4)
       ↓
[Results Rendered State]
       ├── Switch Day Tab
       ├── Edit Trip (Preserves input values & scrolls to form)
       ├── Regenerate (Reruns generator with current input parameters)
       ├── Save Itinerary (Writes to localStorage)
       ├── Print (Triggers window.print() with print CSS)
       └── Download (Exports clean formatted .txt itinerary)
```

---

## 11. Local Storage Persistence

When the user clicks **💾 Save Itinerary**:
1. Saves to `localStorage` under the key `WW_SAVED_AI_ITINERARIES`.
2. Registers the trip with `WanderStorage.saveTrip()` so it appears in the existing site's saved trips system.
3. Displays a non-intrusive `✓ Saved locally to browser` badge.

---

## 12. Responsive Design & Print Optimization

* **Desktop**: Multi-column form layouts, split-screen overview card with 380px hero imagery, and horizontal day tabs.
* **Mobile & Tablet**: Single-column responsive collapse, touch-friendly tab scroll, and stacked slot detail grids.
* **Print**: Dedicated `@media print` rules hide headers, footers, form controls, and action bars, expanding all day schedules for a clean printed dossier or PDF export.

---

## 13. Future AI / Backend Migration Guide

To replace the frontend mock generator with a real AI backend (e.g. Gemini 1.5 Flash / Pro):

1. **In `trip-hub.js`**, update `generateItinerary(tripInput)`:
```javascript
async function generateItinerary(tripInput) {
  const response = await fetch('/api/generate-itinerary', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(tripInput)
  });

  if (!response.ok) {
    throw new Error('AI generation service error');
  }

  const data = await response.json();
  return data;
}
```

2. **On the Backend API endpoint** (`/api/generate-itinerary`):
   - Send `tripInput` along with the available places from `data.js` to Gemini using structured JSON output.
   - Instruct Gemini to adhere to the exact JSON schema documented in Section 9.
   - Return the structured JSON.

No changes to the UI, forms, validation, loading screens, or display tabs will be needed.
