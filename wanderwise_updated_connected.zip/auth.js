﻿/**
 * WANDERWISE - BROWSER AUTHENTICATION & SESSION ENGINE (auth.js)
 * Zero-framework, client-side authentication, validation,
 * multi-step travel profile onboarding, guest browsing, and session persistence.
 */

(function (root) {
  const STORAGE_KEYS = {
    USER: "WW_USER",
    USERS: "WW_USERS",
    IS_GUEST: "WW_IS_GUEST"
  };

  const DEMO_USER = {
    id: "usr-alex-01",
    name: "Ayush Sharma",
    email: "alex.morgan@wanderwise.com",
    avatar: "AM",
    homeCity: "Seattle, WA",
    role: "Verified Explorer",
    travelPreferences: {
      budget: "luxury",
      companion: "solo",
      interests: ["food", "nature", "history", "adventure"]
    },
    joinedDate: "2026-01-15"
  };

  const Auth = {
    STORAGE_KEYS,

    _get(key, fallback = null) {
      try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : fallback;
      } catch (e) {
        console.error(`Auth localStorage read error [${key}]`, e);
        return fallback;
      }
    },

    _set(key, value) {
      try {
        localStorage.setItem(key, JSON.stringify(value));
        return true;
      } catch (e) {
        console.error(`Auth localStorage write error [${key}]`, e);
        return false;
      }
    },

    // Initialize registered users collection if empty
    init() {
      const users = this._get(STORAGE_KEYS.USERS, []);
      const hasDemo = users.some(u => u.email === DEMO_USER.email);
      if (!hasDemo) {
        users.push({ ...DEMO_USER, password: "password123" });
        this._set(STORAGE_KEYS.USERS, users);
      }
    },

    // =========================================================================
    // Session State Getters
    // =========================================================================
    getCurrentUser() {
      return this._get(STORAGE_KEYS.USER, null);
    },

    isGuest() {
      return localStorage.getItem(STORAGE_KEYS.IS_GUEST) === "true";
    },

    isAuthenticated() {
      const user = this.getCurrentUser();
      return !!user && !this.isGuest();
    },

    // Auto-redirect already logged-in users away from auth pages
    redirectIfAuthenticated(redirectTarget = "trip-hub.html") {
      if (this.isAuthenticated()) {
        window.location.replace(redirectTarget);
        return true;
      }
      return false;
    },

    // =========================================================================
    // Validation Helpers
    // =========================================================================
    validateEmail(email) {
      if (!email || typeof email !== "string") {
        return { isValid: false, message: "Email address is required." };
      }
      const trimmed = email.trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(trimmed)) {
        return { isValid: false, message: "Please enter a valid email address (e.g. name@example.com)." };
      }
      return { isValid: true, value: trimmed };
    },

    validatePassword(password, minLength = 6) {
      if (!password || typeof password !== "string") {
        return { isValid: false, message: "Password is required." };
      }
      if (password.length < minLength) {
        return { isValid: false, message: `Password must be at least ${minLength} characters.` };
      }
      return { isValid: true, value: password };
    },

    // =========================================================================
    // Authentication Operations
    // =========================================================================

    /**
     * Authenticate an existing user or create a mock session.
     */
    login(email, password) {
      const emailVal = this.validateEmail(email);
      if (!emailVal.isValid) {
        return { success: false, field: "email", message: emailVal.message };
      }

      const passVal = this.validatePassword(password);
      if (!passVal.isValid) {
        return { success: false, field: "password", message: passVal.message };
      }

      // Check registered users in localStorage
      const users = this._get(STORAGE_KEYS.USERS, []);
      const existingUser = users.find(u => u.email.toLowerCase() === emailVal.value.toLowerCase());

      let userObj;
      if (existingUser) {
        // Simple password check
        if (existingUser.password && existingUser.password !== passVal.value) {
          return { success: false, field: "password", message: "Incorrect password. Please try again." };
        }
        const { password: _, ...cleanUser } = existingUser;
        userObj = cleanUser;
      } else {
        // Fallback mock user generation
        const baseName = emailVal.value.split("@")[0].replace(/[._-]/g, " ").replace(/\b\w/g, c => c.toUpperCase());
        userObj = {
          id: "usr-" + Date.now(),
          name: baseName || "Wanderer",
          email: emailVal.value,
          avatar: (baseName || "W").split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2),
          homeCity: "New York, USA",
          role: "Explorer",
          travelPreferences: {
            budget: "mid",
            companion: "solo",
            interests: ["nature", "food", "history"]
          },
          joinedDate: new Date().toISOString().split("T")[0]
        };
        // Register in list
        users.push({ ...userObj, password: passVal.value });
        this._set(STORAGE_KEYS.USERS, users);
      }

      // Save active user and clear guest
      this._set(STORAGE_KEYS.USER, userObj);
      localStorage.removeItem(STORAGE_KEYS.IS_GUEST);
      this.syncNav();

      return { success: true, user: userObj };
    },

    /**
     * 1-Click quick login as Demo User Ayush Sharma.
     */
    loginDemo() {
      this._set(STORAGE_KEYS.USER, DEMO_USER);
      localStorage.removeItem(STORAGE_KEYS.IS_GUEST);
      this.syncNav();
      window.location.href = "trip-hub.html";
      return DEMO_USER;
    },

    /**
     * Step 1 of Signup: Validate credentials and initialize a pending session.
     */
    validateSignupStep1(email, password, confirmPassword) {
      const emailVal = this.validateEmail(email);
      if (!emailVal.isValid) {
        return { success: false, field: "email", message: emailVal.message };
      }

      const passVal = this.validatePassword(password);
      if (!passVal.isValid) {
        return { success: false, field: "password", message: passVal.message };
      }

      if (password !== confirmPassword) {
        return { success: false, field: "confirmPassword", message: "Passwords do not match." };
      }

      return { success: true, email: emailVal.value, password: passVal.value };
    },

    /**
     * Step 2 of Signup: Save complete profile with preferences to localStorage.
     */
    completeRegistration(profileData) {
      const { email, password, name, homeCity, travelPreferences } = profileData;

      if (!name || name.trim().length < 2) {
        return { success: false, field: "name", message: "Please enter your full name (minimum 2 characters)." };
      }

      if (!homeCity || homeCity.trim().length < 2) {
        return { success: false, field: "homeCity", message: "Please enter your home city." };
      }

      const safeInterests = Array.isArray(travelPreferences.interests) && travelPreferences.interests.length > 0
        ? travelPreferences.interests
        : ["food", "nature", "history"];

      const user = {
        id: "usr-" + Date.now(),
        name: name.trim(),
        email: email ? email.trim() : `explorer_${Date.now()}@wanderwise.com`,
        avatar: name.trim().split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2) || "W",
        homeCity: homeCity.trim(),
        role: "Adventurer",
        travelPreferences: {
          budget: travelPreferences.budget || "mid",
          companion: travelPreferences.companion || "solo",
          interests: safeInterests
        },
        joinedDate: new Date().toISOString().split("T")[0]
      };

      // Save user to active session
      this._set(STORAGE_KEYS.USER, user);
      localStorage.removeItem(STORAGE_KEYS.IS_GUEST);

      // Save to registered users database
      const users = this._get(STORAGE_KEYS.USERS, []);
      const existingIdx = users.findIndex(u => u.email.toLowerCase() === user.email.toLowerCase());
      if (existingIdx >= 0) {
        users[existingIdx] = { ...users[existingIdx], ...user, password: password || users[existingIdx].password };
      } else {
        users.push({ ...user, password: password || "password123" });
      }
      this._set(STORAGE_KEYS.USERS, users);

      this.syncNav();
      return { success: true, user };
    },

    /**
     * Activate guest browsing mode and redirect to destination explorer.
     */
    continueAsGuest(redirectUrl = "destination.html") {
      localStorage.setItem(STORAGE_KEYS.IS_GUEST, "true");
      localStorage.removeItem(STORAGE_KEYS.USER);
      this.syncNav();
      window.location.href = redirectUrl;
    },

    /**
     * Sign out user and return to login page.
     */
    logout() {
      localStorage.removeItem(STORAGE_KEYS.USER);
      localStorage.removeItem(STORAGE_KEYS.IS_GUEST);
      this.syncNav();
      window.location.href = "login.html";
    },

    // =========================================================================
    // Action Guard: Blocks Guests From Booking or Saving Itineraries
    // =========================================================================
    requireAuth(actionName = "proceed with this action", onAllowed = null) {
      if (this.isAuthenticated()) {
        if (typeof onAllowed === "function") onAllowed();
        return true;
      }

      this.showAuthModal(actionName);
      return false;
    },

    showAuthModal(actionName = "book tickets or save an itinerary") {
      let modal = document.getElementById("guest-auth-modal");
      if (!modal) {
        modal = document.createElement("div");
        modal.id = "guest-auth-modal";
        modal.className = "auth-guard-modal";
        modal.innerHTML = `
          <div class="auth-guard-box">
            <div class="auth-guard-icon">🔒</div>
            <h2 style="font-size: var(--text-2xl); margin-bottom: var(--space-2); color: var(--text-main);">Sign In Required</h2>
            <p id="guest-auth-modal-msg" style="color: var(--text-muted); font-size: var(--text-sm); line-height: 1.6;">
              Guests can freely explore worldwide destinations. To ${actionName}, please sign in or create a free account.
            </p>
            <div class="auth-guard-actions">
              <a href="login.html" class="btn btn-primary btn-lg btn-block">Sign In to Your Account</a>
              <a href="signup.html" class="btn btn-outline btn-block">Create a Free Account</a>
              <button type="button" class="btn btn-ghost btn-sm" onclick="Auth.hideAuthModal()">
                Keep Browsing as Guest
              </button>
            </div>
          </div>
        `;
        document.body.appendChild(modal);

        // Close on backdrop click
        modal.addEventListener("click", (e) => {
          if (e.target === modal) Auth.hideAuthModal();
        });
      } else {
        const msgEl = document.getElementById("guest-auth-modal-msg");
        if (msgEl) {
          msgEl.textContent = `Guests can freely explore worldwide destinations. To ${actionName}, please sign in or create a free account.`;
        }
      }

      modal.classList.add("active");
    },

    hideAuthModal() {
      const modal = document.getElementById("guest-auth-modal");
      if (modal) modal.classList.remove("active");
    },

    // =========================================================================
    // Shared Nav Bar Sync
    // =========================================================================
    syncNav() {
      const userSlot = document.getElementById("header-user-slot");
      if (!userSlot) return;

      const user = this.getCurrentUser();
      const isGuest = this.isGuest();

      if (user && !isGuest) {
        // Authenticated State: "Logged in as [name]"
        userSlot.innerHTML = `
          <div class="user-pill" title="Logged in as ${user.name}">
            <span class="user-avatar">${user.avatar || 'U'}</span>
            <span class="user-nav-text">Logged in as <strong>${user.name}</strong></span>
          </div>
          <button type="button" class="btn btn-ghost btn-sm" onclick="Auth.logout()" title="Sign out of WanderWise">
            Sign Out
          </button>
        `;
      } else if (isGuest) {
        // Guest State
        userSlot.innerHTML = `
          <div class="user-pill guest-pill" title="Browsing WanderWise in Guest Mode">
            <span class="guest-indicator-dot"></span>
            <span class="user-nav-text">Guest Mode</span>
          </div>
          <a href="login.html" class="btn btn-outline btn-sm">Sign In</a>
          <a href="signup.html" class="btn btn-primary btn-sm">Sign Up</a>
        `;
      } else {
        // Unauthenticated State
        userSlot.innerHTML = `
          <a href="login.html" class="btn btn-outline btn-sm">Sign In</a>
          <a href="signup.html" class="btn btn-primary btn-sm">Get Started</a>
        `;
      }
    }
  };

  // Mount globally
  root.Auth = Auth;
  Auth.init();

  if (typeof document !== "undefined") {
    document.addEventListener("DOMContentLoaded", () => {
      Auth.syncNav();
    });
  }
})(typeof window !== "undefined" ? window : global);
