/**
 * WANDERWISE - UNIVERSAL DESTINATION & ATTRACTION SERVICE (destination-service.js)
 * 
 * Provides universal search, data retrieval, and autocomplete for ANY destination
 * globally (cities, states, countries, tourist attractions, and hidden gems).
 * 
 * Architecture:
 * 1. Tier 1: Local Knowledge Base + Typo-Tolerant Fuzzy Matcher (Levenshtein & N-gram)
 * 2. Tier 2: Open Public APIs (OpenStreetMap Nominatim + Wikipedia REST Summary)
 * 3. Tier 3: Zero-Failure Dynamic Profile Synthesizer (Realistic metadata, coordinates,
 *            INR budget, best season, curated imagery, and categorized places)
 * 4. LocalStorage Persistence: User-discovered destinations are cached across sessions
 * 5. Reusable Autocomplete UI: Pluggable input dropdown for any search bar
 */

(function (root, factory) {
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.DestinationService = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const CACHE_KEY = 'WW_CUSTOM_DESTINATIONS';
  const CACHE_EXPIRY_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

  // Curated fallback photo collections by theme / keyword for rich visual presentation
  const THEMATIC_PHOTOS = {
    hill: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1200&auto=format&fit=crop",
    mountain: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=1200&auto=format&fit=crop",
    himalaya: "https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?w=1200&auto=format&fit=crop",
    beach: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=1200&auto=format&fit=crop",
    island: "https://images.unsplash.com/photo-1589394815804-964ed0be2eb5?w=1200&auto=format&fit=crop",
    coastal: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&auto=format&fit=crop",
    heritage: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=1200&auto=format&fit=crop",
    fort: "https://images.unsplash.com/photo-1600100397608-f010f444f4e7?w=1200&auto=format&fit=crop",
    palace: "https://images.unsplash.com/photo-1615836245337-f5b9b2303f10?w=1200&auto=format&fit=crop",
    lake: "https://images.unsplash.com/photo-1615836245337-f5b9b2303f10?w=1200&auto=format&fit=crop",
    temple: "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=1200&auto=format&fit=crop",
    spiritual: "https://images.unsplash.com/photo-1600100397608-f010f444f4e7?w=1200&auto=format&fit=crop",
    forest: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=1200&auto=format&fit=crop",
    city: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=1200&auto=format&fit=crop",
    metro: "https://images.unsplash.com/photo-1587474260584-136574528ed5?w=1200&auto=format&fit=crop",
    desert: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=1200&auto=format&fit=crop",
    international: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1200&auto=format&fit=crop",
    default: "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=1200&auto=format&fit=crop"
  };

  // Place categories standard across WanderWise
  const CATEGORIES = [
    "Attractions",
    "Food & Restaurants",
    "Nightlife",
    "Nature/Outdoors",
    "Museums & Culture",
    "Shopping"
  ];

  // =========================================================================
  // 1. LOCAL STORAGE & IN-MEMORY CACHE
  // =========================================================================
  function getStoredCache() {
    try {
      const raw = localStorage.getItem(CACHE_KEY);
      if (!raw) return {};
      const parsed = JSON.parse(raw);
      const now = Date.now();
      const fresh = {};
      for (const k in parsed) {
        if (parsed[k].timestamp && (now - parsed[k].timestamp < CACHE_EXPIRY_MS)) {
          fresh[k] = parsed[k];
        }
      }
      return fresh;
    } catch (e) {
      return {};
    }
  }

  function saveToStoredCache(key, data) {
    try {
      const cache = getStoredCache();
      cache[key] = {
        data: data,
        timestamp: Date.now()
      };
      localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
    } catch (e) {
      console.warn("DestinationService: Storage quota exceeded", e);
    }
  }

  // =========================================================================
  // 2. FUZZY MATCHING & SIMILARITY UTILITIES
  // =========================================================================
  function levenshteinDistance(s1, s2) {
    s1 = (s1 || '').toLowerCase();
    s2 = (s2 || '').toLowerCase();
    const m = s1.length;
    const n = s2.length;
    const d = [];

    for (let i = 0; i <= m; i++) d[i] = [i];
    for (let j = 0; j <= n; j++) d[0][j] = j;

    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        const cost = s1[i - 1] === s2[j - 1] ? 0 : 1;
        d[i][j] = Math.min(
          d[i - 1][j] + 1,      // deletion
          d[i][j - 1] + 1,      // insertion
          d[i - 1][j - 1] + cost // substitution
        );
      }
    }
    return d[m][n];
  }

  function fuzzyScore(target, query) {
    if (!target || !query) return 0;
    target = target.toLowerCase().trim();
    query = query.toLowerCase().trim();

    // Exact match
    if (target === query) return 1.0;
    // Prefix match
    if (target.startsWith(query)) return 0.92;
    // Word boundary start match
    const words = target.split(/[\s,/-]+/);
    for (const w of words) {
      if (w.startsWith(query)) return 0.88;
    }
    // Substring match
    if (target.includes(query)) return 0.80;

    // Levenshtein similarity for typos
    const maxLen = Math.max(target.length, query.length);
    if (maxLen === 0) return 1.0;

    let bestWordDist = Infinity;
    for (const w of words) {
      const dist = levenshteinDistance(w, query);
      if (dist < bestWordDist) bestWordDist = dist;
    }

    const fullDist = levenshteinDistance(target, query);
    const minDist = Math.min(fullDist, bestWordDist);

    const allowedTypos = query.length <= 4 ? 1 : query.length <= 7 ? 2 : 3;
    if (minDist <= allowedTypos) {
      return Math.max(0.4, 1 - (minDist / Math.max(query.length, 5)));
    }

    return 0;
  }

  // =========================================================================
  // 3. SEED KNOWLEDGE HELPER
  // =========================================================================
  function getSeedDestinations() {
    if (typeof window !== 'undefined' && window.MOCK_DATA && Array.isArray(window.MOCK_DATA.destinations)) {
      return window.MOCK_DATA.destinations;
    }
    return [];
  }

  function getSeedPlaces() {
    if (typeof window !== 'undefined' && window.MOCK_DATA && Array.isArray(window.MOCK_DATA.places)) {
      return window.MOCK_DATA.places;
    }
    return [];
  }

  function pickHeroPhoto(name, description, tags = []) {
    const text = `${name} ${description} ${(tags || []).join(' ')}`.toLowerCase();
    for (const key of Object.keys(THEMATIC_PHOTOS)) {
      if (key !== 'default' && text.includes(key)) {
        return THEMATIC_PHOTOS[key];
      }
    }
    if (text.includes('india')) {
      return "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=1200&auto=format&fit=crop";
    }
    return THEMATIC_PHOTOS.default;
  }

  function determineBestSeason(lat, name) {
    const n = (name || '').toLowerCase();
    if (n.includes('ladakh') || n.includes('leh') || n.includes('spiti') || n.includes('kashmir')) {
      return "May - September";
    }
    if (n.includes('goa') || n.includes('beach') || n.includes('andaman') || n.includes('kerala')) {
      return "November - March";
    }
    if (n.includes('shimla') || n.includes('manali') || n.includes('muss') || n.includes('ooty')) {
      return "March - June & Dec - Jan (Snow)";
    }
    return "October - March (Pleasant Weather)";
  }

  function determineTheme(name, desc) {
    const text = `${name} ${desc}`.toLowerCase();
    if (text.includes('fort') || text.includes('palace') || text.includes('heritage') || text.includes('ancient')) return "Heritage";
    if (text.includes('beach') || text.includes('island') || text.includes('ocean') || text.includes('coast')) return "Beach";
    if (text.includes('mountain') || text.includes('himalaya') || text.includes('hill') || text.includes('valley') || text.includes('lake')) return "Nature";
    if (text.includes('temple') || text.includes('ghat') || text.includes('sacred') || text.includes('spiritual')) return "Spiritual";
    if (text.includes('safari') || text.includes('tiger') || text.includes('park') || text.includes('jungle')) return "Wildlife";
    return "Culture";
  }

  // =========================================================================
  // 4. ZERO-FAILURE SYNTHESIZER
  // =========================================================================
  function synthesizeDestination(name, overrides = {}) {
    const cleanName = name.split(',')[0].trim();
    const id = 'dest-' + cleanName.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const theme = determineTheme(cleanName, overrides.description || '');
    const heroImage = overrides.heroImage || pickHeroPhoto(cleanName, overrides.description || '', [theme]);
    const bestTimeToVisit = overrides.bestTimeToVisit || determineBestSeason(overrides.lat || 20, cleanName);

    return {
      id: id,
      name: cleanName,
      country: overrides.country || "India",
      state: overrides.state || cleanName,
      tagline: overrides.tagline || `Discover the captivating sights, culture, and flavors of ${cleanName}.`,
      description: overrides.description || `${cleanName} is a vibrant destination renowned for its rich history, unique culture, picturesque landscapes, and local culinary traditions.`,
      heroImage: heroImage,
      rating: overrides.rating || (4.6 + ((cleanName.charCodeAt(0) % 4) / 10)).toFixed(1),
      reviewsCount: overrides.reviewsCount || (850 + (cleanName.length * 110)),
      avgBudget: overrides.avgBudget || "₹3,200 - ₹5,800 / day",
      bestTimeToVisit: bestTimeToVisit,
      theme: theme,
      tags: [theme, cleanName, "Culture", "Sights", "Travel"],
      lat: overrides.lat || 26.9124,
      lng: overrides.lng || 75.7873,
      isSynthesized: true
    };
  }

  function synthesizePlacesForDestination(destName, destId, centerLat, centerLng) {
    const lat = centerLat || 26.9124;
    const lng = centerLng || 75.7873;
    const clean = destName.split(',')[0].trim();

    return [
      {
        id: `pl-${destId}-1`,
        destinationId: destId,
        name: `${clean} Landmark Heritage Site`,
        category: "Attractions",
        subCategory: "Historic Landmark",
        rating: 4.8,
        reviewsCount: 1240,
        priceINR: 250,
        timings: "09:00 AM - 05:30 PM",
        estimatedTime: "2-3 hours",
        shortDescription: `Iconic landmark and architectural pride of ${clean}, offering panoramic vistas and rich history.`,
        photo: THEMATIC_PHOTOS.fort,
        lat: lat + 0.008,
        lng: lng + 0.006,
        isCustom: true
      },
      {
        id: `pl-${destId}-2`,
        destinationId: destId,
        name: `Old ${clean} Authentic Eatery`,
        category: "Food & Restaurants",
        subCategory: "Traditional Cuisine",
        rating: 4.7,
        reviewsCount: 890,
        priceINR: 450,
        timings: "11:00 AM - 11:00 PM",
        estimatedTime: "1-2 hours",
        shortDescription: `Renowned for delectable authentic regional dishes, culinary secrets, and welcoming atmosphere.`,
        photo: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop",
        lat: lat - 0.005,
        lng: lng + 0.003,
        isCustom: true
      },
      {
        id: `pl-${destId}-3`,
        destinationId: destId,
        name: `${clean} Sky Lounge & Brewery`,
        category: "Nightlife",
        subCategory: "Rooftop Bar",
        rating: 4.6,
        reviewsCount: 420,
        priceINR: 1200,
        timings: "06:00 PM - 01:00 AM",
        estimatedTime: "2-3 hours",
        shortDescription: `Scenic rooftop bar offering handcrafted drinks, evening music, and starlit views of ${clean}.`,
        photo: "https://images.unsplash.com/photo-1514933651103-005eec06c04b?w=800&auto=format&fit=crop",
        lat: lat + 0.003,
        lng: lng - 0.004,
        isCustom: true
      },
      {
        id: `pl-${destId}-4`,
        destinationId: destId,
        name: `${clean} Nature Promenade & Viewpoint`,
        category: "Nature/Outdoors",
        subCategory: "Scenic Point",
        rating: 4.9,
        reviewsCount: 1530,
        priceINR: 0,
        timings: "Open 24 Hours (Sunrise Recommended)",
        estimatedTime: "1.5 hours",
        shortDescription: `Peaceful natural overlook surrounded by lush greenery, perfect for morning walks and sunset views.`,
        photo: THEMATIC_PHOTOS.mountain,
        lat: lat + 0.012,
        lng: lng + 0.015,
        isCustom: true
      },
      {
        id: `pl-${destId}-5`,
        destinationId: destId,
        name: `${clean} Central Heritage Museum`,
        category: "Museums & Culture",
        subCategory: "Cultural Museum",
        rating: 4.7,
        reviewsCount: 680,
        priceINR: 150,
        timings: "10:00 AM - 05:00 PM (Closed Mondays)",
        estimatedTime: "2 hours",
        shortDescription: `Curated museum showcasing regional art, historical relics, royal textiles, and folklore.`,
        photo: THEMATIC_PHOTOS.heritage,
        lat: lat - 0.007,
        lng: lng - 0.006,
        isCustom: true
      },
      {
        id: `pl-${destId}-6`,
        destinationId: destId,
        name: `${clean} Artisans Bazaar & Market`,
        category: "Shopping",
        subCategory: "Local Souvenirs & Crafts",
        rating: 4.8,
        reviewsCount: 2150,
        priceINR: 300,
        timings: "10:30 AM - 09:30 PM",
        estimatedTime: "2 hours",
        shortDescription: `Lively marketplace with local handicrafts, regional spices, handcrafted garments, and trinkets.`,
        photo: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&auto=format&fit=crop",
        lat: lat - 0.002,
        lng: lng + 0.008,
        isCustom: true
      }
    ];
  }

  // =========================================================================
  // 5. PUBLIC API ADAPTERS (OpenStreetMap Nominatim + Wikipedia REST API)
  // =========================================================================
  async function fetchNominatimPlaces(query, limit = 5) {
    try {
      const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&addressdetails=1&limit=${limit}`;
      const res = await fetch(url, { headers: { 'Accept-Language': 'en' } });
      if (!res.ok) return [];
      const data = await res.json();
      return Array.isArray(data) ? data : [];
    } catch (e) {
      return [];
    }
  }

  async function fetchWikipediaSummary(title) {
    try {
      const cleanTitle = encodeURIComponent(title.replace(/\s+/g, '_'));
      const url = `https://en.wikipedia.org/api/rest_v1/page/summary/${cleanTitle}`;
      const res = await fetch(url);
      if (!res.ok) return null;
      const data = await res.json();
      if (data && data.extract) {
        return {
          title: data.title,
          description: data.extract,
          thumbnail: data.thumbnail ? data.thumbnail.source : null
        };
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // =========================================================================
  // 6. MAIN DESTINATION SERVICE API
  // =========================================================================
  const DestinationService = {
    // Search destinations matching query across local, external, and synthesized tiers
    async search(query, options = {}) {
      if (!query || query.trim().length === 0) return [];
      const q = query.trim().toLowerCase();
      const limit = options.limit || 8;

      const scored = [];
      const seenNames = new Set();

      // Check Seed Destinations (Tier 1)
      const seeds = getSeedDestinations();
      seeds.forEach(d => {
        const sName = fuzzyScore(d.name, q);
        const sState = fuzzyScore(d.state || '', q);
        const sTag = Math.max(0, ...(d.tags || []).map(t => fuzzyScore(t, q)));
        const best = Math.max(sName, sState, sTag * 0.85);

        if (best > 0.4) {
          scored.push({ dest: d, score: best, source: 'seed' });
          seenNames.add(d.name.toLowerCase());
        }
      });

      // Check LocalStorage Cache (Discovered Places)
      const cached = getStoredCache();
      for (const k in cached) {
        const item = cached[k].data;
        if (item && item.name && !seenNames.has(item.name.toLowerCase())) {
          const score = fuzzyScore(item.name, q);
          if (score > 0.4) {
            scored.push({ dest: item, score: score, source: 'cached' });
            seenNames.add(item.name.toLowerCase());
          }
        }
      }

      scored.sort((a, b) => b.score - a.score);

      // If good local match found, return immediately
      if (scored.length > 0 && scored[0].score >= 0.85) {
        return scored.slice(0, limit).map(s => s.dest);
      }

      // External Lookup via Nominatim (Tier 2)
      try {
        const geoResults = await fetchNominatimPlaces(query, 5);
        for (const r of geoResults) {
          const displayName = r.name || r.display_name.split(',')[0];
          const lower = displayName.toLowerCase();
          if (!seenNames.has(lower)) {
            const lat = parseFloat(r.lat);
            const lng = parseFloat(r.lon);
            const country = (r.address && r.address.country) || "India";
            const state = (r.address && (r.address.state || r.address.region)) || displayName;

            const wiki = await fetchWikipediaSummary(displayName);

            const synthesized = synthesizeDestination(displayName, {
              lat: lat,
              lng: lng,
              country: country,
              state: state,
              description: wiki ? wiki.description : `${displayName} is a prominent destination located in ${state}, ${country}.`,
              heroImage: wiki && wiki.thumbnail ? wiki.thumbnail : null
            });

            saveToStoredCache(synthesized.id, synthesized);
            scored.push({ dest: synthesized, score: 0.82, source: 'external' });
            seenNames.add(lower);
          }
        }
      } catch (err) {
        // Fallback to Tier 3 on network failure
      }

      // Zero-Failure Guarantee (Tier 3)
      if (scored.length === 0 && q.length >= 2) {
        const synth = synthesizeDestination(query);
        saveToStoredCache(synth.id, synth);
        scored.push({ dest: synth, score: 0.70, source: 'synthesizer' });
      }

      scored.sort((a, b) => b.score - a.score);
      return scored.slice(0, limit).map(s => s.dest);
    },

    // Retrieve single destination by ID or query name
    async getDestination(idOrName) {
      if (!idOrName) return null;
      const target = String(idOrName).trim();
      const seeds = getSeedDestinations();

      const byId = seeds.find(d => d.id.toLowerCase() === target.toLowerCase());
      if (byId) return byId;

      const byName = seeds.find(d => d.name.toLowerCase() === target.toLowerCase());
      if (byName) return byName;

      const cached = getStoredCache();
      if (cached[target] && cached[target].data) return cached[target].data;
      for (const k in cached) {
        if (cached[k].data && cached[k].data.name.toLowerCase() === target.toLowerCase()) {
          return cached[k].data;
        }
      }

      const searchResults = await this.search(target, { limit: 1 });
      if (searchResults.length > 0) {
        return searchResults[0];
      }

      const synth = synthesizeDestination(target);
      saveToStoredCache(synth.id, synth);
      return synth;
    },

    // Return all categorized places for destination
    async getPlacesForDestination(destIdOrName) {
      const dest = await this.getDestination(destIdOrName);
      if (!dest) return [];

      const seedPlaces = getSeedPlaces().filter(p => p.destinationId === dest.id);
      if (seedPlaces.length >= 4) {
        return seedPlaces;
      }

      const generated = synthesizePlacesForDestination(dest.name, dest.id, dest.lat, dest.lng);
      return [...seedPlaces, ...generated].slice(0, 12);
    },

    // Helper for coordinates and hero photo
    async getCoordsAndPhoto(destName) {
      const dest = await this.getDestination(destName);
      if (dest) {
        return {
          lat: dest.lat || 26.9124,
          lng: dest.lng || 75.7873,
          photo: dest.heroImage || THEMATIC_PHOTOS.default,
          name: dest.name
        };
      }
      return {
        lat: 26.9124,
        lng: 75.7873,
        photo: THEMATIC_PHOTOS.default,
        name: destName
      };
    },

    // Return cached destinations
    getCachedDestinations() {
      const cache = getStoredCache();
      return Object.keys(cache).map(k => cache[k].data).filter(Boolean);
    },

    // Pluggable autocomplete dropdown on input element
    attachAutocomplete(inputEl, options = {}) {
      if (!inputEl) return;
      const onSelect = options.onSelect || (() => {});
      const limit = options.limit || 6;

      let wrapper = inputEl.parentElement;
      if (wrapper && window.getComputedStyle(wrapper).position === 'static') {
        wrapper.style.position = 'relative';
      }

      let dropdown = wrapper.querySelector('.dest-autocomplete-dropdown');
      if (!dropdown) {
        dropdown = document.createElement('div');
        dropdown.className = 'dest-autocomplete-dropdown';
        dropdown.style.cssText = `
          position: absolute;
          top: calc(100% + 4px);
          left: 0;
          right: 0;
          background: white;
          border: 1px solid #cbd5e1;
          border-radius: 8px;
          box-shadow: 0 10px 25px rgba(0,0,0,0.12);
          z-index: 9999;
          max-height: 280px;
          overflow-y: auto;
          display: none;
          font-family: inherit;
        `;
        wrapper.appendChild(dropdown);
      }

      let debounceTimer = null;
      let activeIndex = -1;
      let currentItems = [];

      inputEl.addEventListener('input', (e) => {
        const val = e.target.value.trim();
        clearTimeout(debounceTimer);
        activeIndex = -1;

        if (val.length < 2) {
          dropdown.style.display = 'none';
          dropdown.innerHTML = '';
          return;
        }

        dropdown.innerHTML = `
          <div style="padding: 10px 14px; color: #64748b; font-size: 13px; display: flex; align-items: center; gap: 8px;">
            <span style="display:inline-block; width: 14px; height: 14px; border: 2px solid #cbd5e1; border-top-color: #0d9488; border-radius: 50%; animation: spin 0.8s linear infinite;"></span>
            Searching all destinations for "${val}"...
          </div>
        `;
        dropdown.style.display = 'block';

        debounceTimer = setTimeout(async () => {
          try {
            const results = await DestinationService.search(val, { limit: limit });
            currentItems = results;
            if (results.length === 0) {
              dropdown.innerHTML = `
                <div style="padding: 10px 14px; color: #64748b; font-size: 13px;">
                  Press Enter to plan for <strong>"${val}"</strong>
                </div>
              `;
              return;
            }

            dropdown.innerHTML = results.map((d, idx) => `
              <div class="dest-autocomplete-item" data-index="${idx}" style="padding: 10px 14px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #f1f5f9; transition: background 0.15s;">
                <div style="display: flex; align-items: center; gap: 10px; overflow: hidden;">
                  <span style="font-size: 16px;">${d.theme === 'Beach' ? '🏖️' : d.theme === 'Nature' ? '🏔️' : d.theme === 'Spiritual' ? '🛕' : d.theme === 'Heritage' ? '🏰' : '📍'}</span>
                  <div style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                    <strong style="font-size: 14px; color: #0f172a;">${d.name}</strong>
                    <span style="font-size: 12px; color: #64748b; margin-left: 6px;">${d.state ? d.state + ', ' : ''}${d.country || 'India'}</span>
                  </div>
                </div>
                <span style="font-size: 11px; font-weight: 600; color: #0d9488; background: #ccfbf1; padding: 2px 6px; border-radius: 4px; white-space: nowrap;">
                  ${d.avgBudget ? d.avgBudget.split('/')[0].trim() : 'Explore'}
                </span>
              </div>
            `).join('');

            dropdown.querySelectorAll('.dest-autocomplete-item').forEach(item => {
              item.addEventListener('mouseenter', () => {
                dropdown.querySelectorAll('.dest-autocomplete-item').forEach(i => i.style.background = '');
                item.style.background = '#f8fafc';
              });
              item.addEventListener('click', () => {
                const idx = parseInt(item.dataset.index, 10);
                selectItem(currentItems[idx]);
              });
            });
          } catch (err) {
            dropdown.style.display = 'none';
          }
        }, 220);
      });

      function selectItem(dest) {
        if (!dest) return;
        inputEl.value = dest.name;
        dropdown.style.display = 'none';
        onSelect(dest);
      }

      inputEl.addEventListener('keydown', (e) => {
        if (dropdown.style.display === 'none') return;
        const rows = dropdown.querySelectorAll('.dest-autocomplete-item');
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          activeIndex = Math.min(activeIndex + 1, rows.length - 1);
          highlightRow(rows);
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          activeIndex = Math.max(activeIndex - 1, 0);
          highlightRow(rows);
        } else if (e.key === 'Enter') {
          if (activeIndex >= 0 && currentItems[activeIndex]) {
            e.preventDefault();
            selectItem(currentItems[activeIndex]);
          } else if (inputEl.value.trim().length >= 2) {
            e.preventDefault();
            const synth = synthesizeDestination(inputEl.value.trim());
            selectItem(synth);
          }
        } else if (e.key === 'Escape') {
          dropdown.style.display = 'none';
        }
      });

      function highlightRow(rows) {
        rows.forEach((r, idx) => {
          if (idx === activeIndex) {
            r.style.background = '#e0f2fe';
            r.scrollIntoView({ block: 'nearest' });
          } else {
            r.style.background = '';
          }
        });
      }

      document.addEventListener('click', (e) => {
        if (!inputEl.contains(e.target) && !dropdown.contains(e.target)) {
          dropdown.style.display = 'none';
        }
      });
    }
  };

  return DestinationService;
});